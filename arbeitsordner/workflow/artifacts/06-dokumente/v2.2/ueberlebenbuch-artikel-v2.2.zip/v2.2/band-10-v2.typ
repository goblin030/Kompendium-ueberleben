// band-10-v2.typ — Artikel-Enzyklopaedie v2.2, Band 10: Tausch, Dorf und das Behalten (Turn 14)
// v2.2 (Turn 16): MR-1/2/7 (warn-alt refs, orphan warn-art, v1-captions), MR-3/4 (Farben AA), MR-6 (Dichte aus 22-recherche)
#import "../lib/stil.typ": *
#init-doc(band: 10, titel: "Artikel: Tausch, Dorf und das Behalten", farbe: "#7a3fa0", tint: "#efe8f4")
#set page(header: none, footer: none)
#titlepage(10, "Artikel-Enzyklopaedie: Tausch, Dorf und das Behalten", farbe: "#7a3fa0")
#pagebreak()
#seite(10, "Artikel: Tausch, Dorf und das Behalten")
== Artikel-Verzeichnis <inhalt>
Alle 32 Artikel dieses Bandes, alphabetisch, mit ART-ID und Seite.
#outline(title: none, depth: 2, indent: auto)
#pagebreak(weak: true)
#pagebreak(weak: true)
== ART-0283 — Wie aktiviere ich einen Krisenstab im Dorf (Alarmierung, Treffpunkt)? <art-0283>
Einen Krisenstab im Dorf/im Haus so aktivieren, dass bei Eintritt einer Krise (z. B. Blackout) ohne Strom und ohne digitales Netz Alarmierung, Zusammenkunft und geordnetes Handeln sofort funktionieren — mit Papierplan, benanntem Stab, Alarmierungsweg und festem Treffpunkt.
- Notfall-/Alarmplan _in Papierform_ (1 Exemplar je Haushalt + 1 am Treffpunkt) — WKO-Checkliste (29 Fragen, Mai 2022):
- Namensliste des Krisenstabs (Stab + Stellvertretung, doppelt besetzt — siehe ART-0312), Telefonnummern und Adressen _auf Papier_, laminiert
- Treffpunkt A (primär) und B (Ausweich) schriftlich festgelegt (siehe ART-0020)
- Protokollbogen (Amts-Blatt, siehe ART-0294/ART-0307)
- Signalmittel: Trillerpfeife (3 Signale/min, siehe ART-0013), Botenliste
- Zeitrahmen: Saurugg-Phasenmodell als Planungsannahme — Phase 1 stabile Stromversorgung ca. 1 Woche, Phase 2 Telekommunikation ca. 2–4 Wochen, Phase 3 Güterversorgung frühestens ca. 2 Wochen (Expertenheuristik, als Planungsannahme kennzeichnen — gelb)
+ _Vor der Krise:_ Krisenstab benennen (jede Funktion doppelt besetzen), Alarmplan in Papierform erstellen und an jedem Haushalt verteilen; Treffpunkt A/B festlegen; Alarmierungskette definieren (z. B. Pfeife → Botenlauf → Klingelkette).
+ _Krisenstab definieren:_ Leitung, Information/Außenkontakt, Versorgung (Wasser/Nahrung), Sicherheit/Wache, Protokoll — Ämter an die Hand vergeben, rotierend (ART-0312).
+ _Sicheres Herunterfahren definieren:_ welche Geräte werden bei Eintritt aus-/abgesteckt (Schutz beim Wiederanlaufen, siehe ART-0037), eine Lampe bleibt an; kritische Anlagen (Pumpen, Heizung) — Wasserleitungen nicht leerlaufen lassen (Lufteinschlüsse → Pumpenschäden).
+ _Bei Eintritt alarmieren:_ Signal geben (3 Pfeiftöne/min), Stab am Treffpunkt A zusammenrufen; wenn A blockiert → Treffpunkt B.
+ _Erste Lage:_ Personen zählen, Verletzte (ART-0231), Schäden melden; Protokoll eröffnen (Datum, Uhrzeit, Maßnahmen).
+ _Betrieb/Werkstatt:_ Notfallplan in Papierform griffbereit; Notstromaggregat _nur außerhalb_ des Gebäudes betreiben (CO-Gefahr — siehe ART-0081, Warnpflicht).
+ _Warten auf stabile Versorgung:_ keine übereilten Wiederanlauf-Aktionen; offizielle Durchsagen per UKW-Radio verfolgen (siehe ART-0006).
- _Stadt:_ Krisenstab = Hausgemeinschaft; Treffpunkt Treppenhaus/Hof; Alarmierung über Klingelkette; Plan liegt in Papierform in jedem Haushalt.
- _Land:_ Krisenstab im Gemeindehaus/Dorfanger; Alarmierung per Botenlauf/Pfeife; längere Wege → Trupp-Regel (ART-0303) und +60-Minuten-Regel (ART-0027).
- _Klima/Jahreszeit:_ Winter: Treffpunkt wettergeschützt wählen; Wärmequellen sofort planen (ART-0086); Sommer: Wasservorrat sofort auffüllen (ART-0057).
#table(
  columns: 3,
  table.header([Fehler], [Folge], [Korrektur]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Notfallplan nur digital (PC/Cloud)], [bei Stromausfall unlesbar — Totalverlust], [Papierform Pflicht, 1 Exemplar je Haushalt],
  [Kein benannter Treffpunkt], [Chaos in den ersten Stunden], [Treffpunkt A/B schriftlich (ART-0020)],
  [Keine Alarmierungskette], [niemand weiß, wen er rufen soll], [Pfeife/Boten/Klingelkette definieren],
  [Aggregat in geschlossenen Räumen], [CO-Vergiftung, tödlich], [nur außerhalb betreiben (ART-0081)],
)
Keine eigene Warnpflicht. CO-Warnung bei Notstromaggregaten siehe ART-0081 (Band 3) . SETON-Guide (gewerblicher Blick) nur über Sekundärquellen belegt — WKO-Checkliste deckt den Inhalt ab (grün).
ART-0020 (Band 1) (Treffpunkte A/B), ART-0027 (Band 1) (Boten, +60-Minuten-Regel), ART-0013 (Band 1) (Notrufzeichen/Pfeife), ART-0037 (Band 1) (Geräte beim Wiederanlaufen), ART-0006 (Band 1) (UKW-Radio), ART-0081 (Band 3) (Notstromaggregat, CO), ART-0284, S. #refpage(<art-0284>) (Selbsthilfe-Netz), ART-0297, S. #refpage(<art-0297>) (Betrieb/Werkstatt), ART-0312, S. #refpage(<art-0312>) (Ämter)
Üben: einmal jährlich einen Krisenstab-Drill mit dem Papierplan — Alarmierung und Zusammenkunft am Treffpunkt in unter 30 Minuten. Ein zweiter Durchlauf im Jahr nur, wenn der erste Lücken zeigt.
- _Krisenstab:_ benannte Leitungsgruppe mit doppelt besetzten Funktionen; tagt am Treffpunkt.
- _Alarmplan (Papierform):_ schriftlicher Plan, der ohne Strom lesbar ist.
- _Sicheres Herunterfahren:_ definiertes Ausschalten/Ausstecken kritischer Geräte bei Kriseneintritt.
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Abbildungen]]
#grid(columns: (1fr, 1fr), column-gutter: 6pt, row-gutter: 5pt,
  figure(image("../illustrationen/art-0283-abb-1.svg", width: 100%), caption: [Abb. zu ART-0283 — ART-0283 · Abb. 1: Alarmierungskette im Dorf: Sirene/NINA → Anrufbaum → Bote – jeder Ruf geht an zwei weitere (ART-0283).]),
  figure(image("../illustrationen/art-0283-abb-2.svg", width: 100%), caption: [Abb. zu ART-0283 — ART-0283 · Abb. 2: Krisenstab im Dorf: feste Rollen am Ratstisch, Protokollführer, doppelte Besetzung (ART-0283).]))
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Kontroll-Checkliste]]
- [ ] Vor der Krise: Krisenstab benennen (jede Funktion doppelt besetzen), Alarmplan in Papierform erstellen und an 
- [ ] Krisenstab definieren: Leitung, Information/Außenkontakt, Versorgung (Wasser/Nahrung), Sicherheit/Wache, Proto
- [ ] Sicheres Herunterfahren definieren: welche Geräte werden bei Eintritt aus-/abgesteckt (Schutz beim Wiederanlau
- [ ] Bei Eintritt alarmieren: Signal geben (3 Pfeiftöne/min), Stab am Treffpunkt A zusammenrufen; wenn A blockiert 
- [ ] Erste Lage: Personen zählen, Verletzte (ART-0231 (Band 8)), Schäden melden; Protokoll eröffnen (Datum, Uhrzeit, Maßnahm
- [ ] Betrieb/Werkstatt: Notfallplan in Papierform griffbereit; Notstromaggregat nur außerhalb des Gebäudes betreibe
- [ ] Warten auf stabile Versorgung: keine übereilten Wiederanlauf-Aktionen; offizielle Durchsagen per UKW-Radio ver
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Recherche-Details (Fakten, Masse, Fehler-Tiefe)]]
#table(
  columns: 2,
  table.header([*Aspekt*], [*Detail (Recherche)*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Masse/Zeiten/Mengen], [29 Prüfragen ; keine festen Zeiten vorgegeben — Alarmierung/Treffpunkt müssen vor dem Ereignis festgelegt sein; Saurugg-Phasen als Zeithorizont: Phase 1 Strom s],
  [Typische Fehler], [Notfallplan nur digital ; kein benannter Treffpunkt; keine Alarmierungskette → Chaos in den ersten Stunden .],
  [Varianten Stadt/Land], [Land: Krisenstab im Gemeindehaus/Dorfanger, Alarmierung per Botenlauf/Pfeife ; Stadt: Hausgemeinschaft, Treffpunkt Treppenhaus/Hof, Alarmierung über Klingelkett],
  [Fakten], [WKO-Checkliste : Notfall-/Alarmpläne in Papierform, Krisenstab benennen + Alarmierungsweg + Treffpunkt festlegen, kritisches „sicheres Herunterfahren" definiere],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Übungsprotokoll (Verfalluhr 12 Monate)]]
#table(
  columns: 5,
  table.header([*Nr.*], [*Datum*], [*Dauer*], [*Fehler*], [*V / Verfall*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [1], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [2], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [3], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [4], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [5], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [6], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [7], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [8], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [9], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [10], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [11], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [12], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Randbedingungen (vor Ort ausfüllen)]]
#table(
  columns: 3,
  table.header([*Randbedingung*], [*Trifft zu*], [*Anmerkung*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Allein / in der Gruppe], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Stadt / Land], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Tag / Nacht], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Sommer / Winter], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Notizen zu ART-0283]]
#block(width: 100%, height: 6.5cm, stroke: 0.6pt + rgb("#8c8c8c"), inset: 6pt)[Platz für eigene Notizen zu diesem Artikel.]
#pagebreak(weak: true)
== ART-0284 — Wie baue ich ein nachbarschaftliches Selbsthilfe-Netz auf? <art-0284>
Ein nachbarschaftliches Selbsthilfe-Netz aufbauen, das ohne Strom und digitales Netz funktioniert: bekannte Namen, Papier-Adressliste, gemeinsame Basis (Wasser, Wärme, Information, Medikamente), gegenseitige Hilfe bei Kriseneintritt.
- Adress- und Kontaktliste _auf Papier_, laminiert (Name, Wohnung, Tel.-Nr. auf Papier, besondere Bedürfnisse, Medikamente — siehe ART-0288, ART-0301)
- Selbsthilfe-Basis: kühler, trockener Raum mit Vorrat (Treppenhaus/Hof/Keller) — gemeinsamer Vorrat siehe ART-0287
- Kommunikationsmittel ohne Netz: UKW-Kurbelradio (72 h+ Notstrom an Sendern, gesetzlich verpflichtet —), Boten (ART-0027)
- Vorsorgehorizont: _10 Tage = BBK-Mindeststandard (aktuell), 14 Tage = Kompendium-Empfehlung_ (Versionshinweis: ältere BBK-Ratgeber 14 T; Saurugg 2 Wochen —)
- Score-Bänder \<30/30–70/\>70 % sind proprietär → als „orientierender Score, nicht amtlicher Standard“ kennzeichnen
+ Nachbarn kennenlernen: Liste mit Namen, Wohnungen, Telefonnummern (Papier), besondere Bedürfnisse/Bedarfe notieren — 2 Wissende pro Haushalt (siehe ART-0223).
+ Selbsthilfe-Basis einrichten: ein Raum je Haus/Weiler mit Wasser, Lebensmitteln, Medikamenten, Licht, Radio; Wache einteilen (ART-0028).
+ Absprachen schriftlich: Wer bringt was in die Basis? Wer hat welche Fähigkeit (Handwerk ART-0266, Heilkunde ART-0223)? Tausch-Regeln siehe ART-0285/ART-0302.
+ Kommunikation ohne Netz planen: UKW-Radio als garantierter Fallback (NINA braucht mobiles Internet — Ahrtal 2021 belegt); Durchsagen zur vollen Stunde (ART-0008).
+ Üben: 1× jährlich Treffen der Basis, Checkliste durchgehen, Lücken schließen.
- _Stadt:_ dichtes Netz im Haus/Stockwerk; Basis im kühlen Treppenhaus oder Hof; kurze Wege; mehr Bargeld-Reserve (ART-0296).
- _Land:_ Basis je Weiler; längere Wege → Trupp-Regel (ART-0303), +60-Minuten-Regel (ART-0027); Garten/Tierversorgung (ART-0042).
- _Klima:_ Winter: Wärmekonzept der Basis (ein Raum, ART-0086); Sommer: Wasservorrat hoch (ART-0064).
#table(
  columns: 3,
  table.header([Fehler], [Folge], [Korrektur]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Netz nur „gedacht“, keine Papierliste], [bei Netzausfall keine Kontakte], [laminierte Liste je Haushalt (ART-0288)],
  [Basis ohne Wache], [Diebstahl, Plünderung], [Wachplan (ART-0028, ART-0300)],
  [Basis ohne Wasser-/Medikamenten-Plan], [Mangel in der ersten Woche], [ART-0064, ART-0301],
  [NINA als einziger Warnkanal], [ohne mobiles Netz keine Warnung], [UKW-Kurbelradio als Fallback (ART-0006)],
)
Keine eigene Warnpflicht. NINA-Ausfall ohne mobiles Internet: Warnung siehe ART-0026 (Band 1)/ART-0006 (Band 1) (grün + Warnung).
ART-0020 (Band 1), ART-0026 (Band 1), ART-0027 (Band 1), ART-0028 (Band 1), ART-0042 (Band 1), ART-0283, S. #refpage(<art-0283>) (Krisenstab), ART-0288, S. #refpage(<art-0288>), ART-0296, S. #refpage(<art-0296>), ART-0301, S. #refpage(<art-0301>), ART-0303, S. #refpage(<art-0303>)
Üben: halbjährlich ein Treffen der Selbsthilfe-Basis — die Checkliste mit allen sechs Kategorien (Licht, Wärme, Kommunikation, Wasser, Lebensmittel, Medizin) kurz durchgehen und Lücken notieren.
- _Selbsthilfe-Basis:_ gemeinsam genutzter Raum mit Vorrat, Licht, Radio und Wache.
- _Selbsteinschätzung-Score:_ orientierender Prozentwert einer Checkliste, kein amtlicher Standard.
- _UKW-Fallback:_ Rundfunk als garantierter Informationskanal ohne mobiles Internet (72 h+ Notstrom, gesetzlich verpflichtet).
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Abbildungen]]
#grid(columns: (1fr, 1fr), column-gutter: 6pt, row-gutter: 5pt,
  figure(image("../illustrationen/art-0284-abb-1.svg", width: 100%), caption: [Abb. zu ART-0284 — ART-0284 · Abb. 1: Netzkarte Haus/Weiler: jedes Haus mit mindestens zwei Verbindungen, Knotenpunkt markiert (ART-0284).]),
  figure(image("../illustrationen/art-0284-abb-2.svg", width: 100%), caption: [Abb. zu ART-0284 — ART-0284 · Abb. 2: Wer hilft wem: vereinbarte Hilfen pro Haushalt eintragen (ART-0284).]))
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Kontroll-Checkliste]]
- [ ] Nachbarn kennenlernen: Liste mit Namen, Wohnungen, Telefonnummern (Papier), besondere Bedürfnisse/Bedarfe noti
- [ ] Selbsthilfe-Basis einrichten: ein Raum je Haus/Weiler mit Wasser, Lebensmitteln, Medikamenten, Licht, Radio; W
- [ ] Absprachen schriftlich: Wer bringt was in die Basis? Wer hat welche Fähigkeit (Handwerk ART-0266 (Band 9), Heilkunde AR
- [ ] Kommunikation ohne Netz planen: UKW-Radio als garantierter Fallback (NINA braucht mobiles Internet — Ahrtal 20
- [ ] Üben: 1× jährlich Treffen der Basis, Checkliste durchgehen, Lücken schließen.
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Recherche-Details (Fakten, Masse, Fehler-Tiefe)]]
#table(
  columns: 2,
  table.header([*Aspekt*], [*Detail (Recherche)*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Masse/Zeiten/Mengen], [Vorsorgehorizont mindestens 2 Wochen Autonomie — gelb, als Planungsannahme kennzeichnen; BBK aktuell 10 Tage Mindeststandard / 14 Tage Kompendium-Empfehlung ; k],
  [Typische Fehler], [Netz nur „gedacht“ statt schriftlich mit Namen/Telefon auf Papier ; Basis ohne Wache ; Basis ohne Wasser-/Medikamenten-Plan.],
  [Varianten Stadt/Land], [Stadt: dichtes Netz im Haus/Stockwerk, Selbsthilfe-Basis im kühlen Treppenhaus oder Hof, kurze Wege; Land: Selbsthilfe-Basen je Weiler, längere Wege → Trupp-Reg],
  [Fakten], [Saurugg-Checkliste : eigene Rubrik „Nachbarschaft / Selbsthilfe-Basen“ — Nachbarschaft kennen, gegenseitige Hilfe vereinbaren, gemeinsame Basis einrichten; Komm],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Übungsprotokoll (Verfalluhr 12 Monate)]]
#table(
  columns: 5,
  table.header([*Nr.*], [*Datum*], [*Dauer*], [*Fehler*], [*V / Verfall*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [1], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [2], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [3], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [4], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [5], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [6], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [7], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [8], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [9], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [10], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [11], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [12], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Randbedingungen (vor Ort ausfüllen)]]
#table(
  columns: 3,
  table.header([*Randbedingung*], [*Trifft zu*], [*Anmerkung*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Allein / in der Gruppe], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Stadt / Land], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Tag / Nacht], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Sommer / Winter], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Notizen zu ART-0284]]
#block(width: 100%, height: 6.5cm, stroke: 0.6pt + rgb("#8c8c8c"), inset: 6pt)[Platz für eigene Notizen zu diesem Artikel.]
#pagebreak(weak: true)
== ART-0285 — Wie bestimme ich den Wert von Ware (Korridor Stunde/Seltenheit/Not)? <art-0285>
Den Wert von Ware nicht als festen Preis, sondern als _Korridor_ bestimmen: drei Hebel — Arbeitszeit (Stunde), Seltenheit, Not — begrenzen den ehrlichen Preis; zwischen den Grenzen wird gehandelt, auf ihnen nicht.
- Wert-Tafel des Hauses/Dorfes (Papier, am Amts-Blatt — siehe ART-0307)
- Bürger-Maß zum Prüfen (siehe ART-0314): Elle (Vorderarm bis Mittelfinger, ≈ 45 cm Körpermaß, individuell geeicht), Fuß, _Rute regional 10–16 Fuß_, Mandel = 15 Stück, Zentner = 100 Pfund (50 kg)
- Historischer Vergleich: „15/Zehnt“ = 15 Teile Maß plus ein Zehnt Aufschlag — heute nicht gebräuchlich, nur als historischer Vergleich führen
- Wert-Tafel (Beispiele, aus der): ein Sack Salz = hoch (Sieden/Zufuhr), teuer im Binnenland, ehrlich an der Küste; ein Zuber Korn = ein Sommer Feldarbeit, nach Missernte groß, im Frühjahr hart; ein Eimer Honig = mittel, fest (tauscht wie Geld); geschmiedete Sichel = hoch, hält zwei Ernten, nie unter Wert; die Stunde der Hand = 1:1 (ART-0310)
+ Vor jedem Tausch die _drei Hebel_ fragen: Wie viel Arbeitszeit steckt in der Ware? Wie selten ist sie gerade? Wie groß ist die Not des Tauschpartners?
+ Korridor aufschreiben: untere Grenze (Stundenwert), obere Grenze (Notwert) — am Tausch-Blatt (ART-0307) vermerken.
+ Innerhalb des Korridors handeln — nie auf der Spitze; in der Not zählt der Bedarf des anderen, nicht der eigene Besitz.
+ Seltenheit prüfen: was nicht verfügbar ist (z. B. Salz im Binnenland), steigt im Wert.
+ Not-Preis nach der Not — aber im Korridor bleiben; Wucher-Grenze siehe ART-0313 (§ 291 StGB).
- _Stadt/Land:_ gleich — Normalzeit: Stunden-Tafel 1:1 (ART-0310); Not: gegenseitiger Bedarf.
- _Klima/Jahreszeit:_ nach Missernte steigt Getreide, im Frühjahr hart; nach der Ernte ruhig; Winter: Salz/Honig/Talg wertvoll (ART-0309).
#table(
  columns: 3,
  table.header([Fehler], [Folge], [Korrektur]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Jeden Tausch nach eigenem Maßstab bewerten], [unfaire Geschäfte, Konflikte], [Korridor rechnen: Stunde, Seltenheit, Not],
  [In Angst gekauft, nicht im Korridor gerechnet], [Preis der Angst zahlt dreimal], [zwischen den Märkten kaufen (ART-0302)],
  [Historische Maße unkritisch übernehmen (z. B. „Ruthe = 6 Fuß“)], [falsche Mengen], [Rute regional 10–16 Fuß; Körpermaße selbst eichen (ART-0024)],
)
Keine eigene Warnpflicht. Wucher in der Not: strafbar (§ 291 StGB) — Warnrahmen siehe ART-0313, S. #refpage(<art-0313>).
ART-0302, S. #refpage(<art-0302>) (Tausch-Platz), ART-0307, S. #refpage(<art-0307>) (Vertrag), ART-0309, S. #refpage(<art-0309>) (haltbare Ware), ART-0310, S. #refpage(<art-0310>) (Stunden-Tafel), ART-0313, S. #refpage(<art-0313>) (Wucher), ART-0314, S. #refpage(<art-0314>) (ehrlich wiegen), ART-0024 (Band 1) (Körpermaße)
Üben: bei jedem Tausch den Wert-Korridor (Stunde, Seltenheit, Not) laut ansagen und am Blatt eintragen — Routine macht den ehrlichen Preis sicher.
- _Korridor:_ Grenzen des ehrlichen Preises — zwischen ihnen wird gehandelt, auf ihnen nicht.
- _Elle:_ Körpermaß Vorderarm–Mittelfinger (≈ 45 cm, individuell); historische Einheit regional verschieden.
- _Mandel:_ altes Zählmaß = 15 Stück. _Rute:_ altes Längenmaß, regional 10–16 Fuß. _Zentner:_ 100 Pfund = 50 kg.
- _Not-Preis:_ Preis nach dem Bedarf des anderen in der Not — im Korridor bleiben (ART-0313).
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Kontroll-Checkliste]]
- [ ] Vor jedem Tausch die drei Hebel fragen: Wie viel Arbeitszeit steckt in der Ware? Wie selten ist sie gerade? Wi
- [ ] Korridor aufschreiben: untere Grenze (Stundenwert), obere Grenze (Notwert) — am Tausch-Blatt (ART-0307, S. #refpage(<art-0307>)) vermer
- [ ] Innerhalb des Korridors handeln — nie auf der Spitze; in der Not zählt der Bedarf des anderen, nicht der eigen
- [ ] Seltenheit prüfen: was nicht verfügbar ist (z. B. Salz im Binnenland), steigt im Wert.
- [ ] Not-Preis nach der Not — aber im Korridor bleiben; Wucher-Grenze siehe ART-0313, S. #refpage(<art-0313>) (§ 291 StGB).
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Recherche-Details (Fakten, Masse, Fehler-Tiefe)]]
#table(
  columns: 2,
  table.header([*Aspekt*], [*Detail (Recherche)*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Masse/Zeiten/Mengen], [Elle ≈ 45 cm ; Ruthe = 6 Fuß; Mandel = 15 Stück; Korridor je Ware in der Wert-Tafel .],
  [Typische Fehler], [jeden Tausch nach eigenem Maßstab bewerten → unfaire Geschäfte, Konflikte ; in Angst gekauft statt im Korridor gerechnet → Preis der Angst zahlt dreimal .],
  [Varianten Stadt/Land], [gleich; Normalzeit: Stunden-Tafel 1:1; Not: gegenseitiger Bedarf. Stadt: Wohnungsküche/Treppenhaus als Maß-Referenz.],
  [Fakten], [Wert ist kein fester Preis, sondern ein Korridor aus drei Hebeln: 1. Arbeitszeit , 2. Seltenheit , 3. Not . Historische Hohlmaße als Vergleich: Elle ≈ 45 cm , R],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Übungsprotokoll (Verfalluhr 12 Monate)]]
#table(
  columns: 5,
  table.header([*Nr.*], [*Datum*], [*Dauer*], [*Fehler*], [*V / Verfall*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [1], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [2], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [3], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [4], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [5], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [6], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [7], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [8], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [9], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [10], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [11], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [12], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Randbedingungen (vor Ort ausfüllen)]]
#table(
  columns: 3,
  table.header([*Randbedingung*], [*Trifft zu*], [*Anmerkung*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Allein / in der Gruppe], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Stadt / Land], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Tag / Nacht], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Sommer / Winter], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Notizen zu ART-0285]]
#block(width: 100%, height: 6.5cm, stroke: 0.6pt + rgb("#8c8c8c"), inset: 6pt)[Platz für eigene Notizen zu diesem Artikel.]
#pagebreak(weak: true)
== ART-0286 — Wie bewahre ich Wissen auf (Abschreiben, vier Schichten)? <art-0286>
Wissen so aufbewahren, dass es den Ausfall einzelner Schichten überlebt — und den Tod des Wissenden: vier Schichten der Bewahrung (geschrieben, verlesen, eingeübt, Vermächtnis).
- Papier, Stifte, Kopien (Drucker nur solange Strom da — Papier ist Primärträger)
- Vier Schichten: _1. geschriebene Kopie, 2. verlesene mündliche Überlieferung, 3. eingeübte Praxis_ (ART-0035), _4. Vermächtnis_ (ART-0311)
- Kopien in mehreren Haushalten (Stadt: mehrere Wohnungen; Land: mehrere Gebäude)
- Prüfungsrhythmus (Schichten-Tafel): Vorrat je Monat gezählt / je Quartal gedreht (Ältestes nach vorn); Zeug je Saison (Anfang + Ende); Wissen je Winter in den langen Abenden erneuert; Reserve je Halbjahr und nach jeder Not
+ Kernwissen pro –9 auf ein Blatt schreiben (Vermächtnis-Blatt, ART-0311).
+ Abschreiben: mindestens 2 Kopien an verschiedenen Orten (anderes Gebäude/anderer Haushalt).
+ Verlesen: einmal im Monat/Rat vorlesen, damit die mündliche Schicht lebendig bleibt (ART-0293).
+ Einüben: jede Fertigkeit nach (12 Monate) wiederholen (ART-0035).
+ Prüfen: Wissen-Schicht jeden Winter erneuern; Prüferkreis am Prüfungs-Bogen.
- _Stadt:_ Kopien in mehreren Wohnungen des Hauses/einem vertrauten Haushalt im anderen Stadtteil.
- _Land:_ Kopien in mehreren Gebäuden des Hofes/Nachbardörfern.
- _Klima:_ Papier trocken, dunkel, hoch lagern (Feuchtigkeit zerstört es); Brand siehe ART-0300 (Blätter zuerst retten).
#table(
  columns: 3,
  table.header([Fehler], [Folge], [Korrektur]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Nur mündlich überliefern], [Wissen stirbt mit der Person], [4 Schichten führen (dieser Artikel)],
  [Nur eine Kopie an einem Ort], [Totalverlust bei Brand/Diebstahl/Wasserschaden], [≥ 2 Kopien, getrennte Orte],
  [Nie verlesen/never geübt], [Schicht 2/3 leer], [monatliches Verlesen + (ART-0035)],
)
Keine eigene Warnpflicht. Brand im Zeug-Haus/Lager: „weckt das Dorf zuerst, rettet die Blätter zweitens“ — Warnrahmen siehe ART-0300, S. #refpage(<art-0300>).
ART-0311, S. #refpage(<art-0311>) (Vermächtnis), ART-0293, S. #refpage(<art-0293>) (Gedenken), ART-0035 (Band 1) , ART-0292, S. #refpage(<art-0292>) (Feuerprobe), ART-0300, S. #refpage(<art-0300>) (Zeug-Haus)
Üben: jeden Winter ein Band des Wissens komplett abschreiben und einmal vorlesen — so bleibt jede der vier Schichten lebendig.
- _Vier Schichten:_ geschrieben – verlesen – eingeübt – Vermächtnis; Wissen überlebt so den Ausfall einzelner Schichten.
- _:_ 12 Monate ohne Wiederholung = Fähigkeit verfallen (ART-0035).
- _Prüf-Kreis:_ Gruppe, die die Schichten regelmäßig prüft und erneuert.
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Kontroll-Checkliste]]
- [ ] Kernwissen pro –9 auf ein Blatt schreiben (Vermächtnis-Blatt, ART-0311, S. #refpage(<art-0311>)).
- [ ] Abschreiben: mindestens 2 Kopien an verschiedenen Orten (anderes Gebäude/anderer Haushalt).
- [ ] Verlesen: einmal im Monat/Rat vorlesen, damit die mündliche Schicht lebendig bleibt (ART-0293, S. #refpage(<art-0293>)).
- [ ] Einüben: jede Fertigkeit nach (12 Monate) wiederholen (ART-0035 (Band 1)).
- [ ] Prüfen: Wissen-Schicht jeden Winter erneuern; Prüferkreis am Prüfungs-Bogen.
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Recherche-Details (Fakten, Masse, Fehler-Tiefe)]]
#table(
  columns: 2,
  table.header([*Aspekt*], [*Detail (Recherche)*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Masse/Zeiten/Mengen], [4 Schichten; Verfalluhr 12 Monate ohne Wiederholung = Fähigkeit verfallen — konsistent ; Winter-Prüfung für Wissen; Halbjahr für Reserve .],
  [Typische Fehler], [nur mündlich überliefern → Wissen stirbt mit der Person ; nur eine Kopie an einem Ort → Totalverlust bei Brand/Diebstahl.],
  [Varianten Stadt/Land], [Land: Kopien in mehreren Gebäuden; Stadt: Kopien in mehreren Wohnungen/Haushalten; Verlesen in der Hausgemeinschaft statt Dorfversammlung.],
  [Fakten], [Vier Schichten der Bewahrung: 1. geschriebene Kopie, 2. verlesene mündliche Überlieferung, 3. eingeübte Praxis , 4. Vermächtnis . Abschriften in mehreren Hausha],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Übungsprotokoll (Verfalluhr 12 Monate)]]
#table(
  columns: 5,
  table.header([*Nr.*], [*Datum*], [*Dauer*], [*Fehler*], [*V / Verfall*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [1], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [2], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [3], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [4], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [5], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [6], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [7], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [8], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [9], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [10], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [11], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [12], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Randbedingungen (vor Ort ausfüllen)]]
#table(
  columns: 3,
  table.header([*Randbedingung*], [*Trifft zu*], [*Anmerkung*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Allein / in der Gruppe], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Stadt / Land], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Tag / Nacht], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Sommer / Winter], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Notizen zu ART-0286]]
#block(width: 100%, height: 6.5cm, stroke: 0.6pt + rgb("#8c8c8c"), inset: 6pt)[Platz für eigene Notizen zu diesem Artikel.]
#pagebreak(weak: true)
== ART-0287 — Wie bilde ich die Reserve (der Zehnte, aus voller Kammer)? <art-0287>
Eine Gruppen-Reserve bilden — _der Zehnte (10 %) der Erträge_ — die aus der _vollen Kammer_ gegeben wird, nie aus der Not, und die harte Zeiten und Gaben finanziert.
- Reserve-Behälter/-Ecke (dicht, trocken, hoch — wie haltbare Ware, ART-0309)
- Lager-Blatt (Bestand, Datum, Prüfer) am Amts-Blatt
- _10 % der Erträge_ (historischer Zehnt = 10 %) — aus der, als Projekt-Regel konsistent
- Winter-Rechnung als Planungsgrundlage: _100 stille Tage + 20–33 % Aufschlag_ (ART-0214), Verankerung gegen DGE-Referenzwerte (2.200 kcal/Pers./Tag Mittelwert)
- Prüfintervall: je Halbjahr, nach jeder Not sofort
+ Im Herbst nach der Ernte (Sept/Okt) den Zehnten der Erträge in die Reserve legen — aus voller Kammer (Mai-Aufgabe des Tausch-Jahrs: Zehnten gezählt und geliefert, Not-Lager gedreht).
+ Reserve getrennt führen (eigene Kammer/Ecke, eigenes Blatt) — nicht mit dem Haushaltsvorrat vermischen.
+ Entnahme nur mit Rat-Entscheid (ART-0305) — „nichts raus ohne Rat“.
+ Prüfung je Halbjahr und nach jeder Not: Bestand zählen, Blatt aktualisieren.
+ Not-Markt (bei Flut/Brand/Missernte) speist sich aus der Reserve — ohne Gewinn (ART-0302).
- _Land:_ Dorfrat verwaltet die Reserve (Lager-Blatt, Küche zeugt).
- _Stadt:_ Hausgemeinschaft — gemeinsamer Vorrat im kühlen Treppenhaus (ART-0209), Zehnte je Haushalt.
- _Klima:_ Winterreserve nach Winter-Rechnung (100 T + 20–33 %); Sommer: zusätzlich Wasser-Reserve (ART-0064).
#table(
  columns: 3,
  table.header([Fehler], [Folge], [Korrektur]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Erst in der Not „sparen“], [Reserve leer genau dann, wenn sie gebraucht wird], [im Herbst aus voller Kammer geben],
  [Reserve ohne Rat-Entscheid plündern], [Vertrauensbruch, keine Ordnung], [Entnahme nur mit Rat (ART-0305)],
  [Reserve mit Haushaltsvorrat vermischt], [unklar, was Reserve ist], [getrennte Kammer + eigenes Blatt],
)
Keine.
ART-0285, S. #refpage(<art-0285>) (Wert), ART-0302, S. #refpage(<art-0302>) (Tausch-Platz/Not-Markt), ART-0305, S. #refpage(<art-0305>) (Rat), ART-0308, S. #refpage(<art-0308>) (Ration im Herbst), ART-0309, S. #refpage(<art-0309>) (haltbare Ware), ART-0312, S. #refpage(<art-0312>) (Ämter)
Üben: im Mai und im November die Reserve zählen und das Lager-Blatt prüfen — Bestand und Blatt müssen übereinstimmen.
- _Zehnte:_ 10 % der Erträge als Gruppen-Reserve — aus voller Kammer, nie aus der Not.
- _Lager-Blatt:_ schriftlicher Nachweis über Bestand und Prüfungen der Reserve.
- _Not-Markt:_ Markt aus der Reserve bei Flut/Brand/Missernte — ohne Gewinn (ART-0302).
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Abbildungen]]
#grid(columns: (1fr, 1fr), column-gutter: 6pt, row-gutter: 5pt,
  figure(image("../illustrationen/art-0287-abb-1.svg", width: 100%), caption: [Abb. zu ART-0287 — ART-0287 · Abb. 1: Kammer mit Reserve-Ecke: der Zehnte aus voller Kammer, nie aus der Not, markiert und versiegelt (ART-0287).]),
  figure(image("../illustrationen/art-0287-abb-2.svg", width: 100%), caption: [Abb. zu ART-0287 — ART-0287 · Abb. 2: Zehnten ablegen: 10 % der Ernte in Säcke, beschriftet, datum (ART-0287).]))
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Kontroll-Checkliste]]
- [ ] Im Herbst nach der Ernte (Sept/Okt) den Zehnten der Erträge in die Reserve legen — aus voller Kammer (Mai-Aufg
- [ ] Reserve getrennt führen (eigene Kammer/Ecke, eigenes Blatt) — nicht mit dem Haushaltsvorrat vermischen.
- [ ] Entnahme nur mit Rat-Entscheid (ART-0305, S. #refpage(<art-0305>)) — „nichts raus ohne Rat“.
- [ ] Prüfung je Halbjahr und nach jeder Not: Bestand zählen, Blatt aktualisieren.
- [ ] Not-Markt (bei Flut/Brand/Missernte) speist sich aus der Reserve — ohne Gewinn (ART-0302, S. #refpage(<art-0302>)).
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Recherche-Details (Fakten, Masse, Fehler-Tiefe)]]
#table(
  columns: 2,
  table.header([*Aspekt*], [*Detail (Recherche)*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Masse/Zeiten/Mengen], [10 % der Erträge ; Winter-Rechnung: 100 stille Tage + 20–33 % Aufschlag ; Prüfintervall: halbjährlich + nach jeder Not .],
  [Typische Fehler], [erst in der Not „sparen“ → Reserve leer genau dann, wenn sie gebraucht wird ; Reserve ohne Rat-Entscheid plündern.],
  [Varianten Stadt/Land], [Land: Dorfrat verwaltet die Reserve ; Stadt: Hausgemeinschaft — gemeinsamer Vorrat im kühlen Treppenhaus , Zehnte je Haushalt.],
  [Fakten], [Der Zehnte der Erträge geht in die Reserve — aus voller Kammer, nie aus der Not; die Reserve dient harten Zeiten und Gaben . Im Herbst nach der Ernte in die Res],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Übungsprotokoll (Verfalluhr 12 Monate)]]
#table(
  columns: 5,
  table.header([*Nr.*], [*Datum*], [*Dauer*], [*Fehler*], [*V / Verfall*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [1], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [2], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [3], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [4], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [5], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [6], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [7], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [8], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [9], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [10], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [11], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [12], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Randbedingungen (vor Ort ausfüllen)]]
#table(
  columns: 3,
  table.header([*Randbedingung*], [*Trifft zu*], [*Anmerkung*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Allein / in der Gruppe], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Stadt / Land], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Tag / Nacht], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Sommer / Winter], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Notizen zu ART-0287]]
#block(width: 100%, height: 6.5cm, stroke: 0.6pt + rgb("#8c8c8c"), inset: 6pt)[Platz für eigene Notizen zu diesem Artikel.]
#pagebreak(weak: true)
== ART-0288 — Wie dokumentiere ich meinen Haushalt für Behörden und Versicherungen? <art-0288>
Haushalt und Vorsorge so dokumentieren, dass bei Behörden und Versicherungen nach einem Schadens-/Krisenfall nachvollziehbar ist, was vorhanden war und welche Vorsorge getroffen wurde — alles in Papierform, wasserdicht, ohne Strom lesbar.
- Wasserdichte Hülle/Box (oder laminierte Blätter) — Kopien von: Personalausweis/Reisepass, Versicherungsunterlagen, Impfpass, Medikamentenliste (Name/Dosis/Zeit — siehe ART-0301), ärztliche Kurzinfo (Chronik, Allergien), Notfallkontakte in Schriftform
- Vorsorge-Checkliste mit abgehakten Punkten + Datum (z. B. PDF-Export einer Online-Checkliste) als Nachweis der getroffenen Maßnahmen
- Zweite Kopie außerhalb des Hauses (Verwandte, anderer Stadtteil)
- Bargeld in kleinen Scheinen gehört in dieselbe Mappe (ART-0296)
+ Mappe zusammenstellen: Ausweis, Versicherung, Impfpass, Medikamentenliste, Notfallkontakte — alles kopiert.
+ Wasserdicht verpacken (Hülle/Box/Laminat); zweite Kopie extern deponieren.
+ Vorsorge-Checkliste führen: Datum, abgehakte Punkte, offene Punkte; bei jeder Übung/Ergänzung aktualisieren (ART-0035).
+ Im Ernstfall: Mappe griffbereit (Rucksack-Dokumenteblock, ART-0030); Behörden/Versicherung zeigen, was dokumentiert ist.
+ Nach dem Ereignis: Schäden dokumentieren (Fotos auf Speicherkarte + Notizen auf Papier mit Datum), Protokoll (ART-0011).
- _Stadt:_ zweite Kopie bei Verwandten im anderen Stadtteil (gleitende Erreichbarkeit); Digitalkopie auf USB-Stick in der wasserdichten Box.
- _Land:_ zweite Kopie im Nachbarhaus; Bankschließfach nur als Ergänzung (Öffnungszeiten können ausfallen).
- _Klima:_ Feuchtigkeit/Schimmel zerstört Papier → dicht, trocken, erhöht lagern.
#table(
  columns: 3,
  table.header([Fehler], [Folge], [Korrektur]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Dokumente nur digital (Cloud)], [bei Strom-/Netzausfall unlesbar], [Papier + wasserdicht + externe Kopie],
  [Keine Medikamentenliste], [im Stress falsche Gabe/Info an Helfer], [Liste mit Name/Dosis/Zeit (ART-0301)],
  [Checkliste nie aktualisiert], [Nachweis lückenhaft], [Datum + Unterschrift je Eintrag (ART-0035)],
)
Keine eigene Warnpflicht. Hinweis: Dokumentation ist Beweismittel, keine Rechtsberatung — bei Deckungsfragen Versicherung konsultieren.
ART-0030 (Band 1) (Notfallrucksack), ART-0035 (Band 1) (Protokoll), ART-0011 (Band 1) (24-h-Protokoll), ART-0296, S. #refpage(<art-0296>) (Bargeld), ART-0301, S. #refpage(<art-0301>) (Medikamente), ART-0236 (Band 8) (Insulin kühl), ART-0006 (Band 1) (Radio)
Üben: halbjährlich die Dokumentenmappe prüfen — vollständig, wasserdicht verpackt, zweite Kopie außerhalb des Hauses aktuell.
- _Dokumentenmappe:_ wasserdichte Mappe mit allen wichtigen Kopien, griffbereit im Rucksack.
- _Vorsorge-Checkliste:_ datierte Selbsteinschätzung als Nachweis getroffener Maßnahmen.
- _Zweitkopie extern:_ Kopie außerhalb des eigenen Hauses/Gebäudes.
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Abbildungen]]
#align(center)[#block(width: 10.5cm)[#figure(image("../illustrationen/art-0288-abb-1.svg", width: 100%), caption: [Abb. zu ART-0288 — ART-0288 · Abb. 1: Haushalt dokumentieren: Ordner mit Registern, Kopien an zwei Orten (ART-0288).])]]
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Kontroll-Checkliste]]
- [ ] Mappe zusammenstellen: Ausweis, Versicherung, Impfpass, Medikamentenliste, Notfallkontakte — alles kopiert.
- [ ] Wasserdicht verpacken (Hülle/Box/Laminat); zweite Kopie extern deponieren.
- [ ] Vorsorge-Checkliste führen: Datum, abgehakte Punkte, offene Punkte; bei jeder Übung/Ergänzung aktualisieren (A
- [ ] Im Ernstfall: Mappe griffbereit (Rucksack-Dokumenteblock, ART-0030 (Band 1)); Behörden/Versicherung zeigen, was dokumen
- [ ] Nach dem Ereignis: Schäden dokumentieren (Fotos auf Speicherkarte + Notizen auf Papier mit Datum), Protokoll (
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Recherche-Details (Fakten, Masse, Fehler-Tiefe)]]
#table(
  columns: 2,
  table.header([*Aspekt*], [*Detail (Recherche)*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Masse/Zeiten/Mengen], [keine; Vollständigkeit der Mappe ist das Kriterium .],
  [Typische Fehler], [Dokumente nur digital ; keine Kopie außerhalb des Hauses; Liste ohne Medikamenten-Dosierungen .],
  [Varianten Stadt/Land], [Stadt: wasserdichte Hülle/Box in der Wohnung + zweite Kopie bei Verwandten im anderen Stadtteil; Land: wasserdichter Behälter, ggf. zweite Kopie im Nachbarhaus;],
  [Fakten], [Im Blackout arbeiten Behörden/Versicherungen eingeschränkt; dokumentierte Vorsorge dient als Nachweis gegenüber Versicherungen und Behörden (K1). Kopien von Per],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Übungsprotokoll (Verfalluhr 12 Monate)]]
#table(
  columns: 5,
  table.header([*Nr.*], [*Datum*], [*Dauer*], [*Fehler*], [*V / Verfall*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [1], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [2], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [3], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [4], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [5], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [6], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [7], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [8], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [9], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [10], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [11], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [12], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Randbedingungen (vor Ort ausfüllen)]]
#table(
  columns: 3,
  table.header([*Randbedingung*], [*Trifft zu*], [*Anmerkung*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Allein / in der Gruppe], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Stadt / Land], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Tag / Nacht], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Sommer / Winter], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Notizen zu ART-0288]]
#block(width: 100%, height: 6.5cm, stroke: 0.6pt + rgb("#8c8c8c"), inset: 6pt)[Platz für eigene Notizen zu diesem Artikel.]
#pagebreak(weak: true)
== ART-0289 — Wie durchquere ich eine Furt sicher? <art-0289>
Eine Furt so prüfen und durchqueren, dass weder Strömung noch Kälte noch Dunkelheit zur tödlichen Falle werden — oder rechtzeitig umgehen/warten.
- Wanderstab (robust, kniehoch) — Prüfwerkzeug für Tiefe, Grund, Strömung
- Abwerfbare Last: Rucksack-Schnellverschlüsse geöffnet, Tragegurte offen, damit die Last im Wasser abgeworfen werden kann
- Grenzen: _Wasser nie über Kniehöhe mit Last_; nie im Dunkeln (Restlicht-1-h-Regel, ART-0123); kein Eis ohne Prüfung
- Wegzeiten (interne Weg-Tafel): Gezeiten-Furt an der Küste: _3 h Vorlauf_ planen; Moor-Steg: nie neben dem Steg, nie bei Nebel; Niedrigwasser (Sommer, früh morgens) ist leichter
+ _Vor dem Gang:_ Wetter den Berg hinauf lesen (Regen im Berg zieht die Flut nachmittags ins Flache); Furt je Tag neu prüfen, nie aus dem Gedächtnis; Ausstieg am anderen Ufer suchen, ehe der Eintritt gewagt wird.
+ _Prüfung:_ Stab-Tiefe an _3 Stellen_ messen (Tiefe, Grund, Strömung); zweifelhafte Stelle → Umgehung suchen.
+ _Im Wasser:_ Stab vor dem Fuß; nie quer zum Strom, sondern _schräg mit dem Strom_; Last abwerfbar tragen (Hand nicht am Körper festgebunden).
+ _Bei Steigen des Wassers:_ nicht kämpfen — zurückgehen oder harren; Umweg oder Warten.
+ _Nach der Durchquerung:_ nasse Kleidung wechseln/trocknen (ART-0133), Körper aufwärmen (ART-0114 — Zittern hört auf = Umschlag zur Unterkühlung).
- _Land:_ Niedrigwasser (Sommer, früh morgens) leichter; Hochwasser: warten oder Umweg; Gezeiten-Furt: 3 h Vorlauf, nie bei auflaufendem Wasser.
- _Stadt:_ Unterführung bei Regen meiden (Überflutungsgefahr); beleuchtete Brücken bevorzugen.
- _Klima/Winter:_ Eis nie ohne Prüfung betreten (ART-0021); nasse Furt im Dunkeln verboten.
#table(
  columns: 3,
  table.header([Fehler], [Folge], [Korrektur]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Allein durchschwimmen „schaffe ich“], [Ertrinken, Hypothermie — häufigste vermeidbare Todesursache auf dem Marsch], [Stab an 3 Stellen, nie allein (ART-0303), nie über Knie mit Last],
  [Furt aus dem Gedächtnis des Vortags], [gestrige Tiefe gilt nicht mehr], [je Tag neu prüfen, Wetter bergwärts lesen],
  [Last fest am Körper], [wird mitgerissen], [Schnellverschlüsse offen, Last abwerfbar],
  [Furt im Dunkeln], [kein Grund, keine Strömung erkennbar], [nie im Dunkeln (Restlicht-1-h, ART-0123)],
)
#warnrahmen()[siehe oben — Warnrahmen + Warngrafik Pflicht (Katalog §5). Verboten: über Knie mit Last, bei Eis ohne Prüfung, nasse Furt im Dunkeln.]
ART-0123 (Band 4) (Lager bei Dunkelheit/Restlicht), ART-0133 (Band 4) (nasse Kleidung trocknen), ART-0114 (Band 4) (Kältegefahr), ART-0303, S. #refpage(<art-0303>) (Trupp), ART-0067 (Band 2) (Oberflächenwasser lesen), ART-0020 (Band 1) (Treffpunkte)
Üben: im März, vor der Furt-Saison, die Wege des Umkreises neu gehen und eine Furt bei Niedrigwasser mit dem Stab an drei Stellen prüfen.
- _Furt:_ seichte Durchwatungsstelle eines Gewässers — „das Wasser lügt bei Stille: der Stab fragt zuerst“.
- _Stab-Prüfung:_ 3 Stellen messen (Tiefe, Grund, Strömung) vor jedem Gang.
- _Abwerfbare Last:_ Rucksack so tragen, dass er im Wasser sofort abgeworfen werden kann.
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Kontroll-Checkliste]]
- [ ] Vor dem Gang: Wetter den Berg hinauf lesen (Regen im Berg zieht die Flut nachmittags ins Flache); Furt je Tag 
- [ ] Prüfung: Stab-Tiefe an 3 Stellen messen (Tiefe, Grund, Strömung); zweifelhafte Stelle → Umgehung suchen.
- [ ] Im Wasser: Stab vor dem Fuß; nie quer zum Strom, sondern schräg mit dem Strom; Last abwerfbar tragen (Hand nic
- [ ] Bei Steigen des Wassers: nicht kämpfen — zurückgehen oder harren; Umweg oder Warten.
- [ ] Nach der Durchquerung: nasse Kleidung wechseln/trocknen (ART-0133 (Band 4)), Körper aufwärmen (ART-0114 (Band 4) — Zittern hört 
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Recherche-Details (Fakten, Masse, Fehler-Tiefe)]]
#table(
  columns: 2,
  table.header([*Aspekt*], [*Detail (Recherche)*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Masse/Zeiten/Mengen], [3 Prüfstellen mit dem Stab; Grenze: Kniehöhe mit Last; Gezeiten-Furt: 3 h Vorlauf .],
  [Typische Fehler], [allein durchschwimmen „schaffe ich“ → Ertrinken/Hypothermie, häufigste vermeidbare Todesursache auf dem Marsch ; Furt aus dem Gedächtnis des Vortags; Last fest ],
  [Varianten Stadt/Land], [Land: Niedrigwasser leichter; Hochwasser: warten oder Umweg; Stadt: Unterführung bei Regen meiden .],
  [Fakten], [WARNRAHMEN (): Stab an 3 Stellen prüfen , nie über Kniehöhe mit Last durchwaten, nie im Dunkeln ; Umgehung suchen, wenn eine Stelle zweifelhaft. (29cd074c \#146)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Übungsprotokoll (Verfalluhr 12 Monate)]]
#table(
  columns: 5,
  table.header([*Nr.*], [*Datum*], [*Dauer*], [*Fehler*], [*V / Verfall*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [1], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [2], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [3], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [4], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [5], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [6], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [7], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [8], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [9], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [10], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [11], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [12], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Randbedingungen (vor Ort ausfüllen)]]
#table(
  columns: 3,
  table.header([*Randbedingung*], [*Trifft zu*], [*Anmerkung*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Allein / in der Gruppe], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Stadt / Land], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Tag / Nacht], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Sommer / Winter], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Notizen zu ART-0289]]
#block(width: 100%, height: 6.5cm, stroke: 0.6pt + rgb("#8c8c8c"), inset: 6pt)[Platz für eigene Notizen zu diesem Artikel.]
#pagebreak(weak: true)
== ART-0290 — Wie empfange ich Gäste und Fremde (nie allein)? <art-0290>
Gäste und Fremde in der Krise empfangen, ohne sich oder die Gruppe zu gefährden — und ohne das Gast-Recht zu verweigern: nie allein empfangen, Verdacht laut aussprechen, Mitgebrachtes prüfen, Waffen ablegen lassen.
- Zwei Gastgeber bei der ersten Begegnung (nie allein empfangen, nie allein lassen)
- Gast-Feuer im Sichtkreis des Hofes; Nacht im \*\*Gast-Raum, nicht im Familien-Raum
- Waffenablage am Eingang (siehe ART-0300)
- Amts-Blatt für Verdachtsmeldungen (ART-0294/ART-0307); Wache des Hauses informieren (ART-0312)
- Gast-Recht (historischer Vergleich): _drei Tage Herberge gegen lautes Wort_ — gilt beiden Seiten
+ _Begegnung:_ zwei Erwachsene, höflich aber wachsam; Gast-Feuer im Sichtkreis; nie allein empfangen.
+ _Prüfen, was mitgebracht wird:_ Waren (haltbar? ART-0309), Werkzeug ; Waffen ablegen lassen am Eingang (ART-0300).
+ _Fragen zählen:_ Wer nach Vorräten fragt, bevor er nach Arbeit fragt, hat die Frage beantwortet — notieren.
+ _Verdacht laut aussprechen:_ in der Gruppe (geregeltes Gespräch, ART-0012) und vor dem Rat (ART-0305) benennen; am Amts-Blatt zeichnen.
+ _Unterkunft:_ Gast-Raum, Nacht getrennt; Verpflegung nach Ehren-Platz-Regel (ART-0295).
+ _Abschied:_ geuchtet, mit Brot und Wort; Weg markieren (ART-0303).
- _Stadt:_ Wohnungstür, Gegensprechanlage; Waffenablage an der Tür; Gast im gemeinsamen Raum, nicht in der Wohnung übernachten lassen, wo die Familie schläft.
- _Land:_ Hoftor, Hund; Gast-Raum getrennt (Scheune/Stube); Nachtwache (ART-0028).
- _Klima:_ Winter: Gast wärmstens unterbringen (ART-0114); Sommer: Wasser reichen.
#table(
  columns: 3,
  table.header([Fehler], [Folge], [Korrektur]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Allein empfangen], [Übergriff, Diebstahl, Gewalt], [zwei Gastgeber (dieser Artikel)],
  [Mitgebrachte Waffen ignorieren], [Bedrohung der Gruppe], [Waffenablage am Eingang (ART-0300)],
  [Nach Kleidung verurteilen], [„Kunde ist keine Kleidung“ — Fehlurteil], [Verdacht an Taten/Worten, nicht am Äußeren (Feuerprobe-Frage 21)],
  [Gast-Recht aus Angst verweigern], [Bruch der Straßen-Ethik, Eskalation], [Zeile trennt Gast vom Räuber; Angst ist kein Zeuge],
  [Selbstjustiz am Verdacht], [strafbar, Blutrache-Spirale], [Rat nach Klage und Zeugen (ART-0305)],
)
#warnrahmen(id: "warn-art-0290", )[siehe oben. §§ 34/35/123 StGB; —.]
ART-0305, S. #refpage(<art-0305>) (Rat & Streit, § 32 StGB), ART-0300, S. #refpage(<art-0300>) (Zeug-Haus/Waffenablage), ART-0295, S. #refpage(<art-0295>) (Mahl/Ehrenplatz), ART-0012 (Band 1) (geregeltes Gespräch), ART-0132 (Band 4) (Eigentum im Notstand), ART-0303, S. #refpage(<art-0303>) (Trupp)
Üben: einmal im Jahr (Juni) das Gast-Recht üben — Empfang mit zwei Gastgebern, Waffenablage am Eingang, Gast am Feuer.
- _Gast-Recht:_ ältestes Gesetz der Straße — Herberge gegen lautes Wort; gilt beiden Seiten (3 Tage).
- _Kunde:_ das Wissen über eine Person aus Wort und Tat — Kleidung ist keine Kunde.
- _Waffenablage:_ mitgebrachtes am Eingang abgeben/lagern (ART-0300).
- _Selbstjustiz:_ richten ohne Rat — strafbar (ART-0305).
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Kontroll-Checkliste]]
- [ ] Begegnung: zwei Erwachsene, höflich aber wachsam; Gast-Feuer im Sichtkreis; nie allein empfangen.
- [ ] Prüfen, was mitgebracht wird: Waren (haltbar? ART-0309, S. #refpage(<art-0309>)), Werkzeug ; Waffen ablegen lassen am Eingang (ART-0300, S. #refpage(<art-0300>)
- [ ] Fragen zählen: Wer nach Vorräten fragt, bevor er nach Arbeit fragt, hat die Frage beantwortet — notieren.
- [ ] Verdacht laut aussprechen: in der Gruppe (geregeltes Gespräch, ART-0012 (Band 1)) und vor dem Rat (ART-0305, S. #refpage(<art-0305>)) benennen; 
- [ ] Unterkunft: Gast-Raum, Nacht getrennt; Verpflegung nach Ehren-Platz-Regel (ART-0295, S. #refpage(<art-0295>)).
- [ ] Abschied: geuchtet, mit Brot und Wort; Weg markieren (ART-0303, S. #refpage(<art-0303>)).
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Recherche-Details (Fakten, Masse, Fehler-Tiefe)]]
#table(
  columns: 2,
  table.header([*Aspekt*], [*Detail (Recherche)*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Masse/Zeiten/Mengen], [2 Gastgeber; 3 Tage Herberge .],
  [Typische Fehler], [allein empfangen oder mitgebrachte Waffen ignorieren → Übergriff, Diebstahl, Gewalt ; nach Kleidung verurteilen — „Kunde ist keine Kleidung" .],
  [Varianten Stadt/Land], [Stadt: Wohnungstür, Gegensprechanlage, Waffenablage an der Tür; Land: Hoftor, Hund, Gast-Raum getrennt — immer höflich, aber wachsam.],
  [Fakten], [1. Nie allein empfangen — zwei Gastgeber ; 2. Verdacht laut aussprechen ; 3. Selbstjustiz verboten ; 4. prüfen, was mitgebracht wird — Waffen ablegen lassen am ],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Übungsprotokoll (Verfalluhr 12 Monate)]]
#table(
  columns: 5,
  table.header([*Nr.*], [*Datum*], [*Dauer*], [*Fehler*], [*V / Verfall*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [1], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [2], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [3], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [4], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [5], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [6], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [7], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [8], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [9], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [10], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [11], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [12], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Randbedingungen (vor Ort ausfüllen)]]
#table(
  columns: 3,
  table.header([*Randbedingung*], [*Trifft zu*], [*Anmerkung*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Allein / in der Gruppe], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Stadt / Land], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Tag / Nacht], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Sommer / Winter], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Notizen zu ART-0290]]
#block(width: 100%, height: 6.5cm, stroke: 0.6pt + rgb("#8c8c8c"), inset: 6pt)[Platz für eigene Notizen zu diesem Artikel.]
#pagebreak(weak: true)
== ART-0291 — Wie führe ich den Kalender des Dorfes? <art-0291>
Arbeit, Feste, Rationen und Übungen des Dorfes/Haushalts in einem _schriftlichen Kalender_ takten — Papier statt Netz, damit Termine auch ohne Strom verbindlich bleiben.
- Kalenderblatt/Aushang (Papier, großflächig lesbar) — Fest- und Arbeitstermine schriftlich (ART-0020)
- Tausch-Jahr: _12 Monats-Aufgaben_ mit Blatt + Zeuge (interne Übungspraxis): Jan Schulden verlesen/Neujahrs-Rat · Feb Werkstatt-Prüfung (2 Zeugen) · Mär Wege neu gehen/Atlas berichtigen · Apr Maße weihen (Bürger-Maß am Ring) · Mai Zehnten geliefert · Jun Gast-Recht geübt · Jul Stunden-Tafel gerechnet · Aug Rüst-Blatt vor Jahres-Markt · Sep Jahres-Markt mit Zeugen · Okt Feuerprobe des Monats · Nov Zeug-Haus Winter-Prüfung · Dez Jahresgedenken + Vermächtnis erneuert
- Feuerprobe: _1 Band je Monat_ im Ring (ART-0292); Quartal: Übungen (ART-0033)
+ Kalender aufhängen (Gemeindehaus/Treppenhaus); alle Termine schriftlich mit Datum.
+ Monatsaufgabe des Tausch-Jahrs festhalten (Blatt + Zeuge).
+ Quartalsweise Übungen eintragen (ART-0033).
+ Herbst: Winter-Ration setzen (ART-0308).
+ Monatlich: Feuerprobe des Monats-Bandes (ART-0292).
- _Stadt:_ Haushaltskalender + Aushang im Treppenhaus; Feste in der Wohnungsküche/im Hof.
- _Land:_ Dorfkalender am Anschlag im Gemeindehaus; Feste im Saal/auf dem Dorfanger.
- _Klima/Jahreszeit:_ Termine an Saison koppeln (vor der Saat, vor dem Sturm, am Ernte-Beginn — siehe).
#table(
  columns: 3,
  table.header([Fehler], [Folge], [Korrektur]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Kein Kalender], [alles „auf den letzten Drücker“, Chaos in der harten Zeit], [schriftlicher Kalender (dieser Artikel)],
  [Termine nur mündlich], [bei Netzausfall unprüfbar, Streit], [Papier statt Netz (ART-0020)],
  [Übungen nicht eingetragen], [Wissen verrostet (ART-0035)], [Quartals-Übungen fest im Kalender],
)
Keine.
ART-0033 (Band 1) (Jahres-Übungsprogramm), ART-0035 (Band 1), ART-0292, S. #refpage(<art-0292>) (Feuerprobe), ART-0293, S. #refpage(<art-0293>) (Gedenken), ART-0298, S. #refpage(<art-0298>) (Feste/Rituale), ART-0308, S. #refpage(<art-0308>) (Ration), ART-0154 (Band 5) (Pflanzen-Kalender)
Üben: monatlich die jeweilige Monatsaufgabe erledigen und stichprobenartig prüfen, ob alle Termine schriftlich im Kalender stehen.
- _Dorf-Kalender:_ schriftlicher Jahresplan mit Festen, Arbeiten, Rationen, Übungen.
- _Tausch-Jahr:_ die 12 Monats-Aufgaben am eigenen Dorf.
- _Prüf-Kreis:_ der Kreis, der die wiederkehrenden Prüfungen (Feuerprobe) durchführt.
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Kontroll-Checkliste]]
- [ ] Kalender aufhängen (Gemeindehaus/Treppenhaus); alle Termine schriftlich mit Datum.
- [ ] Monatsaufgabe des Tausch-Jahrs festhalten (Blatt + Zeuge).
- [ ] Quartalsweise Übungen eintragen (ART-0033 (Band 1)).
- [ ] Herbst: Winter-Ration setzen (ART-0308, S. #refpage(<art-0308>)).
- [ ] Monatlich: Feuerprobe des Monats-Bandes (ART-0292, S. #refpage(<art-0292>)).
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Recherche-Details (Fakten, Masse, Fehler-Tiefe)]]
#table(
  columns: 2,
  table.header([*Aspekt*], [*Detail (Recherche)*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Masse/Zeiten/Mengen], [12 Monats-Aufgaben; 1 Band je Monat in der Feuerprobe; Quartals-Übungen .],
  [Typische Fehler], [kein Kalender → alles „auf den letzten Drücker“, Chaos in der harten Zeit ; Termine nur mündlich .],
  [Varianten Stadt/Land], [Land: Dorfkalender am Anschlag/Blatt im Gemeindehaus; Stadt: Haushaltskalender + Aushang im Treppenhaus; Feste in der Wohnungsküche/Hof.],
  [Fakten], [Fest- und Arbeitstermine schriftlich führen ; konsistent mit und . Tausch-Jahr: 12 Monats-Aufgaben mit Blatt + Zeuge ; Mai: Zehnten geliefert; Juni: Gast-Recht ],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Übungsprotokoll (Verfalluhr 12 Monate)]]
#table(
  columns: 5,
  table.header([*Nr.*], [*Datum*], [*Dauer*], [*Fehler*], [*V / Verfall*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [1], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [2], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [3], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [4], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [5], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [6], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [7], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [8], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [9], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [10], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [11], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [12], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Randbedingungen (vor Ort ausfüllen)]]
#table(
  columns: 3,
  table.header([*Randbedingung*], [*Trifft zu*], [*Anmerkung*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Allein / in der Gruppe], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Stadt / Land], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Tag / Nacht], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Sommer / Winter], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Notizen zu ART-0291]]
#block(width: 100%, height: 6.5cm, stroke: 0.6pt + rgb("#8c8c8c"), inset: 6pt)[Platz für eigene Notizen zu diesem Artikel.]
#pagebreak(weak: true)
== ART-0292 — Wie führe ich die Feuerprobe des Kompendiums durch (Ring der Reihe)? <art-0292>
Das ganze Kompendium im _Ring der Reihe_ prüfen: jedes –9 wird abgefragt; wer eine Frage nicht beantworten kann, übt nach — so bleibt das Wissen abrufbar.
- Fragenkatalog (Anhang Feuerprobe): _32 Fragen_, Kernfragen pro Band (Anhang): Regel der Drei/STOPP/Traglast Abkochen 1 min (ab 2.000 m: 3 min), Latrine ≥ 30 m, Chlor-Dosis; Feuer-Abstände 30 cm/2–3 m/4–6 m, CO-Regel; Lagerplatz, Bodenisolation; „keine Mahlzeit ohne Namen + zweites Merkmal“, Pilze nie roh, Beinwell nur äußerlich; Kastenfalle, Jagdschein, Durchgaren ≥ 71 °C, Muscheln nur amtlich überwacht; B7 Druckkocher 116–121 °C, pH ≤ 4,6, Dörr-Preheat 71 °C, Streusalz nie; B8 Risikowunde + Booster, kein induziertes Erbrechen, ORS, Weidenrinde nicht \< 16 J; B9 Flucht 45°, Anlassen, Leinöl-Lappen
- Prüfungs-Bogen: pro Band ein Block, bestanden/Übungspflicht, Urteil + Zeugen/Datum
- Erfolgskriterium: _≥ 80 % der Fragen korrekt_; Lücken als Übungspflicht notiert (ART-0035)
+ Termin setzen: halbjährlich, vor dem Winter, nach jeder Änderung des Kompendiums (ART-0306).
+ Ring der Reihe: –9 der Reihe nach abfragen, „prüft sich im Führen“ (Tausch am Blatt, Amt übernommen, Kreis geplant).
+ Jede unbeantwortete Frage notieren → Übungspflicht (ART-0035).
+ Ergebnis im Protokoll (ART-0011), Zeugen unterschreiben (ART-0307).
+ Lücken schließen: Übung im Monatsrhythmus bis bestanden.
- _Stadt:_ Nachbarschaftsrunde in der Wohnung/im Treppenhaus; Land: Rat im Gemeindehaus. Ablauf identisch.
- _Klima:_ vor dem Winter (Heiz-/Vorratsfragen), nach jeder Änderung.
#table(
  columns: 3,
  table.header([Fehler], [Folge], [Korrektur]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Nie prüfen], [Wissen verrostet — im Ernstfall tödliche Fehlhandlungen], [halbjährlich + nach Änderung (dieser Artikel)],
  [Prüfung als Wettkampf inszenieren], [Scham verhindert Teilnahme], [Bestandsaufnahme, Wiederholung normal],
  [Lücken nicht notieren], [keine Übungspflicht, Lücke bleibt], [Protokoll + (ART-0035)],
)
Keine eigene Warnpflicht — der Fragenkatalog verweist auf alle warnpflichtigen Kernregeln (…) der Bände.
ART-0035 (Band 1) , ART-0033 (Band 1) (Jahresplan), ART-0011 (Band 1) (Protokoll), ART-0304, S. #refpage(<art-0304>) (Werkstatt-Prüfung), ART-0306, S. #refpage(<art-0306>) (Reihe schließen), ART-0307, S. #refpage(<art-0307>) (Zeugen)
Üben: halbjährlich die Feuerprobe im Ring der Reihe — alle Bände des Kompendiums abfragen; Ziel: mindestens 80 % der Kernfragen korrekt.
- _Ring der Reihe:_ die Prüfung aller Bände 1–9 in fester Reihenfolge.
- _Feuerprobe:_ bestanden, wenn das Wissen im Ring abrufbar ist — sonst Übungspflicht.
- _Prüfungs-Bogen:_ Protokollbogen mit Urteil + Zeugen je Band.
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Kontroll-Checkliste]]
- [ ] Termin setzen: halbjährlich, vor dem Winter, nach jeder Änderung des Kompendiums (ART-0306, S. #refpage(<art-0306>)).
- [ ] Ring der Reihe: –9 der Reihe nach abfragen, „prüft sich im Führen“ (Tausch am Blatt, Amt übernommen, Kreis gep
- [ ] Jede unbeantwortete Frage notieren → Übungspflicht (ART-0035 (Band 1)).
- [ ] Ergebnis im Protokoll (ART-0011 (Band 1)), Zeugen unterschreiben (ART-0307, S. #refpage(<art-0307>)).
- [ ] Lücken schließen: Übung im Monatsrhythmus bis bestanden.
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Recherche-Details (Fakten, Masse, Fehler-Tiefe)]]
#table(
  columns: 2,
  table.header([*Aspekt*], [*Detail (Recherche)*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Masse/Zeiten/Mengen], [32 Fragen ; 9 Bände im Ring + „prüft sich im Führen“; Erfolg ≥ 80 % ; 2× jährlich + nach jeder Änderung; Verfalluhr 12 Monate.],
  [Typische Fehler], [nie prüfen → Wissen verrostet, im Ernstfall tödliche Fehlhandlungen ; Prüfung als Wettkampf inszenieren .],
  [Varianten Stadt/Land], [gleich; Stadt: Nachbarschaftsrunde in der Wohnung; Land: Rat im Gemeindehaus.],
  [Fakten], [Die Feuerprobe prüft alle Bände 1–9 im Ring der Reihe: jedes abgefragt ; wer eine Frage nicht beantworten kann, übt nach ; Ergebnis im Protokoll . Rhythmus: hal],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Übungsprotokoll (Verfalluhr 12 Monate)]]
#table(
  columns: 5,
  table.header([*Nr.*], [*Datum*], [*Dauer*], [*Fehler*], [*V / Verfall*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [1], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [2], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [3], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [4], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [5], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [6], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [7], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [8], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [9], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [10], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [11], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [12], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Randbedingungen (vor Ort ausfüllen)]]
#table(
  columns: 3,
  table.header([*Randbedingung*], [*Trifft zu*], [*Anmerkung*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Allein / in der Gruppe], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Stadt / Land], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Tag / Nacht], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Sommer / Winter], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Notizen zu ART-0292]]
#block(width: 100%, height: 6.5cm, stroke: 0.6pt + rgb("#8c8c8c"), inset: 6pt)[Platz für eigene Notizen zu diesem Artikel.]
#pagebreak(weak: true)
== ART-0293 — Wie gedenke ich der Verstorbenen (Vermächtnis verlesen)? <art-0293>
Der Verstorbenen gedenken und ihr Vermächtnis _verlesen_ — mündlich und schriftlich, damit Werte und Wissen der Gruppe erhalten bleiben (Teil der Resilienz).
- Drei Gedenk-Blätter: Tausch-Blatt, Amts-Blatt, Vermächtnis-Blatt
- Namensliste der Verstorbenen (am Amts-Blatt)
- Vermächtnis-Blatt des Verstorbenen (ART-0311), wenn vorhanden
- Anlässe: Jahrestag, Beerdigung, Feuerprobe (ART-0292); _Dezember: Jahresgedenken_ mit Verlesung der Namen, Vermächtnis erneuert (Tausch-Jahr)
+ Namen der Verstorbenen am Amts-Blatt führen, mit Datum.
+ Vermächtnis-Blatt des Verstorbenen vorlesen (geschrieben + verlesen, ART-0311).
+ Zum Anlass (Jahrestag/Beerdigung/Feuerprobe) gedenken: kurze Rede, Verlesen, Stille.
+ Dezember: Jahresgedenken — alle Namen des Jahres verlesen, Vermächtnis erneuern, neues Jahr planen.
+ Protokoll: Gedenken im Protokoll vermerken (ART-0011/ART-0035).
- _Stadt:_ Hausgemeinschaft liest im Treppenhaus/in der Wohnung; Land: Rat verliest vor der Gemeinde.
- _Klima:_ Winter (Dezember) am Jahres-Ende; Sommer: Beerdigung/Gedenken am Grab.
#table(
  columns: 3,
  table.header([Fehler], [Folge], [Korrektur]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Nicht gedenken], [Werte gehen verloren, Gruppe verliert Zusammenhalt], [fester Anlass + Verlesung (dieser Artikel)],
  [Nur mündlich gedenken, nichts verlesen], [Vermächtnis unauffindbar], [Vermächtnis-Blatt schriftlich (ART-0311)],
  [Namen nicht geführt], [Vergessene Tote], [Amts-Blatt mit Namen + Datum],
)
Keine.
ART-0311, S. #refpage(<art-0311>) (Vermächtnis), ART-0286, S. #refpage(<art-0286>) (vier Schichten), ART-0292, S. #refpage(<art-0292>) (Feuerprobe), ART-0291, S. #refpage(<art-0291>) (Kalender), ART-0295, S. #refpage(<art-0295>) (Mahl), ART-0224 (Band 8) (Sterbende begleiten)
Üben: einmal jährlich im Dezember das Jahresgedenken abhalten — Namen verlesen, Vermächtnis erneuern.
- _Gedenken:_ Verlesung der Namen + Vermächtnis zum Ehrentag — mündlich und schriftlich.
- _Jahresgedenken:_ December-Termin des Tausch-Jahrs.
- _Vermächtnis:_ letzte schriftliche + mündliche Weitergabe des Wissenden (ART-0311).
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Abbildungen]]
#align(center)[#block(width: 10.5cm)[#figure(image("../illustrationen/art-0293-abb-1.svg", width: 100%), caption: [Abb. zu ART-0293 — ART-0293 · Abb. 1: Gedenken an Verstorbene: kleiner Tisch, Kerze, Foto, Verlesen des Namens – würdevoll und kurz (ART-0293).])]]
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Kontroll-Checkliste]]
- [ ] Namen der Verstorbenen am Amts-Blatt führen, mit Datum.
- [ ] Vermächtnis-Blatt des Verstorbenen vorlesen (geschrieben + verlesen, ART-0311, S. #refpage(<art-0311>)).
- [ ] Zum Anlass (Jahrestag/Beerdigung/Feuerprobe) gedenken: kurze Rede, Verlesen, Stille.
- [ ] Dezember: Jahresgedenken — alle Namen des Jahres verlesen, Vermächtnis erneuern, neues Jahr planen.
- [ ] Protokoll: Gedenken im Protokoll vermerken (ART-0011 (Band 1)/ART-0035 (Band 1)).
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Recherche-Details (Fakten, Masse, Fehler-Tiefe)]]
#table(
  columns: 2,
  table.header([*Aspekt*], [*Detail (Recherche)*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Masse/Zeiten/Mengen], [jährlich ; 3 Gedenk-Blätter.],
  [Typische Fehler], [nicht gedenken → Werte gehen verloren, Gruppe verliert Zusammenhalt .],
  [Varianten Stadt/Land], [Stadt: Hausgemeinschaft liest im Treppenhaus/Wohnung; Land: Rat liest vor der Gemeinde.],
  [Fakten], [Vermächtnis wird verlesen — mündlich und schriftlich ; Gedenken ehrt die Toten und überliefert Werte — Teil der Resilienz der Gruppe. Anlässe: Jahrestag, Beerdi],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Übungsprotokoll (Verfalluhr 12 Monate)]]
#table(
  columns: 5,
  table.header([*Nr.*], [*Datum*], [*Dauer*], [*Fehler*], [*V / Verfall*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [1], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [2], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [3], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [4], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [5], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [6], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [7], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [8], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [9], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [10], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [11], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [12], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Randbedingungen (vor Ort ausfüllen)]]
#table(
  columns: 3,
  table.header([*Randbedingung*], [*Trifft zu*], [*Anmerkung*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Allein / in der Gruppe], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Stadt / Land], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Tag / Nacht], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Sommer / Winter], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Notizen zu ART-0293]]
#block(width: 100%, height: 6.5cm, stroke: 0.6pt + rgb("#8c8c8c"), inset: 6pt)[Platz für eigene Notizen zu diesem Artikel.]
#pagebreak(weak: true)
== ART-0294 — Wie gehe ich mit Schuld und Geschenk um (Gabe nie gemahnt)? <art-0294>
Gabe und Schuld sozial sauber trennen: die _Gabe wird nie gemahnt_ — eine Gabe bleibt Gabe; die _Schuld_ ist eine vereinbarte Leistung mit Frist, schriftlich am Blatt. Das hält Kooperation stabil.
- Amts-Blatt: Zeile je Schuld/Gabe mit Datum + Frist + Zeugen
- Beispiele: Schuld — Nachbar W. schuldet Haus K. einen Sack Mehl, Frist Herbst, _ohne Mahnung_; Gabe — Haus K. gab der alten Witwe zwei Stunden Holz, \*\*keine Frist, die Gabe kehrt nie
- Wort-Kunde: Gabe = das Gegebene ohne Rechnung; Schuld = die Gabe mit Gedächtnis — steht mit Frist am Blatt und kehrt ohne Mahnung
+ Gabe geben: benennen („ich gebe…“), ans Amts-Blatt, _nie mahnen_.
+ Schuld vereinbaren: laut benennen, bevor sie lastet; Datum + Frist am Blatt; zwei Zeugen (ART-0307).
+ Frist verstreichen lassen: ohne Mahnung; bei Verzug im Rat besprechen (ART-0305), nicht selbst eintreiben.
+ In der Krise: Gaben statt Schulden bevorzugen.
- _Stadt/Land:_ gleich (Nachbarschaft); in der Krise: Gaben bevorzugen.
- _Klima:_ harte Zeit (Winter): Gaben statt Schulden (ART-0308).
#table(
  columns: 3,
  table.header([Fehler], [Folge], [Korrektur]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Gabe mahnen], [Vertrauensbruch — Gaben versiegen, niemand hilft mehr freiwillig], [Gabe nie mahnen (dieser Artikel)],
  [Gabe ohne Blatt gegeben], [Dank kennt keine Adresse — Nachbarschaft sieht nicht, wer gab], [Gabe benennen + ans Amts-Blatt],
  [Schuld still getragen statt benannt], [verdirbt die Nachbarschaft beim ersten Streit], [Schuld laut benennen, mit Datum am Blatt],
)
Keine.
ART-0307, S. #refpage(<art-0307>) (Vertrag: 2 Zeugen + Frist), ART-0285, S. #refpage(<art-0285>) (Wert-Korridor), ART-0295, S. #refpage(<art-0295>) (Mahl), ART-0305, S. #refpage(<art-0305>) (Rat), ART-0311, S. #refpage(<art-0311>) (Vermächtnis)
Üben: einmal im Jahr zum Neujahrstreffen die Schulden verlesen und die Gaben benennen — ohne Mahnung.
- _Gabe:_ das Gegebene ohne Rechnung — wird benannt, gegeben und nie gemahnt.
- _Schuld:_ vereinbarte Leistung mit Frist am Blatt — kehrt ohne Mahnung.
- _Amts-Blatt:_ das Blatt des Hauses/Dorfes mit allen Schuld-/Gabe-/Amts-Zeilen.
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Kontroll-Checkliste]]
- [ ] Gabe geben: benennen („ich gebe…“), ans Amts-Blatt, nie mahnen.
- [ ] Schuld vereinbaren: laut benennen, bevor sie lastet; Datum + Frist am Blatt; zwei Zeugen (ART-0307, S. #refpage(<art-0307>)).
- [ ] Frist verstreichen lassen: ohne Mahnung; bei Verzug im Rat besprechen (ART-0305, S. #refpage(<art-0305>)), nicht selbst eintreiben.
- [ ] In der Krise: Gaben statt Schulden bevorzugen.
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Recherche-Details (Fakten, Masse, Fehler-Tiefe)]]
#table(
  columns: 2,
  table.header([*Aspekt*], [*Detail (Recherche)*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Masse/Zeiten/Mengen], [Schuld immer mit Datum + Frist am Blatt; Gabe ohne Frist.],
  [Typische Fehler], [Gabe mahnen → Gaben versiegen, niemand hilft mehr freiwillig .],
  [Varianten Stadt/Land], [gleich ; in der Krise: Gaben statt Schulden bevorzugen.],
  [Fakten], [Gabe nie mahnen — eine Gabe bleibt Gabe; Schuld = vereinbarte Leistung mit Frist, schriftlich am Blatt . BAUSTEIN: „Ein Geschenk, das gemahnt wird, ist eine Rec],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Übungsprotokoll (Verfalluhr 12 Monate)]]
#table(
  columns: 5,
  table.header([*Nr.*], [*Datum*], [*Dauer*], [*Fehler*], [*V / Verfall*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [1], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [2], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [3], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [4], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [5], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [6], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [7], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [8], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [9], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [10], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [11], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [12], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Randbedingungen (vor Ort ausfüllen)]]
#table(
  columns: 3,
  table.header([*Randbedingung*], [*Trifft zu*], [*Anmerkung*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Allein / in der Gruppe], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Stadt / Land], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Tag / Nacht], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Sommer / Winter], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Notizen zu ART-0294]]
#block(width: 100%, height: 6.5cm, stroke: 0.6pt + rgb("#8c8c8c"), inset: 6pt)[Platz für eigene Notizen zu diesem Artikel.]
#pagebreak(weak: true)
== ART-0295 — Wie gestalte ich das gemeinsame Mahl (Ehren-Platz-Regel)? <art-0295>
Das gemeinsame Mahl als soziales Kapital gestalten: Gäste sitzen auf dem _Ehrenplatz_ (wärmster/sicherster Platz, beste Portion), der Gastgeber isst zuletzt — das signalisiert Großzügigkeit und Schutz.
- Ein Ehrenplatz je Mahl (wärmster/sicherster Platz am Tisch/am Feuer)
- Beste Portion für den Gast; Gastgeber isst zuletzt
- Feuerprobe-Frage: Welches Mahl gab ich dieses Jahr — und wer saß am Ehren-Platz?
+ Tisch/Feuerplatz richten: Ehrenplatz kennzeichnen (z. B. Kissen/Stuhl am wärmsten Ende).
+ Portionen: beste Portion zuerst für den Gast aufschneiden.
+ Gastgeber isst zuletzt — auch wenn wenig da ist.
+ Gespräch: geregeltes Gespräch in der Runde (15-Minuten-Box, ART-0012); keine Anklage.
+ Reste: in die Reserve/Kammer (ART-0287), nichts wegwerfen, solange haltbar (ART-0309).
- _Stadt:_ Wohnungsküche, kleiner Tisch — Ehrenplatz = Platz an der Heizung/trockenster Platz.
- _Land:_ großer Tisch/Herd — Ehrenplatz am wärmsten Ende des Ofens.
- _Klima:_ Winter: mehr Kalorien für alle (2.200 kcal/Pers./Tag Planungswert); Sommer: Wasser reichlich.
#table(
  columns: 3,
  table.header([Fehler], [Folge], [Korrektur]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Gäste vergessen/schlecht behandeln], [keine Allianzen, keine Hilfe in der Not], [Ehren-Platz-Regel (dieser Artikel)],
  [Gastgeber isst zuerst], [signalisiert Knappheit statt Schutz], [Gastgeber zuletzt],
  [Reste weggeworfen], [Verschwendung in der harten Zeit], [Reste in die Kammer (ART-0287/ART-0309)],
)
Keine. (CO bei Kochstelle im geschlossenen Raum:, siehe ART-0091 (Band 3).)
ART-0012 (Band 1) (geregeltes Gespräch), ART-0290, S. #refpage(<art-0290>) (Gäste empfangen), ART-0294, S. #refpage(<art-0294>) (Gabe/Schuld), ART-0309, S. #refpage(<art-0309>) (haltbare Ware), ART-0308, S. #refpage(<art-0308>) (Ration)
Üben: einmal im Jahr ein gemeinsames Mahl geben und prüfen: Saß der Gast am Ehrenplatz? Aß der Gastgeber zuletzt?
- _Ehrenplatz:_ wärmster/sicherster Platz, beste Portion — für den Gast.
- _Mahl als soziales Kapital:_ gemeinsames Essen baut Allianzen und Vertrauen.
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Abbildungen]]
#grid(columns: (1fr, 1fr), column-gutter: 6pt, row-gutter: 5pt,
  figure(image("../illustrationen/art-0295-abb-1.svg", width: 100%), caption: [Abb. zu ART-0295 — ART-0295 · Abb. 1: Tischordnung mit Ehrenplatz: markierter Platz (z. B. Fenster/Licht), Gast von rechts setzen (ART-0295).]),
  figure(image("../illustrationen/art-0295-abb-2.svg", width: 100%), caption: [Abb. zu ART-0295 — ART-0295 · Abb. 2: Servierreihenfolge beim gemeinsamen Mahl (ART-0295).]))
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Kontroll-Checkliste]]
- [ ] Tisch/Feuerplatz richten: Ehrenplatz kennzeichnen (z. B. Kissen/Stuhl am wärmsten Ende).
- [ ] Portionen: beste Portion zuerst für den Gast aufschneiden.
- [ ] Gastgeber isst zuletzt — auch wenn wenig da ist.
- [ ] Gespräch: geregeltes Gespräch in der Runde (15-Minuten-Box, ART-0012 (Band 1)); keine Anklage.
- [ ] Reste: in die Reserve/Kammer (ART-0287, S. #refpage(<art-0287>)), nichts wegwerfen, solange haltbar (ART-0309, S. #refpage(<art-0309>)).
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Recherche-Details (Fakten, Masse, Fehler-Tiefe)]]
#table(
  columns: 2,
  table.header([*Aspekt*], [*Detail (Recherche)*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Masse/Zeiten/Mengen], [1 Ehrenplatz je Mahl; Gastgeber zuletzt.],
  [Typische Fehler], [Gäste vergessen/schlecht behandeln → keine Allianzen, keine Hilfe in der Not .],
  [Varianten Stadt/Land], [jede Gruppe gleich; Stadt: Wohnungsküche.],
  [Fakten], [Gäste sitzen auf dem Ehrenplatz ; Gastgeber isst zuletzt — signalisiert Großzügigkeit und Schutz; das gemeinsame Mahl ist soziales Kapital. Feuerprobe-Frage 15:],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Übungsprotokoll (Verfalluhr 12 Monate)]]
#table(
  columns: 5,
  table.header([*Nr.*], [*Datum*], [*Dauer*], [*Fehler*], [*V / Verfall*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [1], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [2], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [3], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [4], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [5], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [6], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [7], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [8], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [9], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [10], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [11], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [12], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Randbedingungen (vor Ort ausfüllen)]]
#table(
  columns: 3,
  table.header([*Randbedingung*], [*Trifft zu*], [*Anmerkung*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Allein / in der Gruppe], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Stadt / Land], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Tag / Nacht], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Sommer / Winter], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Notizen zu ART-0295]]
#block(width: 100%, height: 6.5cm, stroke: 0.6pt + rgb("#8c8c8c"), inset: 6pt)[Platz für eigene Notizen zu diesem Artikel.]
#pagebreak(weak: true)
== ART-0296 — Wie halte ich Bargeld im Blackout bereit (200–500 EUR in kleinen Scheinen)? <art-0296>
Bargeld in kleinen Scheinen griffbereit halten, damit bei Stromausfall (Geldautomaten und EC-Terminals fallen sofort aus — BBK) noch gewechselt und bezahlt werden kann, solange Bargeld irgendwo akzeptiert wird.
- _200–500 € in kleinen Scheinen_ (Richtwert, keine amtliche Vorgabe —)
- Stückelung: kleine Scheine (5/10/20 €) + Münzen — Wechselgeld ist entscheidend, wenn nur Barzahlung geht
- Aufbewahrung: wasserdichte Dokumentenmappe im Rucksack (ART-0288, ART-0030); Stadt-Profil: mehr Bargeld als Basisliste
- Zeitraum: individuelle Bedarfsrechnung für ca. 2 Wochen (10 T BBK-Standard / 14 T Empfehlung)
+ Betrag festlegen (Richtwert 200–500 €, individuell an 2-Wochen-Bedarf anpassen).
+ Kleine Scheine + Münzen packen; in die wasserdichte Mappe (ART-0288).
+ Sicher verwahren (versteckt, feuersicher — nicht im Zeug-Haus mit Brandlast, siehe ART-0300).
+ Kontrolle halbjährlich: Betrag vollständig? Scheine nicht verklebt/vermodert? (ART-0035)
+ Im Ernstfall: sparsam ausgeben, Tausch bevorzugen (ART-0285), jede Ausgabe am Blatt (ART-0307).
- _Stadt:_ höhere Reserve (längere Versorgungswege zu Fuß, mehr Bedarf); Land: Naturaltausch stärker (ART-0285/0309).
- _Klima:_ Feuchtigkeit schadet Scheinen → dicht/laminiert oder Kunststoffhülle.
#table(
  columns: 3,
  table.header([Fehler], [Folge], [Korrektur]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Nur große Scheine], [kein Wechselgeld, wenn doch ein Laden öffnet], [kleine Scheine + Münzen (dieser Artikel)],
  [Alles auf Karte/Lastschrift], [bei Stromausfall kein Zahlen möglich], [Bargeld-Reserve (BBK)],
  [Bargeld ungesichert], [Diebstahl/Brand-Verlust], [wasserdichte Mappe, verteilter Ort (ART-0288)],
  [Betrag nie kontrolliert], [Scheine unbrauchbar (Feuchtigkeit)], [halbjährliche Kontrolle (ART-0035)],
)
Keine eigene Warnpflicht.
ART-0288, S. #refpage(<art-0288>) (Dokumente wasserdicht), ART-0030 (Band 1) (Rucksack), ART-0285, S. #refpage(<art-0285>) (Wert/Tausch), ART-0307, S. #refpage(<art-0307>) (Ausgaben am Blatt), ART-0300, S. #refpage(<art-0300>) (sichere Lagerung), ART-0284, S. #refpage(<art-0284>) (Selbsthilfe-Netz)
Üben: halbjährlich das Bargeld zählen und die Stückelung prüfen — Betrag vollständig, Scheine trocken und unbeschädigt.
- _Bargeld-Reserve:_ kleine Scheine + Münzen für den Fall, dass bargeldloses Bezahlen (Karte/App) ausfällt.
- _Richtwert:_ empfohlene Größenordnung ohne amtliche Verbindlichkeit (hier 200–500 €).
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Abbildungen]]
#align(center)[#block(width: 10.5cm)[#figure(image("../illustrationen/art-0296-abb-1.svg", width: 100%), caption: [Abb. zu ART-0296 — ART-0296 · Abb. 1: Bargeld im Blackout: kleine Scheine, gestückelt, versteckt, nicht prahlen (ART-0296).])]]
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Kontroll-Checkliste]]
- [ ] Betrag festlegen (Richtwert 200–500 €, individuell an 2-Wochen-Bedarf anpassen).
- [ ] Kleine Scheine + Münzen packen; in die wasserdichte Mappe (ART-0288, S. #refpage(<art-0288>)).
- [ ] Sicher verwahren (versteckt, feuersicher — nicht im Zeug-Haus mit Brandlast, siehe ART-0300, S. #refpage(<art-0300>)).
- [ ] Kontrolle halbjährlich: Betrag vollständig? Scheine nicht verklebt/vermodert? (ART-0035 (Band 1))
- [ ] Im Ernstfall: sparsam ausgeben, Tausch bevorzugen (ART-0285, S. #refpage(<art-0285>)), jede Ausgabe am Blatt (ART-0307, S. #refpage(<art-0307>)).
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Recherche-Details (Fakten, Masse, Fehler-Tiefe)]]
#table(
  columns: 2,
  table.header([*Aspekt*], [*Detail (Recherche)*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Masse/Zeiten/Mengen], [200–500 € in kleinen Scheinen — gelb: Richtwert, keine amtliche Zahl; 500 € als Oberwert; Zeithorizont: 2 Wochen Bedarf individuell.],
  [Typische Fehler], [nur große Scheine ; alles auf Karte/Lastschrift; Bargeld ungesichert .],
  [Varianten Stadt/Land], [Stadt: höhere Reserve , da Handel ausfällt und Wege zu Fuß; Land: gleiche Reserve, ggf. Naturaltausch davantage .],
  [Fakten], [Geldautomaten und EC-Terminals fallen beim Stromausfall sofort aus (B1). Reserve 200–500 € in kleinen Scheinen (K1); K2 empfiehlt 500 € (K2). BBK-Ratgeber 2025 ],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Übungsprotokoll (Verfalluhr 12 Monate)]]
#table(
  columns: 5,
  table.header([*Nr.*], [*Datum*], [*Dauer*], [*Fehler*], [*V / Verfall*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [1], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [2], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [3], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [4], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [5], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [6], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [7], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [8], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [9], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [10], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [11], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [12], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Randbedingungen (vor Ort ausfüllen)]]
#table(
  columns: 3,
  table.header([*Randbedingung*], [*Trifft zu*], [*Anmerkung*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Allein / in der Gruppe], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Stadt / Land], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Tag / Nacht], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Sommer / Winter], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Notizen zu ART-0296]]
#block(width: 100%, height: 6.5cm, stroke: 0.6pt + rgb("#8c8c8c"), inset: 6pt)[Platz für eigene Notizen zu diesem Artikel.]
#pagebreak(weak: true)
== ART-0297 — Wie halte ich Betrieb und Werkstatt im Blackout handlungsfähig (Notfallplan in Papierform)? <art-0297>
Betrieb/Werkstatt auch ohne Strom handlungsfähig halten: Notfallplan in _Papierform_, Krisenstab, sicheres Herunterfahren, Kommunikation ohne Strom, klare Regeln für Notstrom.
- Notfall-/Alarmplan _in Papierform_ (WKO-Checkliste, 29 Fragen, Mai 2022)
- SETON Blackout-Guide (E-Book, gewerblich): Risikobewertung, Notfallpläne, Betriebsfähigkeit (Notstromaggregate, Redundanz), Mitarbeitende vorbereiten, Checklisten vor/während/nach Blackout — Inhalt über Sekundärquellen, Original automatisiert blockiert
- Kritisches „sicheres Herunterfahren" je Anlage schriftlich; Wasserleitungen nicht leerlaufen lassen (Pumpenschäden)
- Notstromaggregat: _nur außerhalb des Gebäudes_, nur bei Bedarf (CO, ART-0081)
+ Plan in Papierform erstellen: Alarmierung, Treffpunkt, Krisenstab (ART-0283), Herunterfahren, Kommunikation ohne Strom, Entsorgung/Dekontamination.
+ Personal schulen: jeder kennt seine Rolle (doppelt besetzt, ART-0312).
+ Werkstatt: Werkzeug sicher lagern (ART-0300); Not-Werkzeuge bereitlegen (ART-0018).
+ Bei Eintritt: Plan abarbeiten; Aggregat nur außen; eine Lampe an lassen (Wiederkehr erkennen, ART-0037).
+ Warten auf stabile europäische Stromversorgung — keine übereilten Aktionen (WKO).
- _Stadt:_ Betrieb im Hinterhof/Keller — Aggregat nur außen mit freier Abgasführung; Land: Werkstatt/Scheune, Aggregat außen.
- _Klima:_ Winter: Beheizung der Werkstatt planen (ART-0086); Sommer: Kühlung von Vorräten (ART-0204).
#table(
  columns: 3,
  table.header([Fehler], [Folge], [Korrektur]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Plan nur im Intranet/PC], [bei Stromausfall unlesbar], [Papierform Pflicht (WKO)],
  [Kein sicheres Herunterfahren definiert], [Datenverlust, Pumpenschäden], [je Anlage schriftlich festlegen],
  [Aggregat in geschlossenen Räumen], [CO-Vergiftung, tödlich], [nur außerhalb (ART-0081)],
  [Werkzeug unsicher gelagert], [Diebstahl/Brand], [Zeug-Haus-Regeln (ART-0300)],
)
#warnrahmen()[_CO-WARNUNG:_ Notstromaggregat nie in Wohnung/Garage/Keller betreiben — nur außerhalb, siehe ART-0081 (Band 3) (Warnpflicht).]
ART-0283, S. #refpage(<art-0283>) (Krisenstab), ART-0081 (Band 3) (Aggregat/CO), ART-0037 (Band 1) (Wiederanlaufen), ART-0300, S. #refpage(<art-0300>) (Zeug-Haus), ART-0304, S. #refpage(<art-0304>) (Werkstatt-Prüfung), ART-0312, S. #refpage(<art-0312>) (Ämter), ART-0018 (Band 1) (Behelfswerkzeug)
Üben: einmal jährlich einen Blackout-Drill im Betrieb mit dem Papierplan — sicheres Herunterfahren in unter 30 Minuten.
- _Notfallplan (Papierform):_ ohne Strom lesbarer Plan mit Alarmierung, Treffpunkt, Herunterfahren.
- _Sicheres Herunterfahren:_ definiertes, schonendes Abschalten kritischer Anlagen bei Kriseneintritt.
- _Redundanz:_ doppelte Auslegung kritischer Systeme (Notstrom, Kommunikation).
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Abbildungen]]
#align(center)[#block(width: 10.5cm)[#figure(image("../illustrationen/art-0297-abb-1.svg", width: 100%), caption: [Abb. zu ART-0297 — ART-0297 · Abb. 1: Werkstatt/Betrieb im Blackout sichern: abdunkeln, Werkzeug verstauen, nichts Offenes stehen lassen (ART-0297).])]]
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Kontroll-Checkliste]]
- [ ] Plan in Papierform erstellen: Alarmierung, Treffpunkt, Krisenstab (ART-0283, S. #refpage(<art-0283>)), Herunterfahren, Kommunikation oh
- [ ] Personal schulen: jeder kennt seine Rolle (doppelt besetzt, ART-0312, S. #refpage(<art-0312>)).
- [ ] Werkstatt: Werkzeug sicher lagern (ART-0300, S. #refpage(<art-0300>)); Not-Werkzeuge bereitlegen (ART-0018 (Band 1)).
- [ ] Bei Eintritt: Plan abarbeiten; Aggregat nur außen; eine Lampe an lassen (Wiederkehr erkennen, ART-0037 (Band 1)).
- [ ] Warten auf stabile europäische Stromversorgung — keine übereilten Aktionen (WKO).
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Recherche-Details (Fakten, Masse, Fehler-Tiefe)]]
#table(
  columns: 2,
  table.header([*Aspekt*], [*Detail (Recherche)*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Masse/Zeiten/Mengen], [29 WKO-Fragen ; SETON-Checklisten je Phase ; Notstrom-Aggregat: nur außerhalb, nur bei Bedarf (S2).],
  [Typische Fehler], [Plan nur im Intranet/PC; kein sicheres Herunterfahren definiert ; Aggregat in geschlossenen Räumen → CO .],
  [Varianten Stadt/Land], [Stadt: Betrieb im Hinterhof/Keller — Aggregat nur außerhalb des Hauses, Abgase frei; Land: Werkstatt/Scheune, Aggregat außen mit Abgasführung; Papier-Notfallpla],
  [Fakten], [SETON Blackout-Guide : Ursachen/Folgen von Stromausfällen , Risikobewertung, Notfallpläne, Betriebsfähigkeit sichern , Mitarbeitende vorbereiten, Checklisten vo],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Übungsprotokoll (Verfalluhr 12 Monate)]]
#table(
  columns: 5,
  table.header([*Nr.*], [*Datum*], [*Dauer*], [*Fehler*], [*V / Verfall*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [1], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [2], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [3], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [4], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [5], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [6], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [7], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [8], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [9], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [10], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [11], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [12], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Randbedingungen (vor Ort ausfüllen)]]
#table(
  columns: 3,
  table.header([*Randbedingung*], [*Trifft zu*], [*Anmerkung*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Allein / in der Gruppe], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Stadt / Land], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Tag / Nacht], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Sommer / Winter], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Notizen zu ART-0297]]
#block(width: 100%, height: 6.5cm, stroke: 0.6pt + rgb("#8c8c8c"), inset: 6pt)[Platz für eigene Notizen zu diesem Artikel.]
#pagebreak(weak: true)
== ART-0298 — Wie halte ich Feste und Rituale in der harten Zeit aufrecht? <art-0298>
Feste und Rituale auch in der harten Zeit aufrechterhalten — sie sind das soziale Kapital der Gruppe: Kalender, Markt-Feste, Gedenken, gemeinsames Mahl, Vermächtnis-Verlesung.
- Dorf-Kalender mit Fest-Terminen (ART-0291)
- Markt-Feste mit Fristen: _Wochen-Markt_ = fester Tag je Woche, kleine Ware; _wer zweimal fehlt, verliert den Platz am Ring_; _Monats-Markt_ = erster Markt-Tag nach Neumond, Werkzeug/Stoff/Vieh, Schulden und Gaben werden am Platz verlesen; _Jahres-Markt_ = nach der Ernte, drei Tage vor dem Winter, große Ware (Salz/Eisen/Leim), Rüst-Blatt diktiert den Einkauf; _Not-Markt_ = bei Flut/Brand/Missernte, Rat ruft ihn, Ware aus der Reserve (ART-0287), \*\*kein Gewinn
- Rituale: Gedenken (ART-0293), Mahl mit Ehrenplatz (ART-0295), Feuerprobe (ART-0292), Vermächtnis-Verlesung (ART-0311)
+ Fest-Termine in den Kalender schreiben (ART-0291).
+ Markt-Fristen ansagen (Anfang/Ende) — Ordnung durch Wachen (ART-0302).
+ Rituale einhalten: Gedenken, Mahl, Verlesen — auch wenn wenig da ist.
+ Not-Markt nur mit Rat-Beschluss und ohne Gewinn (ART-0313).
+ Nach jedem Fest: Zeile im Protokoll (ART-0035).
- _Land:_ Dorfanger/Gemeindehaus; _Stadt:_ Hof/Treppenhaus zu festen Zeiten, Wohnungsküche.
- _Klima:_ Winter: Feste wärmstens und kalorienreicher (ART-0295); harte Zeit: Ration beachten (ART-0308).
#table(
  columns: 3,
  table.header([Fehler], [Folge], [Korrektur]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Feste „wegen Krise“ ausfallen lassen], [Zusammenhalt bricht], [Rituale gerade in der harten Zeit (dieser Artikel)],
  [Not-Markt mit Gewinn], [Wucher — strafbar (§ 291 StGB), Ächtung], [Not-Markt ohne Gewinn (ART-0313)],
  [Fristen nicht angesagt], [Platz verliert seine Ehre, Chaos], [Fristen vorher ansagen (ART-0302)],
)
Keine eigene Warnpflicht; Wucher-Warnrahmen siehe ART-0313, S. #refpage(<art-0313>).
ART-0291, S. #refpage(<art-0291>) (Kalender), ART-0293, S. #refpage(<art-0293>) (Gedenken), ART-0295, S. #refpage(<art-0295>) (Mahl), ART-0302, S. #refpage(<art-0302>) (Tausch-Platz), ART-0308, S. #refpage(<art-0308>) (harte Zeit), ART-0311, S. #refpage(<art-0311>) (Vermächtnis), ART-0313, S. #refpage(<art-0313>) (Wucher)
Üben: jedes Ritual einmal im Jahr durchführen — Markt-Fristen angesagt, Gedenken verlesen, Mahl mit Ehrenplatz.
- _Markt-Frist:_ angesagtes Anfang/Ende eines Marktes — „Ehre der Frist“.
- _Not-Markt:_ Markt aus der Reserve in der Not — ohne Gewinn.
- _Ritual:_ wiederkehrende Handlung (Gedenken, Mahl, Verlesen), die Zusammenhalt stiftet.
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Abbildungen]]
#align(center)[#block(width: 10.5cm)[#figure(image("../illustrationen/art-0298-abb-1.svg", width: 100%), caption: [Abb. zu ART-0298 — ART-0298 · Abb. 1: Feste in der harten Zeit: feste Termine im Kalender halten – auch klein (ART-0298).])]]
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Kontroll-Checkliste]]
- [ ] Fest-Termine in den Kalender schreiben (ART-0291, S. #refpage(<art-0291>)).
- [ ] Markt-Fristen ansagen (Anfang/Ende) — Ordnung durch Wachen (ART-0302, S. #refpage(<art-0302>)).
- [ ] Rituale einhalten: Gedenken, Mahl, Verlesen — auch wenn wenig da ist.
- [ ] Not-Markt nur mit Rat-Beschluss und ohne Gewinn (ART-0313, S. #refpage(<art-0313>)).
- [ ] Nach jedem Fest: Zeile im Protokoll (ART-0035 (Band 1)).
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Recherche-Details (Fakten, Masse, Fehler-Tiefe)]]
#table(
  columns: 2,
  table.header([*Aspekt*], [*Detail (Recherche)*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Masse/Zeiten/Mengen], [4 Markt-Arten mit Fristen; Jahres-Markt 3 Tage vor dem Winter; 12 Monats-Rituale .],
  [Typische Fehler], [Feste ausfallen lassen „weil ja Krise“ → Zusammenhalt bricht; Not-Markt mit Gewinn → Wucher .],
  [Varianten Stadt/Land], [Land: Dorfanger/Gemeindehaus; Stadt: Hof/Treppenhaus zu festen Zeiten ; Wohnungsküche statt Festsaal.],
  [Fakten], [„Das Behalten: Kalender, Feste und das Gedenken“ (29cd074c \#146, ): Feste schriftlich im Dorfkalender ; Markt-Feste mit Fristen: Wochen-Markt , Monats-Markt , J],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Übungsprotokoll (Verfalluhr 12 Monate)]]
#table(
  columns: 5,
  table.header([*Nr.*], [*Datum*], [*Dauer*], [*Fehler*], [*V / Verfall*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [1], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [2], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [3], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [4], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [5], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [6], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [7], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [8], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [9], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [10], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [11], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [12], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Randbedingungen (vor Ort ausfüllen)]]
#table(
  columns: 3,
  table.header([*Randbedingung*], [*Trifft zu*], [*Anmerkung*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Allein / in der Gruppe], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Stadt / Land], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Tag / Nacht], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Sommer / Winter], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Notizen zu ART-0298]]
#block(width: 100%, height: 6.5cm, stroke: 0.6pt + rgb("#8c8c8c"), inset: 6pt)[Platz für eigene Notizen zu diesem Artikel.]
#pagebreak(weak: true)
== ART-0299 — Wie mache ich Warnungen für alle verständlich (Leichte Sprache, DGS)? <art-0299>
Warnungen und Anweisungen so verfassen, dass sie _alle_ verstehen — auch ohne Internet: Leichte Sprache, DGS (Gebärdensprache), barrierearme PDFs, Papier-Aushänge, UKW-Durchsagen als Fallback.
- BBK-Angebot (belegt über B1-Verknüpfungen): Publikationen zum Stromausfall als barrierearme PDFs („Stromausfall – Vorsorge und Selbsthilfe“ 673 KB; Baustein „Alles aus“ 2 MB —), Video „Was tun bei Stromausfall?“ (2:55 min), Informationen _in DGS und Leichter Sprache_ (:: — partly geblockt)
- Rechtsrahmen: _European Accessibility Act (EAA) — seit 28 verbindlich_ für digitale Produkte/E-Books in der EU; WCAG 2.x: Kontrast Text ≥ _4,5:1_, großer Text/grafische Elemente ≥ _3:1_ (W3C WAI SC 1.4.3)
- Projekt-Praxis: PDF/UA-1-Build aller Bände (getaggt, /Lang(de), Alt-Texte, Stand)
- Kanäle ohne Netz: Papier-Aushang in Leichter Sprache, UKW-Radio (72 h+ Notstrom), NINA nur als Ergänzung (braucht mobiles Internet —)
+ Jede Warnung in zwei Fassungen: Normalsprache + _Leichte Sprache_ (kurze Sätze, Aktiv, keine Fremdwörter, pro Satz eine Info).
+ Bildliche/DGS-Elemente: Piktogramme, DGS-Video auf lokalem Gerät (USB-Stick), Gebärden für Kernbegriffe (Wasser, Feuer, Treffpunkt, Notruf 112).
+ Druck: großer Kontrast (≥ 4,5:1), große Schrift, Papier aushängen (Treppenhaus/Gemeindehaus).
+ Audio: UKW-Durchsagen zur vollen Stunde (ART-0006/ART-0008) — sprechender Kanal für Sehbeeinträchtigte.
+ Prüfung: WCAG-Kontrast messen, Leichte-Sprache-Regeln prüfen, mit Betroffenen testen).
- _Stadt:_ Aushang im Treppenhaus + Leichte-Sprache-PDF auf USB; Land: Aushang am Gemeindehaus + Dorf-Funk per Boten.
- _Klima:_ Papier wetterfest laminieren; Videos auf lokalem Gerät ohne Netz abspielbar.
#table(
  columns: 3,
  table.header([Fehler], [Folge], [Korrektur]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Warnung nur als App/NINA], [ohne mobiles Netz keine Warnung (Ahrtal 2021)], [UKW + Papier + Leichte Sprache (dieser Artikel)],
  [Nur Fachsprache], [Betroffene verstehen nichts], [Leichte-Sprache-Fassung Pflicht],
  [Videos ohne Untertitel/DGS], [Gehörlose ausgeschlossen], [DGS/Untertitel (EAA ab 28)],
  [Kontrast zu gering], [Sehbeeinträchtigte lesen nicht], [WCAG 4,5:1 / 3:1 messen (W3C)],
)
Keine eigene Warnpflicht; NINA-Ausfall-Warnung (grün + Warnung) siehe ART-0026 (Band 1)/ART-0006 (Band 1).
ART-0006 (Band 1) (UKW-Radio), ART-0008 (Band 1) (Falschinformationen), ART-0026 (Band 1) (NINA/KATWARN/Sirenen), ART-0283, S. #refpage(<art-0283>) (Krisenstab/Alarmierung), ART-0284, S. #refpage(<art-0284>) (Selbsthilfe-Netz)
Üben: einmal jährlich eine Warnung in Leichter Sprache mit Piktogramm erstellen und von Betroffenen auf Verständlichkeit testen lassen.
- _Leichte Sprache:_ einfaches Deutsch — kurze Sätze, Aktiv, erklärte Fremdwörter.
- _DGS:_ Deutsche Gebärdensprache — Video-Kanal für Gehörlose.
- _EAA:_ European Accessibility Act — seit 28 Pflicht für digitale Produkte in der EU.
- _WCAG 2.x:_ Web-Content-Accessibility-Guidelines — Kontrast ≥ 4,5:1 (Text), ≥ 3:1 (Grafik/großer Text).
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Abbildungen]]
#align(center)[#block(width: 10.5cm)[#figure(image("../illustrationen/art-0299-abb-1.svg", width: 100%), caption: [Abb. zu ART-0299 — ART-0299 · Abb. 1: Warnung in Leichter Sprache: kurze Sätze, große Schrift, Symbol + Text – nie nur Symbol (ART-0299).])]]
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Kontroll-Checkliste]]
- [ ] Jede Warnung in zwei Fassungen: Normalsprache + Leichte Sprache (kurze Sätze, Aktiv, keine Fremdwörter, pro Sa
- [ ] Bildliche/DGS-Elemente: Piktogramme, DGS-Video auf lokalem Gerät (USB-Stick), Gebärden für Kernbegriffe (Wasse
- [ ] Druck: großer Kontrast (≥ 4,5:1), große Schrift, Papier aushängen (Treppenhaus/Gemeindehaus).
- [ ] Audio: UKW-Durchsagen zur vollen Stunde (ART-0006 (Band 1)/ART-0008 (Band 1)) — sprechender Kanal für Sehbeeinträchtigte.
- [ ] Prüfung: WCAG-Kontrast messen, Leichte-Sprache-Regeln prüfen, mit Betroffenen testen).
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Recherche-Details (Fakten, Masse, Fehler-Tiefe)]]
#table(
  columns: 2,
  table.header([*Aspekt*], [*Detail (Recherche)*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Masse/Zeiten/Mengen], [PDF 673 KB / Baustein 2 MB; Video 2:55 min ; EAA-Stichtag 28.06.2025; WCAG-Kontrast 4,5:1 / 3:1 .],
  [Typische Fehler], [Warnungen nur digital/App ; Fachsprache ohne Leichte-Sprache-Fassung; Videos ohne Untertitel/DGS.],
  [Varianten Stadt/Land], [gleich — Warnungen müssen auch ohne Internet verständlich sein; NINA ohne mobiles Internet eingeschränkt → UKW-Durchsagen + gedruckte Aushänge in Leichter Sprac],
  [Fakten], [BBK bietet Publikationen zum Stromausfall als barrierefrei/barrierearme PDFs , Video „Was tun bei Stromausfall?“ , Informationen in DGS und Leichter Sprache (B1],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Übungsprotokoll (Verfalluhr 12 Monate)]]
#table(
  columns: 5,
  table.header([*Nr.*], [*Datum*], [*Dauer*], [*Fehler*], [*V / Verfall*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [1], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [2], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [3], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [4], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [5], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [6], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [7], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [8], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [9], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [10], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [11], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [12], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Randbedingungen (vor Ort ausfüllen)]]
#table(
  columns: 3,
  table.header([*Randbedingung*], [*Trifft zu*], [*Anmerkung*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Allein / in der Gruppe], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Stadt / Land], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Tag / Nacht], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Sommer / Winter], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Notizen zu ART-0299]]
#block(width: 100%, height: 6.5cm, stroke: 0.6pt + rgb("#8c8c8c"), inset: 6pt)[Platz für eigene Notizen zu diesem Artikel.]
#pagebreak(weak: true)
== ART-0300 — Wie organisiere ich das Zeug-Haus? <art-0300>
Waffen, Werkzeug, Vorrat und Wissen zentral und _brand-sicher_ lagern — das Zeug-Haus ist das „nächste Jahr“ der Werkstatt: Verlust dort trifft am härtesten.
- Zeughaus: Land = separates Gebäude; Stadt = abschließbarer Keller/Abstellraum — _nie in der Wohnung_ (Diebstahl, Brand)
- Eimer mit Wasser gefüllt am Eingang; Sand-Sack neben Fettflächen
- Abstände: _2–3 m frei um das Haus, 4–6 m zu Unterkünften_ (konsistent ART-0092, grün)
- Ofen (falls nötig) außen; Rohr durch die Wand
- Prüf-Rhythmus: Zeug je Saison (Anfang + Ende): geölt, gewetzt, gehüllt; Werkstatt am Werk-Blatt; _Jahres-Prüfung (ART-0304) liest das Zeug-Haus als erste Station_ — Brand-Abstand ist eine Zeile im Rüst-Blatt, nicht ein Gefühl
- Gast-Regel: Waffen ablegen am Eingang (ART-0290)
+ Standort wählen: Abstand 2–3 m frei / 4–6 m zu Unterkünften; trocken, dunkel, hoch.
+ Haus einrichten: kein offenes Licht innen; Lampe außen/am Eingang; Ofen außen; Eimer + Sand am Eingang.
+ Einlagern: Waffen/Werkzeug getrennt von brennbaren Stoffen; Stroh nie über Getreide; Öl-Lappen nicht innen.
+ Saison-Prüfung (2×/Jahr): geölt/gewetzt/gehüllt; Abstände messen; Blatt aktualisieren.
+ Bei Brand: Dorf wecken → Blätter/Register retten → dann löschen (Eimer, Sand).
- _Land:_ separates Gebäude (Scheune/Stadel) mit Abstand; _Stadt:_ Keller/Abstellraum, abschließbar, nie in der Wohnung.
- _Klima:_ Winter: Frost — Flüssigkeiten (Lauge, Öl) nicht einfrieren lassen; Sommer: Hitze — Munition/Öle kühl und dunkel.
#table(
  columns: 3,
  table.header([Fehler], [Folge], [Korrektur]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Offenes Licht im Zeughaus], [Explosion/Brand — Verlust aller Waffen, Tote], [kein offenes Licht],
  [Öl-Lappen im Verschlag], [Selbstentzündung], [Lappen ausgebreitet trocknen oder in Metallbehälter mit Wasser],
  [Stroh über Getreide], [Brandbrücke], [getrennt lagern],
  [In der Wohnung lagern (Stadt)], [Diebstahl + Brand in der Wohnung], [Keller/Abstellraum (dieser Artikel)],
)
#warnrahmen()[siehe oben — Warnrahmen + Warngrafik Pflicht (Katalog §5). Querverweis (Leinöl-Lappen, ART-0272 (Band 9)/ART-0278 (Band 9)).]
ART-0290, S. #refpage(<art-0290>) (Waffenablage), ART-0272 (Band 9)/ART-0278 (Band 9) (Leinöl), ART-0304, S. #refpage(<art-0304>) (Werkstatt-Prüfung), ART-0079 (Band 3)/ART-0093 (Band 3) (Entstehungsbrand löschen), ART-0092 (Band 3) (Feuerplatz-Abstände), ART-0286, S. #refpage(<art-0286>) (Wissen/Blätter)
Üben: im November das Zeug-Haus auf den Winter prüfen — Abstände messen (2–3 m frei, 4–6 m zu Unterkünften), Eimer gefüllt, kein offenes Licht innen.
- _Zeug-Haus:_ zentraler Lagerraum für Waffen, Werkzeug, Vorrat, Wissen — brandgeschützt.
- _Brand-Abstand:_ 2–3 m frei, 4–6 m zu Unterkünften (ART-0092).
- _Rüst-Blatt:_ Einkaufs-/Lager-Blatt mit Fristen.
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Kontroll-Checkliste]]
- [ ] Standort wählen: Abstand 2–3 m frei / 4–6 m zu Unterkünften; trocken, dunkel, hoch.
- [ ] Haus einrichten: kein offenes Licht innen; Lampe außen/am Eingang; Ofen außen; Eimer + Sand am Eingang.
- [ ] Einlagern: Waffen/Werkzeug getrennt von brennbaren Stoffen; Stroh nie über Getreide; Öl-Lappen nicht innen.
- [ ] Saison-Prüfung (2×/Jahr): geölt/gewetzt/gehüllt; Abstände messen; Blatt aktualisieren.
- [ ] Bei Brand: Dorf wecken → Blätter/Register retten → dann löschen (Eimer, Sand).
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Recherche-Details (Fakten, Masse, Fehler-Tiefe)]]
#table(
  columns: 2,
  table.header([*Aspekt*], [*Detail (Recherche)*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Masse/Zeiten/Mengen], [Abstände 2–3 m frei / 4–6 m zu Unterkünften; 1 Eimer Wasser am Eingang; Prüfintervall je Saison + nach jeder Not .],
  [Typische Fehler], [offenes Licht im Zeughaus → Explosion/Brand, Verlust aller Waffen, Tote ; Öl-Lappen im Verschlag ; Stroh über Getreide.],
  [Varianten Stadt/Land], [Land: separates Gebäude; Stadt: abschließbarer Keller/Abstellraum — nie in der Wohnung lagern .],
  [Fakten], [WARNRAHMEN (): kein offenes Licht im Zeughaus , Ofen außen, Eimer mit Wasser am Eingang ; Abstände konsistent : 2–3 m frei, 4–6 m zu Unterkünften . (29cd074c \#1],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Übungsprotokoll (Verfalluhr 12 Monate)]]
#table(
  columns: 5,
  table.header([*Nr.*], [*Datum*], [*Dauer*], [*Fehler*], [*V / Verfall*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [1], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [2], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [3], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [4], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [5], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [6], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [7], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [8], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [9], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [10], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [11], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [12], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Randbedingungen (vor Ort ausfüllen)]]
#table(
  columns: 3,
  table.header([*Randbedingung*], [*Trifft zu*], [*Anmerkung*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Allein / in der Gruppe], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Stadt / Land], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Tag / Nacht], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Sommer / Winter], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Notizen zu ART-0300]]
#block(width: 100%, height: 6.5cm, stroke: 0.6pt + rgb("#8c8c8c"), inset: 6pt)[Platz für eigene Notizen zu diesem Artikel.]
#pagebreak(weak: true)
== ART-0301 — Wie organisiere ich einen Medikamenten-Pool der Dorf-Apotheke? <art-0301>
Einen Medikamenten-Pool für Dorf/Haus organisieren: Dauermedikation für mindestens 14 Tage (Ziel 4 Wochen), schriftliche Liste, Impfpass, Kühlkette — damit bei Stromausfall (Apotheken geschlossen, Lieferketten unterbrochen) die Versorgung weiterläuft.
- _Dauermedikation: mind. 14-Tage-Depot, Ziel 4 Wochen_ (BBK 2025); Saurugg: mind. 1 Woche, sonst sofort Arzt/Apotheke
- _Medikamentenliste schriftlich:_ Name / Dosis / Einnahmezeit je Medikament (ART-0288); Impfpass in der Dokumentenmappe
- Senioren-Medikation: Blutdrucksenker, Blutverdünner, Schmerzmittel, Diuretika
- Erweitertes Erste-Hilfe-Set: Verbandsmaterial, Pflaster, Desinfektionsmittel, Schmerzmittel, Durchfall-/Fiebermittel, Thermodecken
- _Insulin kühl lagern: 2–8 °C_ (ART-0236); bei Eintritt Bestand prüfen, ggf. sofort Apotheke/Rettungsleitstelle/Arzt kontaktieren
- Sanitätsmappe \< 3 kg (ART-0243, konsistent)
+ Bestand erfassen: alle Dauermedikamente + 14-Tage-Depot (Ziel 4 Wo) + Liste (Name/Dosis/Zeit) + Impfpass.
+ Pool einrichten: Dorf = zentrale Mappe in einem Haushalt, Kopie am Amts-Blatt (ART-0294); Stadt = Mappe je Haushalt + Absprache im Haus (Treppenhaus-Aushang).
+ Kühlkette: Insulin/Medikamente 2–8 °C (kühler Keller, ART-0236); keine Wärme.
+ Ausgabe-Regeln: nur gegen Liste, jede Entnahme am Blatt mit Datum (ART-0307); Antibiotika nur nach Regeln (ART-0243).
+ Kontrolle monatlich: Bestand vs. Liste; Verfalldaten prüfen (ART-0035).
- _Stadt:_ Mappe je Haushalt + Haus-Pool mit Aushang; Apotheke im Stadtteil kennen (Papierkarte, ART-0288).
- _Land:_ Dorf-Apotheke in einem Haushalt, doppelte Liste (Amts-Blatt), Boten bei Bedarf (ART-0027).
- _Klima:_ Sommer: Kühlkette kritisch (2–8 °C, ART-0236); Winter: Medikamente nicht einfrieren.
#table(
  columns: 3,
  table.header([Fehler], [Folge], [Korrektur]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Nur 7 Tage bevorratet (alter Band-1-Wert)], [Lücke bei längerem Ausfall], [mind. 14 T, Ziel 4 Wo],
  [Keine schriftliche Liste], [im Stress falsche Gabe], [Liste Name/Dosis/Zeit (ART-0288)],
  [Insulin ungekühlt], [Wirkungsverlust], [2–8 °C, ART-0236],
  [Entnahme nicht dokumentiert], [Pool leer ohne Nachweis], [jede Entnahme am Blatt (ART-0307)],
)
Kühlketten-Warnung (Insulin 2–8 °C — §3); Tetanus-Warnrahmen bei Wunden (→ ART-0245 (Band 8)).
ART-0236 (Band 8) (Insulin/Medikamente kühlen), ART-0245 (Band 8) (Wunde/Tetanus), ART-0243 (Band 8) (Sanitätsmappe), ART-0288, S. #refpage(<art-0288>) (Dokumente), ART-0253 (Band 8) (Dauermedikation 14 Tage), ART-0307, S. #refpage(<art-0307>) (Dokumentation am Blatt), ART-0284, S. #refpage(<art-0284>) (Selbsthilfe-Netz)
Üben: monatlich den Medikamenten-Pool kontrollieren — Bestand stimmt mit der schriftlichen Liste überein, Verfalldaten im Blick.
- _Medikamenten-Pool:_ zentrale, dokumentierte Medikamenten-Reserve von Dorf/Haus.
- _14-Tage-Depot / Ziel 4 Wochen:_ Kompendium-Wert für Dauermedikation (BBK 2025).
- _Kühlkette:_ ununterbrochene Kühlung 2–8 °C für Insulin und kühlpflichtige Medikamente.
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Abbildungen]]
#grid(columns: (1fr, 1fr), column-gutter: 6pt, row-gutter: 5pt,
  figure(image("../illustrationen/art-0301-abb-1.svg", width: 100%), caption: [Abb. zu ART-0301 — ART-0301 · Abb. 1: Dorf-Apotheke: Medikamentenschrank mit Fächern, Kühlkette 2–8 °C fürs Kühlfach, Verfallsdaten (ART-0301).]),
  figure(image("../illustrationen/art-0301-abb-2.svg", width: 100%), caption: [Abb. zu ART-0301 — ART-0301 · Abb. 2: Abgabeliste Medikamenten-Pool: Name, Medikament, Menge, Datum, Unterschrift (ART-0301).]))
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Kontroll-Checkliste]]
- [ ] Bestand erfassen: alle Dauermedikamente + 14-Tage-Depot (Ziel 4 Wo) + Liste (Name/Dosis/Zeit) + Impfpass.
- [ ] Pool einrichten: Dorf = zentrale Mappe in einem Haushalt, Kopie am Amts-Blatt (ART-0294, S. #refpage(<art-0294>)); Stadt = Mappe je Hau
- [ ] Kühlkette: Insulin/Medikamente 2–8 °C (kühler Keller, ART-0236 (Band 8)); keine Wärme.
- [ ] Ausgabe-Regeln: nur gegen Liste, jede Entnahme am Blatt mit Datum (ART-0307, S. #refpage(<art-0307>)); Antibiotika nur nach Regeln (ART
- [ ] Kontrolle monatlich: Bestand vs. Liste; Verfalldaten prüfen (ART-0035 (Band 1)).
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Recherche-Details (Fakten, Masse, Fehler-Tiefe)]]
#table(
  columns: 2,
  table.header([*Aspekt*], [*Detail (Recherche)*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Masse/Zeiten/Mengen], [mind. 14 Tage Depot, Ziel 4 Wochen ; Insulin 2–8 °C; Sanitätsmappe \< 3 kg .],
  [Typische Fehler], [nur 7 Tage bevorratet — Lücke bei längerem Ausfall; keine schriftliche Liste → im Stress falsche Gabe; Insulin ungekühlt ; Antibiotika ohne Regeln .],
  [Varianten Stadt/Land], [Stadt: zentrale Mappe je Haushalt + Pool-Absprache im Haus ; Land: Dorf-Apotheke/Pool in einem Haushalt, Liste doppelt , Kühlkette im kühlen Keller.],
  [Fakten], [Hausapotheke + Dauermedikation im Pool: Kompendium-Wert mind. 14-Tage-Depot + Medikamentenliste + Impfpass in der Dokumentenmappe; 4 Wochen als Ziel . Saurugg: ],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Übungsprotokoll (Verfalluhr 12 Monate)]]
#table(
  columns: 5,
  table.header([*Nr.*], [*Datum*], [*Dauer*], [*Fehler*], [*V / Verfall*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [1], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [2], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [3], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [4], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [5], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [6], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [7], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [8], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [9], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [10], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [11], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [12], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Randbedingungen (vor Ort ausfüllen)]]
#table(
  columns: 3,
  table.header([*Randbedingung*], [*Trifft zu*], [*Anmerkung*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Allein / in der Gruppe], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Stadt / Land], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Tag / Nacht], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Sommer / Winter], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Notizen zu ART-0301]]
#block(width: 100%, height: 6.5cm, stroke: 0.6pt + rgb("#8c8c8c"), inset: 6pt)[Platz für eigene Notizen zu diesem Artikel.]
#pagebreak(weak: true)
== ART-0302 — Wie organisiere ich einen Tausch-Platz (Markt-Fristen)? <art-0302>
Einen Tausch-Platz mit _angesagten Fristen_ und Wachen betreiben, damit er nicht zum Schwarzmarkt wird — Ordnung durch feste Zeiten, Plätze und Zeugen.
- Fester Platz: Dorf = Dorfanger; Stadt = Treppenhaus/Hof zu festen Zeiten
- Markt-Fristen (angesagt, Anfang/Ende —): _Wochen-Markt_ fester Tag je Woche (Sonnenaufgang bis Schlag), kleine Ware des Hauses; _2× Fehlen = Platzverlust am Ring_; _Monats-Markt_ = erster Markt-Tag nach Neumond, Werkzeug/Stoff/Vieh, Zeugen je Zeile, Schulden+Gaben am Platz verlesen; _Jahres-Markt_ = nach der Ernte, 3 Tage vor dem Winter, große Ware (Salz/Eisen/Leim), Rüst-Blatt diktiert Einkauf; _Not-Markt_ = bei Flut/Brand/Missernte, Rat ruft, aus der Reserve (ART-0287), \*\*kein Gewinn
- Ordnungsposten: Wachen (ART-0099, ART-0028/ART-0028); Bürger-Maß am Ring (ART-0314); Tausch-Blatt je Zeile (ART-0307)
+ Platz und Zeiten festlegen und _ansagen_ (Aushang, ART-0291).
+ Ordnungsposten besetzen (Wache, Maß-Wächter, Protokoll).
+ Je Tausch eine Zeile am Tausch-Blatt: Datum/Ware/Wert-Korridor (ART-0285)/2 Zeugen/Frist (ART-0307).
+ Frist einhalten: Anfang/Ende pünktlich; 2× Fehlen = Platzverlust.
+ Not-Markt nur mit Rat-Beschluss, Ware aus der Reserve, Not-Preis nach der Not — im Korridor (ART-0313).
- _Land:_ fester Platz am Dorfanger; _Stadt:_ Treppenhaus/Hof zu festen Zeiten, Ring markiert.
- _Klima:_ Winter: beheizter/überdachter Platz; Sommer: früh morgens (Kühle, Frische der Ware).
#table(
  columns: 3,
  table.header([Fehler], [Folge], [Korrektur]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Unbegrenzter Markt], [Diebstahl, Gewalt, Chaos], [Fristen + Wachen (dieser Artikel)],
  [Frist nicht angesagt], [Steh-Zeiten verfallen, Platz verliert Ehre], [Aushang + Verlesung],
  [Not-Markt mit Gewinn], [Wucher — strafbar, Ächtung], [kein Gewinn am Not-Markt (ART-0313)],
  [Platz ohne Maß-Wächter], [Streit um Maße], [Bürger-Maß am Ring (ART-0314)],
)
Keine eigene Warnpflicht; Wucher-Warnrahmen siehe ART-0313, S. #refpage(<art-0313>) (§ 291 StGB).
ART-0285, S. #refpage(<art-0285>) (Wert), ART-0287, S. #refpage(<art-0287>) (Reserve), ART-0307, S. #refpage(<art-0307>) (Tausch-Blatt), ART-0309, S. #refpage(<art-0309>) (haltbare Ware), ART-0310, S. #refpage(<art-0310>) (Stunden-Tafel), ART-0313, S. #refpage(<art-0313>) (Wucher), ART-0314, S. #refpage(<art-0314>) (Maß), ART-0028 (Band 1) (Wachen), ART-0312, S. #refpage(<art-0312>) (Ämter)
Üben: im September den Jahres-Markt abhalten — jede Zeile mit zwei Zeugen und laut angesagtem Wert-Korridor.
- _Markt-Frist:_ angesagtes Anfang/Ende des Marktes; die Ehre der Frist ist das Gesetz des Platzes.
- _Ring:_ Kreis der Plätze am Markt; Platzverlust am Ring bei 2× Fehlen.
- _Not-Markt:_ Markt aus der Reserve in der Not — ohne Gewinn.
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Abbildungen]]
#grid(columns: (1fr, 1fr), column-gutter: 6pt, row-gutter: 5pt,
  figure(image("../illustrationen/art-0302-abb-1.svg", width: 100%), caption: [Abb. zu ART-0302 — ART-0302 · Abb. 1: Tauschplatz mit Ring: fester Platz, Kreis/Ring markiert, Stände im Kreis, Mitte frei (ART-0302).]),
  figure(image("../illustrationen/art-0302-abb-2.svg", width: 100%), caption: [Abb. zu ART-0302 — ART-0302 · Abb. 2: Markt-Ordnung: wer wann wo steht – Tafel am Platz (ART-0302).]))
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Kontroll-Checkliste]]
- [ ] Platz und Zeiten festlegen und ansagen (Aushang, ART-0291, S. #refpage(<art-0291>)).
- [ ] Ordnungsposten besetzen (Wache, Maß-Wächter, Protokoll).
- [ ] Je Tausch eine Zeile am Tausch-Blatt: Datum/Ware/Wert-Korridor (ART-0285, S. #refpage(<art-0285>))/2 Zeugen/Frist (ART-0307, S. #refpage(<art-0307>)).
- [ ] Frist einhalten: Anfang/Ende pünktlich; 2× Fehlen = Platzverlust.
- [ ] Not-Markt nur mit Rat-Beschluss, Ware aus der Reserve, Not-Preis nach der Not — im Korridor (ART-0313, S. #refpage(<art-0313>)).
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Recherche-Details (Fakten, Masse, Fehler-Tiefe)]]
#table(
  columns: 2,
  table.header([*Aspekt*], [*Detail (Recherche)*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Masse/Zeiten/Mengen], [4 Markt-Arten; Frist-Regel: 2× Fehlen = Platzverlust; Not-Markt: 0 Gewinn .],
  [Typische Fehler], [unbegrenzter Markt → Diebstahl, Gewalt, Chaos ; Markt-Frist nicht angesagt → Steh-Zeiten verfallen, Platz verliert seine Ehre ; Not-Markt mit Gewinn → Wucher .],
  [Varianten Stadt/Land], [Dorf: fester Platz am Dorfanger; Stadt: Treppenhaus/Hof zu festen Zeiten.],
  [Fakten], [Markt mit Fristen ; Ordnung aufrechterhalten durch Wachen , sonst wird der Platz zum Schwarzmarkt. Markt-Tafel: Wochen-Markt = ein fester Tag je Woche , kleine ],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Übungsprotokoll (Verfalluhr 12 Monate)]]
#table(
  columns: 5,
  table.header([*Nr.*], [*Datum*], [*Dauer*], [*Fehler*], [*V / Verfall*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [1], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [2], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [3], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [4], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [5], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [6], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [7], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [8], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [9], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [10], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [11], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [12], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Randbedingungen (vor Ort ausfüllen)]]
#table(
  columns: 3,
  table.header([*Randbedingung*], [*Trifft zu*], [*Anmerkung*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Allein / in der Gruppe], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Stadt / Land], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Tag / Nacht], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Sommer / Winter], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Notizen zu ART-0302]]
#block(width: 100%, height: 6.5cm, stroke: 0.6pt + rgb("#8c8c8c"), inset: 6pt)[Platz für eigene Notizen zu diesem Artikel.]
#pagebreak(weak: true)
== ART-0303 — Wie organisiere ich einen Trupp (einer vorn, einer hinten)? <art-0303>
Unterwegs nie allein gehen: _einer liest vorn, einer hält hinten_ — niemand geht allein verloren; die _+60-Minuten-Regel_ startet rechtzeitig die Suche.
- Trupp ab 2 Personen; einer vorn (Weg lesen, Markierungen), einer hinten (keiner bleibt zurück)
- _+60-Minuten-Regel_ (ART-0027): Rückkehrzeit vereinbaren; 60 min überfällig → Suchaktion starten (erst bei Tageslicht suchen
- Wegzeiten (interne Weg-Tafel): zum Tausch-Platz 1 h zu Fuß (mit Karren 2); zum Nachbardorf 2 h (Nachmittag 1); zur Salz-Siede (Küste) 1 Tag hin + 1 zurück; über die Heide (Insel) 3 h zum Torf-Stich
- Rast = Gerichts-Ort des Trupps: am Abend berichtet jeder, der Morgen wird gemeinsam gewählt
- Signal: 3 Signale/min (ART-0013); Markierungen am Weg
+ Vor dem Losgehen: Route, Rückkehrzeit (+60 min), Ausweichroute schriftlich (ART-0020).
+ Reihe bilden: vorn der Kundige, hinten der Starke; Tempo dem Langsamsten.
+ Unterwegs: Pausen an Rast-Orten; jeder berichtet am Abend.
+ Bei Verlust: Signal geben, nicht allein losziehen, +60-min-Regel abwarten, dann Suche bei Tageslicht.
+ Rückkehr: Treffpunkt bestätigen, Protokoll (ART-0011).
- _Stadt:_ belebte Wege, Treppenhaus, beleuchtete Route; _Land:_ Route abseits der Straße, Markierungen an Bäumen.
- _Klima:_ Winter: kürzere Etappen, Restlicht-1-h-Regel (ART-0123); Sommer: früh los (Hitze), Wasser reichlich (ART-0049).
#table(
  columns: 3,
  table.header([Fehler], [Folge], [Korrektur]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Allein losziehen], [Verlust, keine Hilfe, Suchaktion zu spät], [nie allein (dieser Artikel)],
  [Keine Rückkehrzeit], [Bote wird nie oder zu früh gesucht], [+60-Minuten-Regel (ART-0027/ART-0027)],
  [Suche nachts], [Verletzungsgefahr massiv], [erst bei Tageslicht suchen, Signal geben],
  [Tempo des Schnellsten], [Gruppe reißt auseinander], [Tempo dem Langsamsten],
)
Keine eigene Warnpflicht; Furt-Regeln siehe ART-0289, S. #refpage(<art-0289>).
ART-0020 (Band 1) (Treffpunkte A/B), ART-0027 (Band 1) (Boten/+60-min), ART-0013 (Band 1) (Signale), ART-0289, S. #refpage(<art-0289>) (Furt), ART-0123 (Band 4) (Dunkelheit), ART-0043 (Band 1) (Traglasten)
Üben: im März die Wege des Umkreises in Trupp-Regel gehen — einer vorn, einer hinten, Rückkehrzeit plus 60 Minuten vereinbart.
- _Trupp:_ Wandern in Ordnung — einer liest vorn, einer hält hinten, keiner geht allein.
- _+60-Minuten-Regel:_ Überfälligkeits-Zeit; nach 60 min Überfälligkeit startet die Suche.
- _Rast:_ Rast-Ort des Trupps — Gerichts-Ort: am Abend berichtet jeder, der Morgen wird gemeinsam gewählt.
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Abbildungen]]
#grid(columns: (1fr, 1fr), column-gutter: 6pt, row-gutter: 5pt,
  figure(image("../illustrationen/art-0303-abb-1.svg", width: 100%), caption: [Abb. zu ART-0303 — ART-0303 · Abb. 1: Trupp in Reihe: einer vorn (Spitze), einer hinten (Schluss), Abstand halten, leise (ART-0303).]),
  figure(image("../illustrationen/art-0303-abb-2.svg", width: 100%), caption: [Abb. zu ART-0303 — ART-0303 · Abb. 2: Handzeichen im Trupp: Halt – Weiter – Gefahr – Versammlung (ART-0303).]))
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Kontroll-Checkliste]]
- [ ] Vor dem Losgehen: Route, Rückkehrzeit (+60 min), Ausweichroute schriftlich (ART-0020 (Band 1)).
- [ ] Reihe bilden: vorn der Kundige, hinten der Starke; Tempo dem Langsamsten.
- [ ] Unterwegs: Pausen an Rast-Orten; jeder berichtet am Abend.
- [ ] Bei Verlust: Signal geben, nicht allein losziehen, +60-min-Regel abwarten, dann Suche bei Tageslicht.
- [ ] Rückkehr: Treffpunkt bestätigen, Protokoll (ART-0011 (Band 1)).
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Recherche-Details (Fakten, Masse, Fehler-Tiefe)]]
#table(
  columns: 2,
  table.header([*Aspekt*], [*Detail (Recherche)*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Masse/Zeiten/Mengen], [+60 Minuten Überfälligkeits-Regel ; Wegzeiten 1 h/2 h/1 Tag/3 h je Ziel .],
  [Typische Fehler], [allein losziehen → Verlust, keine Hilfe, Suchaktion zu spät ; keine Rückkehrzeit → Bote wird nie oder zu früh gesucht .],
  [Varianten Stadt/Land], [Stadt: belebte Wege, Treppenhaus; Land: Route abseits der Straße, Markierungen.],
  [Fakten], [Einer vorn, einer hinten — nie allein los . Rast = Gerichts-Ort des Trupps: am Abend berichtet jeder, der Morgen wird gemeinsam gewählt . Weg-Tafel: zum Tausch-],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Übungsprotokoll (Verfalluhr 12 Monate)]]
#table(
  columns: 5,
  table.header([*Nr.*], [*Datum*], [*Dauer*], [*Fehler*], [*V / Verfall*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [1], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [2], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [3], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [4], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [5], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [6], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [7], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [8], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [9], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [10], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [11], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [12], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Randbedingungen (vor Ort ausfüllen)]]
#table(
  columns: 3,
  table.header([*Randbedingung*], [*Trifft zu*], [*Anmerkung*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Allein / in der Gruppe], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Stadt / Land], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Tag / Nacht], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Sommer / Winter], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Notizen zu ART-0303]]
#block(width: 100%, height: 6.5cm, stroke: 0.6pt + rgb("#8c8c8c"), inset: 6pt)[Platz für eigene Notizen zu diesem Artikel.]
#pagebreak(weak: true)
== ART-0304 — Wie prüfe ich die Werkstatt (zwei Nachbarn zeugen)? <art-0304>
Die Werkstatt regelmäßig prüfen — _mit zwei Nachbarn als Zeugen_ — damit Qualität nachprüfbar bleibt und Pfusch auffällt, bevor er schadet (Weitergabe dreifach gesichert, ART-0262 (Band 9)).
- Prüfungs-Bogen: Datum, Bestand, Mängel, Urteil, 2 Zeugen
- Checkliste: Werkzeug vollständig? geschärft/geölt (ART-0264)? Brand-Abstand im Zeug-Haus als erste Station (ART-0300)? Sicherheitsmängel?
- Rhythmus: _jährlich + nach größeren Arbeiten_; Februar (Tausch-Jahr): Werkstatt von außen sehen lassen, fremde Hand einladen
+ Termin ankündigen; zwei Nachbarn als Zeugen einladen.
+ Werkstatt von außen sehen: Zugang, Licht, Ordnung (fester Ort je Ding, ART-0269).
+ Bestand prüfen: Werkzeug, Material-Kammer (ART-0268); Mängel notieren.
+ Zeug-Haus als _erste Station_ der Jahres-Prüfung: Brand-Abstand messen (2–3 m frei / 4–6 m zu Unterkünften) — als Zeile ins Rüst-Blatt (ART-0300).
+ Urteil + Unterschriften der Zeugen auf dem Bogen; Mängel → Nachbesserung mit Frist (ART-0307).
- _Stadt:_ zwei Nachbarn aus dem Haus; Werkstatt = Keller/Abstellraum/Werkbank in der Wohnung.
- _Land:_ zwei Nachbarn aus dem Dorf; Werkstatt = Scheune/Stadel.
- _Klima:_ Winter-Prüfung (November, Tausch-Jahr) vor der Heizperiode.
#table(
  columns: 3,
  table.header([Fehler], [Folge], [Korrektur]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Allein prüfen lassen], [Mängel übersehen — Einsturz/Brand/Unfall], [2 Zeugen (dieser Artikel)],
  [Nur Bestand zählen, keine Sicherheitsprüfung], [Brand-Abstand, scharfe Kanten übersehen], [Zeug-Haus zuerst, Abstand messen (ART-0300)],
  [Mängel ohne Frist], [bleiben liegen], [Nachbesserung mit Frist am Blatt (ART-0307)],
)
Keine eigene Warnpflicht; Brand-Abstand im Zeug-Haus siehe (ART-0300, S. #refpage(<art-0300>)).
ART-0300, S. #refpage(<art-0300>) (Zeug-Haus), ART-0262 (Band 9) (Wissen am Werkstück weitergeben), ART-0292, S. #refpage(<art-0292>) (Feuerprobe), ART-0307, S. #refpage(<art-0307>) (Frist/Zeugen), ART-0035 (Band 1) (Protokoll)
Üben: im Februar und nach größeren Arbeiten die Werkstatt mit zwei Nachbarn prüfen — Zeug-Haus zuerst, Brand-Abstand messen.
- _Werkstatt-Prüfung:_ nachprüfbare Qualitätskontrolle mit zwei Zeugen.
- _Prüfungs-Bogen:_ Protokoll mit Urteil + Zeugen.
- _Dreifach gesichert:_ Weitergabe/Prüfung so, dass kein einzelner Fehler sie kippt (ART-0262).
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Abbildungen]]
#grid(columns: (1fr, 1fr), column-gutter: 6pt, row-gutter: 5pt,
  figure(image("../illustrationen/art-0304-abb-1.svg", width: 100%), caption: [Abb. zu ART-0304 — ART-0304 · Abb. 1: Werkstatt prüfen mit zwei Zeugen: Prüfprotokoll mit Unterschriften (ART-0304).]),
  figure(image("../illustrationen/art-0304-abb-2.svg", width: 100%), caption: [Abb. zu ART-0304 — ART-0304 · Abb. 2: Prüfpunkte an der Werkbank: Ordnung, Werkzeug, Sicherheit (ART-0304).]))
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Kontroll-Checkliste]]
- [ ] Termin ankündigen; zwei Nachbarn als Zeugen einladen.
- [ ] Werkstatt von außen sehen: Zugang, Licht, Ordnung (fester Ort je Ding, ART-0269 (Band 9)).
- [ ] Bestand prüfen: Werkzeug, Material-Kammer (ART-0268 (Band 9)); Mängel notieren.
- [ ] Zeug-Haus als erste Station der Jahres-Prüfung: Brand-Abstand messen (2–3 m frei / 4–6 m zu Unterkünften) — al
- [ ] Urteil + Unterschriften der Zeugen auf dem Bogen; Mängel → Nachbesserung mit Frist (ART-0307, S. #refpage(<art-0307>)).
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Recherche-Details (Fakten, Masse, Fehler-Tiefe)]]
#table(
  columns: 2,
  table.header([*Aspekt*], [*Detail (Recherche)*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Masse/Zeiten/Mengen], [2 Zeugen; 1× jährlich + nach größeren Arbeiten; Zeug-Schicht je Saison .],
  [Typische Fehler], [allein prüfen lassen → Mängel übersehen, Einsturz/Brand/Unfall .],
  [Varianten Stadt/Land], [Stadt: zwei Nachbarn aus dem Haus; Land: zwei Nachbarn aus dem Dorf.],
  [Fakten], [Zwei Nachbarn zeugen die Werkstatt-Prüfung — macht Qualität nachprüfbar, verhindert Pfusch. Rhythmus: jährlich + nach größeren Arbeiten ; Februar-Aufgabe Tausch],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Übungsprotokoll (Verfalluhr 12 Monate)]]
#table(
  columns: 5,
  table.header([*Nr.*], [*Datum*], [*Dauer*], [*Fehler*], [*V / Verfall*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [1], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [2], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [3], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [4], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [5], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [6], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [7], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [8], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [9], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [10], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [11], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [12], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Randbedingungen (vor Ort ausfüllen)]]
#table(
  columns: 3,
  table.header([*Randbedingung*], [*Trifft zu*], [*Anmerkung*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Allein / in der Gruppe], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Stadt / Land], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Tag / Nacht], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Sommer / Winter], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Notizen zu ART-0304]]
#block(width: 100%, height: 6.5cm, stroke: 0.6pt + rgb("#8c8c8c"), inset: 6pt)[Platz für eigene Notizen zu diesem Artikel.]
#pagebreak(weak: true)
== ART-0305 — Wie schlichte ich Streit im Rat (nie Rache)? <art-0305>
Streit in der Gruppe so schlichten, dass die Gruppe nicht zerbricht: Verfahren = _Klage → Zeugen → Rat → Entscheidung_ — nie Rache, nie Selbstjustiz.
- Klage schriftlich (Datum, Parteien, Sachverhalt) — am Amts-Blatt (ART-0294)
- _2 Zeugen_ je Klage (ART-0307)
- Rat = Versammlung der Ämter (ART-0312), doppelt besetzte Funktionen
- -Auflage: Rats-Frist ergänzen (Vorschlag: Entscheidung binnen Tagen, nicht Wochen)
+ Klage erheben: schriftlich, mit Datum, am Blatt.
+ Zeugen benennen (2) und verhören — getrennt, protokolliert.
+ Rat einberufen (Treffpunkt, ART-0020); beide Seiten gehört.
+ Entscheidung des Rats — verhältnismäßig, dokumentiert; Urteil am Blatt.
+ Vollzug: beide Parteien tragen das Urteil; bei Nichtbefolgung: Eskalation im Rat, nie Selbsthilfe.
+ Deeskalation zuerst: geregeltes Gespräch (ART-0012), Verdacht laut aussprechen (ART-0290).
- _Stadt:_ Rat der Nachbarn im Treppenhaus/Hof; _Land:_ Rat im Gemeindehaus. Verfahren identisch.
#table(
  columns: 3,
  table.header([Fehler], [Folge], [Korrektur]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Selbst richten], [Blutrache-Spirale, strafbar, Gruppe zerbricht], [Rat nach Klage+Zeugen (dieser Artikel)],
  [Rache statt Rat], [Eskalation], [: „Rache statt Rat → Eskalation, Selbstjustiz strafbar“],
  [Klage ohne Zeugen], [nicht durchsetzbar], [2 Zeugen + Frist (ART-0307)],
  [Urteil aus Rache gesucht], [Verfahren korrupt], [Feuerprobe-Frage 12: „Habe ich je ein Urteil aus Rache gesucht?“],
)
#warnrahmen(id: "warn-art-0305", )[siehe oben — § 32 StGB;.]
ART-0290, S. #refpage(<art-0290>) (Gast/Fremder, §§ 34/35/123), ART-0307, S. #refpage(<art-0307>) (Vertrag/Zeugen), ART-0312, S. #refpage(<art-0312>) (Ämter), ART-0294, S. #refpage(<art-0294>) (Amts-Blatt), ART-0012 (Band 1) (geregeltes Gespräch), ART-0132 (Band 4) (Eigentum im Notstand)
Üben: einmal jährlich einen fiktiven Streitfall durchspielen — Klage, zwei Zeugen, Rat, Urteil in der richtigen Reihenfolge.
- _Rat:_ Versammlung der Zeugen — spricht nach Klage und Zeugen, nie nach Rache.
- _Klage:_ schriftliche Anrufung des Rats mit Sachverhalt und Datum.
- _Selbstjustiz:_ richten ohne Rat — strafbar (§ 32 StGB nur Notwehr bei gegenwärtigem rechtswidrigen Angriff).
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Kontroll-Checkliste]]
- [ ] Klage erheben: schriftlich, mit Datum, am Blatt.
- [ ] Zeugen benennen (2) und verhören — getrennt, protokolliert.
- [ ] Rat einberufen (Treffpunkt, ART-0020 (Band 1)); beide Seiten gehört.
- [ ] Entscheidung des Rats — verhältnismäßig, dokumentiert; Urteil am Blatt.
- [ ] Vollzug: beide Parteien tragen das Urteil; bei Nichtbefolgung: Eskalation im Rat, nie Selbsthilfe.
- [ ] Deeskalation zuerst: geregeltes Gespräch (ART-0012 (Band 1)), Verdacht laut aussprechen (ART-0290, S. #refpage(<art-0290>)).
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Recherche-Details (Fakten, Masse, Fehler-Tiefe)]]
#table(
  columns: 2,
  table.header([*Aspekt*], [*Detail (Recherche)*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Masse/Zeiten/Mengen], [2 Zeugen je Klage; keine Frist-Vorgabe für den Rat .],
  [Typische Fehler], [selbst richten → Blutrache-Spirale, strafbar, Gruppe zerbricht ; Rache statt Rat .],
  [Varianten Stadt/Land], [gleich; Stadt: Rat der Nachbarn im Treppenhaus/Hof.],
  [Fakten], [Streit nach Klage und Zeugen , Entscheidung durch den Rat, nie Rache. Rechtlich : Notwehr nur § 32 StGB — bei gegenwärtigem rechtswidrigem Angriff und verhältni],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Übungsprotokoll (Verfalluhr 12 Monate)]]
#table(
  columns: 5,
  table.header([*Nr.*], [*Datum*], [*Dauer*], [*Fehler*], [*V / Verfall*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [1], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [2], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [3], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [4], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [5], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [6], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [7], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [8], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [9], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [10], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [11], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [12], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Randbedingungen (vor Ort ausfüllen)]]
#table(
  columns: 3,
  table.header([*Randbedingung*], [*Trifft zu*], [*Anmerkung*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Allein / in der Gruppe], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Stadt / Land], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Tag / Nacht], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Sommer / Winter], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Notizen zu ART-0305]]
#block(width: 100%, height: 6.5cm, stroke: 0.6pt + rgb("#8c8c8c"), inset: 6pt)[Platz für eigene Notizen zu diesem Artikel.]
#pagebreak(weak: true)
== ART-0306 — Wie schließe ich die Reihe (Haus-Metapher)? <art-0306>
Verstehen, wie das Kompendium als Ganzes zusammenhält — und Änderungen nur so vornehmen, dass keine internen Widersprüche entstehen.
- Haus-Metapher: _ = Fundament, Bände 2–9 = Räume, = Dach_ — keine Schicht trägt allein (Abb. 9.1)
- Regel: _„Wer ein Stockwerk abreist, muss das Dach neu decken“_ — Änderungen nur mit Feuerprobe (ART-0292)
- 10 Bände = 10 Schichten; jede Änderung → 1 Feuerprobe-Durchlauf (≥ 80 %, ART-0292)
+ Vor jeder Änderung: festhalten, welcher Band/welches ART betroffen ist.
+ Änderung nur nach Rücksprache im Rat der Gruppe (ART-0305) und mit Protokoll (ART-0011).
+ Nach der Änderung: Feuerprobe des betroffenen Bandes (ART-0292), Ergebnis protokollieren.
+ Querverweise prüfen: lösen alle ART-IDs auf? (keine toten Referenzen)
+ Abschluss: (Dach) erst anfassen, wenn Bände 1–9 stabil sind.
- Gilt für jeden Haushalt und jede Gruppe gleichermaßen — die Metapher ist ortsunabhängig.
#table(
  columns: 3,
  table.header([Fehler], [Folge], [Korrektur]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Einfach umschreiben], [interne Widersprüche — im Ernstfall tödliche Fehlentscheidungen], [Änderung nur mit Feuerprobe (ART-0292)],
  [Querverweise nicht geprüft], [tote Referenzen, Verwirrung], [ART-Register prüfen (Phase H2)],
  [Fundament ändern ohne Prüfung], [alle Bände betroffen], [zuerst Feuerprobe],
)
Keine.
ART-0292, S. #refpage(<art-0292>) (Feuerprobe), ART-0305, S. #refpage(<art-0305>) (Rat), ART-0011 (Band 1) (Protokoll), ART-0035 (Band 1), ART-0286, S. #refpage(<art-0286>) (Wissen bewahren), ART-0311, S. #refpage(<art-0311>) (Vermächtnis)
Üben: nach jeder Änderung am eigenen Wissensstand die Feuerprobe des betroffenen Bereichs — Ziel: mindestens 80 % korrekt.
- _Haus-Metapher:_ Fundament, Bände 2–9 Räume, Dach — keine Schicht trägt allein.
- _Dach neu decken:_ nach jeder Änderung am Fundament die Konsistenz des Ganzen neu prüfen (Feuerprobe).
- _Devise :_ „Tausche, bevor du verteidigst; richte nach Klage und Zeugen, nie aus Rache; und was du weitergibst, schreibe auf — das Vermächtnis ist das letzte Werkzeug.“
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Abbildungen]]
#align(center)[#block(width: 10.5cm)[#figure(image("../illustrationen/abb-9-1.svg", width: 100%), caption: [Abb. 9.1 (Band 9, siehe Artikel ART-0306)])]]
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Kontroll-Checkliste]]
- [ ] Vor jeder Änderung: festhalten, welcher Band/welches ART betroffen ist.
- [ ] Änderung nur nach Rücksprache im Rat der Gruppe (ART-0305, S. #refpage(<art-0305>)) und mit Protokoll (ART-0011 (Band 1)).
- [ ] Nach der Änderung: Feuerprobe des betroffenen Bandes (ART-0292, S. #refpage(<art-0292>)), Ergebnis protokollieren.
- [ ] Querverweise prüfen: lösen alle ART-IDs auf? (keine toten Referenzen)
- [ ] Abschluss: (Dach) erst anfassen, wenn Bände 1–9 stabil sind.
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Recherche-Details (Fakten, Masse, Fehler-Tiefe)]]
#table(
  columns: 2,
  table.header([*Aspekt*], [*Detail (Recherche)*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Masse/Zeiten/Mengen], [10 Bände = 10 Schichten; jede Änderung → 1 Feuerprobe-Durchlauf .],
  [Typische Fehler], [einfach umschreiben → interne Widersprüche, im Ernstfall tödliche Fehlentscheidungen .],
  [Varianten Stadt/Land], [gleich — Metapher gilt für jeden Haushalt.],
  [Fakten], [Das Kompendium ist ein Haus: das Fundament, Bände 2–9 die Räume, das Dach. „Wer ein Stockwerk abreist, muss das Dach neu decken“ — Änderungen nur mit Feuerprobe],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Übungsprotokoll (Verfalluhr 12 Monate)]]
#table(
  columns: 5,
  table.header([*Nr.*], [*Datum*], [*Dauer*], [*Fehler*], [*V / Verfall*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [1], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [2], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [3], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [4], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [5], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [6], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [7], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [8], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [9], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [10], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [11], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [12], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Randbedingungen (vor Ort ausfüllen)]]
#table(
  columns: 3,
  table.header([*Randbedingung*], [*Trifft zu*], [*Anmerkung*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Allein / in der Gruppe], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Stadt / Land], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Tag / Nacht], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Sommer / Winter], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Notizen zu ART-0306]]
#block(width: 100%, height: 6.5cm, stroke: 0.6pt + rgb("#8c8c8c"), inset: 6pt)[Platz für eigene Notizen zu diesem Artikel.]
#pagebreak(weak: true)
== ART-0307 — Wie schließe ich einen Vertrag (zwei Zeugen + Frist)? <art-0307>
Vereinbarungen ohne Netz und ohne Gericht durchsetzbar machen: _zwei Zeugen + Frist + schriftliche Zeile_ — mündlich gilt, schriftlich hält.
- Tausch-Blatt: _Datum / Ware A / Ware B / Wert-Korridor (ART-0285) / Zeuge 1 / Zeuge 2 / Frist_ — eine Zeile je Tausch
- Beispiele: 3. des Monats — ein Sack Salz gegen zwei Fässchen Honig, Zeugen: Bäcker + Wache; 17. — geschmiedete Sichel gegen ein Zuber Korn + eine Stunde, Zeugen: Schmied + Rat; Markt-Tag — zwei Eimer Pech gegen drei Rollen Zwirn, zwei Markt-Nachbarn
- Wort-Kunde: „die Zeile — der Beweis, der über den Tag zählt; was nicht am Blatt steht, geschah nicht fürs Dorf. Zwei Zeugen machen das Wort zum Vertrag."
+ Leistung und Gegenleistung klar benennen (Ware/Stunde, ART-0285/ART-0310).
+ Wert-Korridor laut ansagen (ART-0285).
+ _Zwei Zeugen_ hinzuziehen; Frist festlegen.
+ Zeile am Tausch-Blatt: alle 7 Felder ausfüllen; beide Parteien + Zeugen unterschreiben/zeichnen.
+ Frist überwachen: bei Verzug im Rat besprechen (ART-0305), nicht selbst eintreiben.
- _Stadt:_ Tausch im Treppenhaus, Blatt an der Tür; _Land:_ am Markt/Dorfanger, Blatt am Amts-Blatt. Verfahren gleich.
#table(
  columns: 3,
  table.header([Fehler], [Folge], [Korrektur]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Versprechen ohne Zeugen], [„habe ich nicht gesagt“-Streit, nicht beweisbar], [2 Zeugen + Frist + Zeile (dieser Artikel)],
  [Ohne Frist], [unklare Erwartung, Streit], [Frist immer am Blatt],
  [Mündlich nur, weil „gilt ja anyway“], [Beweisproblem ohne Zeugen (ZPO)], [Zeile am Blatt],
)
#warnrahmen(id: "warn-art-0307", )[siehe oben (Formfreiheit + Beweisregel; Details). Warnpflicht lt. Katalog §5.]
ART-0285, S. #refpage(<art-0285>) (Wert-Korridor), ART-0294, S. #refpage(<art-0294>) (Schuld/Gabe), ART-0302, S. #refpage(<art-0302>) (Tausch-Platz), ART-0305, S. #refpage(<art-0305>) (Rat), ART-0287, S. #refpage(<art-0287>) (Reserve), ART-0011 (Band 1) (Protokoll)
Üben: zweimal im Jahr ein Tausch-Protokoll mit zwei Zeugen und Frist ausfüllen — Ware, Wert, Zeugen und Frist vollständig.
- _Tausch-Blatt:_ Protokollblatt mit 7 Feldern je Tausch.
- _Zeile:_ der schriftliche Beweis — was nicht am Blatt steht, geschah nicht fürs Dorf.
- _Zwei Zeugen:_ machen das Wort zum Vertrag — Beweissicherung, kein Gesetzeserfordernis (BGB-Formfreiheit).
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Abbildungen]]
#grid(columns: (1fr, 1fr), column-gutter: 6pt, row-gutter: 5pt,
  figure(image("../illustrationen/art-0307-abb-1.svg", width: 100%), caption: [Abb. zu ART-0307 — ART-0307 · Abb. 1: Tausch-Blatt / Vertrag: Ware, Menge, Frist, zwei Zeugen, Unterschriften – ohne Netz, schriftlich (ART-0307).]),
  figure(image("../illustrationen/art-0307-abb-2.svg", width: 100%), caption: [Abb. zu ART-0307 — ART-0307 · Abb. 2: Zeugen-Schema: A und B tauschen, zwei Zeugen unterschreiben – dann gilt der Vertrag (ART-0307).]))
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Kontroll-Checkliste]]
- [ ] Leistung und Gegenleistung klar benennen (Ware/Stunde, ART-0285, S. #refpage(<art-0285>)/ART-0310, S. #refpage(<art-0310>)).
- [ ] Wert-Korridor laut ansagen (ART-0285, S. #refpage(<art-0285>)).
- [ ] Zwei Zeugen hinzuziehen; Frist festlegen.
- [ ] Zeile am Tausch-Blatt: alle 7 Felder ausfüllen; beide Parteien + Zeugen unterschreiben/zeichnen.
- [ ] Frist überwachen: bei Verzug im Rat besprechen (ART-0305, S. #refpage(<art-0305>)), nicht selbst eintreiben.
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Recherche-Details (Fakten, Masse, Fehler-Tiefe)]]
#table(
  columns: 2,
  table.header([*Aspekt*], [*Detail (Recherche)*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Masse/Zeiten/Mengen], [2 Zeugen + 1 Frist je Vertrag; 1 Zeile je Tausch; Übung 2×.],
  [Typische Fehler], [ohne Zeugen/Frist → „habe ich nicht gesagt“-Streit, Eskalation, Vertrauensverlust ; Versprechen ohne Zeugen .],
  [Varianten Stadt/Land], [gleich; Stadt: Tausch im Treppenhaus mit Blatt an der Tür.],
  [Fakten], [Zwei Zeugen + Frist — mündlich gilt, schriftlich hält. Protokoll : Datum / Ware A / Ware B / Wert-Korridor / Zeuge 1 / Zeuge 2 / Frist — eine Zeile je Tausch. B],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Übungsprotokoll (Verfalluhr 12 Monate)]]
#table(
  columns: 5,
  table.header([*Nr.*], [*Datum*], [*Dauer*], [*Fehler*], [*V / Verfall*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [1], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [2], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [3], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [4], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [5], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [6], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [7], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [8], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [9], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [10], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [11], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [12], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Randbedingungen (vor Ort ausfüllen)]]
#table(
  columns: 3,
  table.header([*Randbedingung*], [*Trifft zu*], [*Anmerkung*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Allein / in der Gruppe], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Stadt / Land], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Tag / Nacht], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Sommer / Winter], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Notizen zu ART-0307]]
#block(width: 100%, height: 6.5cm, stroke: 0.6pt + rgb("#8c8c8c"), inset: 6pt)[Platz für eigene Notizen zu diesem Artikel.]
#pagebreak(weak: true)
== ART-0308 — Wie setze ich die Ration im Herbst (die harte Zeit)? <art-0308>
Die Ration für die harte Zeit _im Herbst_ (nach der Ernte, Sept/Okt) festsetzen — im Rat, nicht allein — nie erst im Frühjahr/Januar.
- Winter-Rechnung (ART-0214): \*\*100 stille Tage + 20–33 % Aufschlag
- Planungswert Energie: _2.200 kcal pro Person und Tag_ (DGE-Referenzwerte 1.600–2.600 kcal je Alter/Geschlecht/PAL — Mittelwert plausibel, grün)
- Rations-Blatt (am Amts-Blatt): wer bekommt wann wie viel; Verfallsdaten der Vorräte (ART-0197)
- Herbst-Termin: nach der Ernte (Sept/Okt), Beschluss im Rat (ART-0305)
+ Bestand aufnehmen: Vorrat nach Kreisen (Tag/Woche/Winter) zählen (ART-0287).
+ Bedarf rechnen: Personen × Tage × kcal; Winter-Rechnung (100 T + 20–33 %) als Rahmen.
+ Ration im Rat beschließen (nicht allein) — schriftliches Rations-Blatt.
+ Ration verteilen/lagern: Reserve getrennt (ART-0287), älteste Ware zuerst (Drehung, ART-0286).
+ Kontrolle monatlich: Bestand vs. Rations-Blatt; Mangel laut melden (: „der Mangel wird laut“).
- _Land:_ Rat des Dorfes beschließt nach der Ernte; _Stadt:_ Hausgemeinschaft legt Haushaltsration fest (gemeinsamer Vorrat Treppenhaus, ART-0284).
- _Klima:_ Winterhart: 100-Tage-Rahmen + Aufschlag; mildere Winter: Aufschlag reduzieren — im Rat begründen.
#table(
  columns: 3,
  table.header([Fehler], [Folge], [Korrektur]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Erst im Januar/Frühjahr rationieren], [Vorrat reicht nicht — Hungersnot], [Ration im Herbst setzen (dieser Artikel)],
  [Allein rationieren], [Willkür, Streit], [Beschluss im Rat (ART-0305)],
  [Reserve mit Ration vermischen], [keine klare Grenze], [getrennte Kammer (ART-0287)],
  [kcal-Bedarf nicht gerechnet], [zu wenig/viel], [2.200 kcal/Pers./Tag als Planungswert],
)
Keine.
ART-0287, S. #refpage(<art-0287>) (Reserve/Zehnte), ART-0305, S. #refpage(<art-0305>) (Rat), ART-0194 (Band 7) (Vorrat berechnen), ART-0214 (Band 7) (Winter-Vorrat), ART-0222 (Band 7) (sofort essbar), ART-0197 (Band 7) (Verderb), ART-0308, S. #refpage(<art-0308>)↔ART-0291, S. #refpage(<art-0291>) (Kalender)
Üben: im Herbst (September/Oktober) einmal das Rations-Blatt erstellen und im Rat beschließen lassen.
- _Harte Zeit:_ der Termin zwischen Winter und Ernte — Ration wird im Herbst gesetzt, der Mangel wird laut.
- _Rations-Blatt:_ schriftlicher Beschluss, wer wann wie viel bekommt.
- _100 stille Tage + 20–33 %:_ Winter-Rechnung (ART-0214).
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Abbildungen]]
#align(center)[#block(width: 10.5cm)[#figure(image("../illustrationen/art-0308-abb-1.svg", width: 100%), caption: [Abb. zu ART-0308 — ART-0308 · Abb. 1: Ration im Herbst setzen: am Erntedank festlegen, schriftlich, für die harte Zeit (ART-0308).])]]
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Kontroll-Checkliste]]
- [ ] Bestand aufnehmen: Vorrat nach Kreisen (Tag/Woche/Winter) zählen (ART-0287, S. #refpage(<art-0287>)).
- [ ] Bedarf rechnen: Personen × Tage × kcal; Winter-Rechnung (100 T + 20–33 %) als Rahmen.
- [ ] Ration im Rat beschließen (nicht allein) — schriftliches Rations-Blatt.
- [ ] Ration verteilen/lagern: Reserve getrennt (ART-0287, S. #refpage(<art-0287>)), älteste Ware zuerst (Drehung, ART-0286, S. #refpage(<art-0286>)).
- [ ] Kontrolle monatlich: Bestand vs. Rations-Blatt; Mangel laut melden (: „der Mangel wird laut“).
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Recherche-Details (Fakten, Masse, Fehler-Tiefe)]]
#table(
  columns: 2,
  table.header([*Aspekt*], [*Detail (Recherche)*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Masse/Zeiten/Mengen], [Winter-Rechnung: 100 stille Tage + 20–33 % Aufschlag ; Termin: Herbst nach der Ernte.],
  [Typische Fehler], [erst im Januar rationieren → Vorrat reicht nicht ; allein rationieren statt im Rat.],
  [Varianten Stadt/Land], [Land: Rat des Dorfes beschließt nach der Ernte; Stadt: Hausgemeinschaft legt Haushaltsration fest .],
  [Fakten], [Die Ration wird im Herbst gesetzt — Entscheidung im Rat , nicht allein; nie erst im Frühjahr/Januar. Basis: Winter-Rechnung. : „Ration im Frühjahr gesetzt = zu ],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Übungsprotokoll (Verfalluhr 12 Monate)]]
#table(
  columns: 5,
  table.header([*Nr.*], [*Datum*], [*Dauer*], [*Fehler*], [*V / Verfall*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [1], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [2], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [3], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [4], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [5], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [6], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [7], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [8], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [9], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [10], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [11], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [12], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Randbedingungen (vor Ort ausfüllen)]]
#table(
  columns: 3,
  table.header([*Randbedingung*], [*Trifft zu*], [*Anmerkung*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Allein / in der Gruppe], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Stadt / Land], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Tag / Nacht], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Sommer / Winter], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Notizen zu ART-0308]]
#block(width: 100%, height: 6.5cm, stroke: 0.6pt + rgb("#8c8c8c"), inset: 6pt)[Platz für eigene Notizen zu diesem Artikel.]
#pagebreak(weak: true)
== ART-0309 — Wie tausche ich haltbare Ware des Hauses? <art-0309>
Nur _haltbare Ware_ tauschen — transportfähig und wertstabil; Verderb macht Ware wertlos oder gefährlich.
- Zulässige Ware (ART-0208 sechs Wege): Dörrware, Gesalzenes, Eingekochtes (ART-0203), Getreide, _Salz bekannter Herkunft_ (: Streusalz/Regeneriersalz nie in die Küche — Ferrocyanid)
- Waren-Tafel: Salz — ewig wenn trocken (dicht + hoch lagern, ART-0300/ART-0286), das Geld des Winters, teuer im Binnenland; Stockfisch — Jahre (trocken, dunkel); Honig — Jahre (Kristall ist keine Fäulnis); Talg — 1 Jahr kühl/dunkel; Pech — Jahre im Fass; Leim — Jahre als Platten (1 Platte ≈ 10 Fugen); Eisen-Nägel — „rostet nie ganz“; Zwirn — Jahre trocken/dunkel; Tuch — Jahre (Feind: Mottenstunde); Brannt — Jahre in der Kanne
- Nie leicht verderbliche Ware über weite Strecken tauschen
+ Ware prüfen: haltbar? Herkunft bekannt (Salz!)? Lagerfähig (dicht, trocken, hoch, dunkel — ART-0216)?
+ Wert im Korridor bestimmen (ART-0285).
+ Zeile am Tausch-Blatt mit 2 Zeugen + Frist (ART-0307).
+ Transport: Ware vor Feuchtigkeit/Schädlingen schützen (ART-0216).
+ Beim Tausch: gestrichen messen (ART-0314).
- _Stadt:_ Vorrat im kühlen Treppenhaus (ART-0209); kurze Wege — auch Frisches am selben Tag ok; _Land:_ längere Wege → nur haltbare Ware.
- _Klima:_ Sommer: keine leicht verderbliche Ware; Winter: Salz/Honig/Talg hoch im Wert (ART-0285).
#table(
  columns: 3,
  table.header([Fehler], [Folge], [Korrektur]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Frisches als „Währung“ genommen], [fault beim Transport — Streit um Wert], [nur haltbare Ware],
  [Salz unbekannter Herkunft (Streusalz)], [Vergiftungsgefahr (Ferrocyanid)], [: nur Salz bekannter Herkunft],
  [Salz im feuchten Eck], [Gewichtsverlust, Klumpen], [dicht + hoch lagern],
  [Motten im Tuch/Zwirn], [Wertverlust], [trocken, dunkel, dicht (ART-0216)],
)
Querverweis: _Streusalz/Regeneriersalz nie in die Küche_ (Ferrocyanid) — Warnrahmen in (ART-0215 (Band 7)).
ART-0285, S. #refpage(<art-0285>) (Wert), ART-0302, S. #refpage(<art-0302>) (Tausch-Platz), ART-0307, S. #refpage(<art-0307>) (Vertrag), ART-0310, S. #refpage(<art-0310>) (Ware der Hand), ART-0314, S. #refpage(<art-0314>) (wiegen), ART-0216 (Band 7) (Vorräte schützen), ART-0215 (Band 7) (Salz), ART-0208 (Band 7) (sechs Wege haltbar)
Üben: im August das Rüst-Blatt führen — je Ding „kaufen, machen oder lassen“ entscheiden, nur haltbare Ware listen.
- _Haltbare Ware:_ Dörrware, Gesalzenes, Eingekochtes, Getreide, Salz bekannter Herkunft — transportfähig, wertstabil.
- _Waren-Tafel:_ Liste der Handels-Waren mit Herkunft, Haltbarkeit, Tauschwert.
- _Geld des Winters:_ Salz — ewig haltbar, im Binnenland teuer (ART-0285).
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Abbildungen]]
#align(center)[#block(width: 10.5cm)[#figure(image("../illustrationen/art-0309-abb-1.svg", width: 100%), caption: [Abb. zu ART-0309 — ART-0309 · Abb. 1: Ware des Hauses: nur haltbare Ware tauschen – Konserve, Getreide, Salz, Trockenobst (ART-0309).])]]
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Kontroll-Checkliste]]
- [ ] Ware prüfen: haltbar? Herkunft bekannt (Salz!)? Lagerfähig (dicht, trocken, hoch, dunkel — ART-0216 (Band 7))?
- [ ] Wert im Korridor bestimmen (ART-0285, S. #refpage(<art-0285>)).
- [ ] Zeile am Tausch-Blatt mit 2 Zeugen + Frist (ART-0307, S. #refpage(<art-0307>)).
- [ ] Transport: Ware vor Feuchtigkeit/Schädlingen schützen (ART-0216 (Band 7)).
- [ ] Beim Tausch: gestrichen messen (ART-0314, S. #refpage(<art-0314>)).
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Recherche-Details (Fakten, Masse, Fehler-Tiefe)]]
#table(
  columns: 2,
  table.header([*Aspekt*], [*Detail (Recherche)*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Masse/Zeiten/Mengen], [Haltbarkeiten je Ware siehe Tafel (T11) ; Salz-Lagerpflicht: dicht + hoch.],
  [Typische Fehler], [frisches als „Währung“ nehmen → Ware fault beim Transport, Streit um Wert ; Salz im feuchten Eck → Gewichtsverlust.],
  [Varianten Stadt/Land], [gleich; Stadt: Vorrat im kühlen Treppenhaus .],
  [Fakten], [Nur haltbare Ware handeln : Dörrware, Gesalzenes, Eingekochtes , Getreide, Salz bekannter Herkunft . Waren-Tafel mit Haltbarkeit: Salz — ewig wenn trocken , das],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Übungsprotokoll (Verfalluhr 12 Monate)]]
#table(
  columns: 5,
  table.header([*Nr.*], [*Datum*], [*Dauer*], [*Fehler*], [*V / Verfall*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [1], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [2], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [3], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [4], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [5], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [6], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [7], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [8], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [9], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [10], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [11], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [12], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Randbedingungen (vor Ort ausfüllen)]]
#table(
  columns: 3,
  table.header([*Randbedingung*], [*Trifft zu*], [*Anmerkung*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Allein / in der Gruppe], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Stadt / Land], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Tag / Nacht], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Sommer / Winter], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Notizen zu ART-0309]]
#block(width: 100%, height: 6.5cm, stroke: 0.6pt + rgb("#8c8c8c"), inset: 6pt)[Platz für eigene Notizen zu diesem Artikel.]
#pagebreak(weak: true)
== ART-0310 — Wie tausche ich Ware der Hand (Stunden-Tafel 1:1)? <art-0310>
Handwerk und Dienste bewertbar und tauschbar machen: _Stunden-Tafel 1:1_ — eine Stunde Arbeit gegen eine Stunde Ware; jeder Auftrag mit Stundenzettel am Blatt.
- Stunden-Tafel (Papier, am Amts-Blatt): je Zeile Datum, Stunde, Werk, Lohn, Zeuge (ART-0307)
- Werk-Tafel: Zaun eine Rute Fach = 2 h (mit gesetzten Pfosten) / 3 h (ohne); Sichel geschmiedet+geschliffen = 1 Tag am Feuer + 2 h am Stein, Lohn: Zuber Korn + Stunde (hält 2 Ernten); Schuh geflickt/genäht = 2 h je Schuh, Lohn: ein Brot je Schuh; Wache eine Nacht = _Gabe_ am Amts-Blatt, keine Schuld (ART-0294); Acker ein Tag gehackt = Anteil an der Ernte (im Herbst gezählt); Brot backen = 3 h + Nacht Ruhe, Lohn: das Brot selbst
- Dienst-Tafel: Schmied — Zuber je Werk am Ernte-Ende; Müllerin — _Mahl-Zehnte: je 10. Sack bleibt am Stein_; Bäcker — Ofen wird geteilt (Brot gegen Brot); Zimmermann — Ware des Hauses + Zeile am Amts-Blatt; Spinnerin — Hälfte bleibt am Rocken; Heilerin — _Gabe, nie der Preis_ (ART-0294); Wache — das Amt selbst ist der Lohn; Schreiber — Kost und Dach beim Haus, das die Zeile braucht
+ Vor dem Auftrag: Stundenzettel eröffnen (Datum, Werk, geschätzte Stunden).
+ Arbeiten; Stunden ehrlich zählen — nicht fühlen.
+ Nach dem Werk: Lohn nach Tafel; Zeile am Blatt mit Zeugen (ART-0307).
+ Jede geleistete Stunde am Amts-Blatt — auch die unbezahlte.
+ Juli (Tausch-Jahr): eigene Stunden-Tafel gerechnet — das eigene Werk je Stunde am Blatt.
- _Stadt:_ Aufträge über Tauschplatz Treppenhaus (ART-0302); _Land:_ am Dorfanger/im Gemeindehaus. Tafel gleich.
- _Klima:_ Winter: Indoor-Werke (Flicken, ART-0122); Sommer: Feld-Werke (Zaun, Acker).
#table(
  columns: 3,
  table.header([Fehler], [Folge], [Korrektur]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [„Unbezahlbar“ — Handwerker arbeitet nicht mehr], [Reparaturstau], [Stunden-Tafel 1:1 (dieser Artikel)],
  [Stunde gefühlt statt gerechnet], [Lohn ist Meinung — Streit kommt], [Stundenzettel führen],
  [Geleistete Stunde nie gezählt], [Gebender verarmt still], [jede Stunde ans Amts-Blatt],
)
Keine.
ART-0285, S. #refpage(<art-0285>) (Wert-Korridor), ART-0294, S. #refpage(<art-0294>) (Gabe/Schuld), ART-0302, S. #refpage(<art-0302>) (Tausch-Platz), ART-0307, S. #refpage(<art-0307>) (Vertrag), ART-0262 (Band 9) (Wissen am Werkstück), ART-0266 (Band 9) (Handwerk ethisch)
Üben: im Juli die eigene Stunden-Tafel rechnen — jedes Werk mit Stundenzettel und Lohn am Blatt.
- _Stunden-Tafel:_ Aufstellung von Arbeit = Ware, 1 Stunde gegen 1 Stunde (1:1).
- _Stundenzettel:_ schriftlicher Nachweis je Auftrag.
- _Mahl-Zehnte:_ Lohn der Müllerin — je 10. Sack bleibt einer am Stein.
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Abbildungen]]
#grid(columns: (1fr, 1fr), column-gutter: 6pt, row-gutter: 5pt,
  figure(image("../illustrationen/art-0310-abb-1.svg", width: 100%), caption: [Abb. zu ART-0310 — ART-0310 · Abb. 1: Ware der Hand: Stunden-Tafel 1:1 – geleistete Stunde gegen Stunde (ART-0310).]),
  figure(image("../illustrationen/art-0310-abb-2.svg", width: 100%), caption: [Abb. zu ART-0310 — ART-0310 · Abb. 2: Stunden-Eintrag: Datum, Leistung, Dauer, Unterschrift beider Seiten (ART-0310).]))
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Kontroll-Checkliste]]
- [ ] Vor dem Auftrag: Stundenzettel eröffnen (Datum, Werk, geschätzte Stunden).
- [ ] Arbeiten; Stunden ehrlich zählen — nicht fühlen.
- [ ] Nach dem Werk: Lohn nach Tafel; Zeile am Blatt mit Zeugen (ART-0307, S. #refpage(<art-0307>)).
- [ ] Jede geleistete Stunde am Amts-Blatt — auch die unbezahlte.
- [ ] Juli (Tausch-Jahr): eigene Stunden-Tafel gerechnet — das eigene Werk je Stunde am Blatt.
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Recherche-Details (Fakten, Masse, Fehler-Tiefe)]]
#table(
  columns: 2,
  table.header([*Aspekt*], [*Detail (Recherche)*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Masse/Zeiten/Mengen], [1:1 Stunde gegen Stunde; Beispiele: 2–3 h/Zaun-Ruthe, 1 Tag+2 h/Sichel, 2 h/Schuh, 3 h+Nacht/Brot, Mahl-Zehnte 1:10 .],
  [Typische Fehler], [„unbezahlbar“ → Handwerker arbeiten nicht mehr, Reparaturstau ; Stunde gefühlt statt gerechnet → Lohn ist Meinung, Streit kommt ; geleistete Stunden nie gezählt],
  [Varianten Stadt/Land], [gleich; Stadt: Aufträge über Tauschplatz Treppenhaus, Stundenzettel am Blatt.],
  [Fakten], [Stunden-Tafel 1:1 — eine Stunde Arbeit gegen eine Stunde Ware ; jeder Auftrag mit Stundenzettel . Werk-Tafel: Zaun eine Ruthe Fach = 2 h / 3 h ; Sichel geschmie],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Übungsprotokoll (Verfalluhr 12 Monate)]]
#table(
  columns: 5,
  table.header([*Nr.*], [*Datum*], [*Dauer*], [*Fehler*], [*V / Verfall*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [1], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [2], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [3], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [4], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [5], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [6], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [7], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [8], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [9], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [10], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [11], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [12], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Randbedingungen (vor Ort ausfüllen)]]
#table(
  columns: 3,
  table.header([*Randbedingung*], [*Trifft zu*], [*Anmerkung*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Allein / in der Gruppe], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Stadt / Land], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Tag / Nacht], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Sommer / Winter], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Notizen zu ART-0310]]
#block(width: 100%, height: 6.5cm, stroke: 0.6pt + rgb("#8c8c8c"), inset: 6pt)[Platz für eigene Notizen zu diesem Artikel.]
#pagebreak(weak: true)
== ART-0311 — Wie verfasse ich ein Vermächtnis (geschrieben + verlesen)? <art-0311>
Das Wissen, das weitergegeben werden muss, als _Vermächtnis_ festhalten — geschrieben und verlesen, damit es den Tod des Wissenden überlebt: Kernregeln pro –9.
- Vermächtnis-Blatt: _Name / Datum / Kernregeln pro –9 / Unterschrift / zwei Zeugen_ (ART-0307)
- 9 Bände = Kernregeln je Band auf das Blatt
- Kopie in die _vier Schichten_ (ART-0286); Verlesen vor der Gruppe (ART-0293)
- Rhythmus: _1× jährlich aktualisieren_ (Dezember, Tausch-Jahr: Jahresgedenken + Vermächtnis erneuert)
+ Blatt nehmen (A3); für jeden –9 die 1–3 Kernregeln aufschreiben, die weitergegeben werden müssen.
+ Unterschreiben; _zwei Zeugen_ unterschreiben (ART-0307).
+ Vor der Gruppe verlesen (ART-0293) — mündlich und schriftlich.
+ Kopien in die vier Schichten verteilen (ART-0286): geschrieben (2 Orte), verlesen, eingeübt, Vermächtnis.
+ Jährlich (Dezember) erneuern; Protokoll (ART-0035).
- _Stadt:_ Verlesen in der Hausgemeinschaft, Kopien in mehreren Wohnungen; _Land:_ Rat verliest, Kopien in mehreren Gebäuden.
#table(
  columns: 3,
  table.header([Fehler], [Folge], [Korrektur]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Nur mündlich], [Wissen stirbt mit der Person], [Vermächtnis-Blatt schreiben + verlesen (dieser Artikel)],
  [Keine Zeugen/Unterschrift], [nicht nachweisbar], [2 Zeugen (ART-0307)],
  [Nie aktualisiert], [Vermächtnis veraltet], [1× jährlich (Dezember) erneuern],
)
Keine.
ART-0286, S. #refpage(<art-0286>) (vier Schichten), ART-0293, S. #refpage(<art-0293>) (Gedenken), ART-0307, S. #refpage(<art-0307>) (Zeugen), ART-0292, S. #refpage(<art-0292>) (Feuerprobe), ART-0306, S. #refpage(<art-0306>) (Reihe schließen), ART-0262 (Band 9) (Wissen weitergeben)
- _Vermächtnis:_ letzte schriftliche + mündliche Weitergabe — „geschrieben, solange die Hand führt, verlesen, ehe es gilt“.
- _Vermächtnis-Blatt:_ mit Name/Datum/Kernregeln/Unterschrift/2 Zeugen.
- _Vier Schichten:_ geschrieben – verlesen – eingeübt – Vermächtnis (ART-0286).
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Abbildungen]]
#align(center)[#block(width: 10.5cm)[#figure(image("../illustrationen/art-0311-abb-1.svg", width: 100%), caption: [Abb. zu ART-0311 — ART-0311 · Abb. 1: Vermächtnis: schriftlich verfassen, laut verlesen, an Vertrauensperson übergeben (ART-0311).])]]
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Kontroll-Checkliste]]
- [ ] Blatt nehmen (A3); für jeden –9 die 1–3 Kernregeln aufschreiben, die weitergegeben werden müssen.
- [ ] Unterschreiben; zwei Zeugen unterschreiben (ART-0307, S. #refpage(<art-0307>)).
- [ ] Vor der Gruppe verlesen (ART-0293, S. #refpage(<art-0293>)) — mündlich und schriftlich.
- [ ] Kopien in die vier Schichten verteilen (ART-0286, S. #refpage(<art-0286>)): geschrieben (2 Orte), verlesen, eingeübt, Vermächtnis.
- [ ] Jährlich (Dezember) erneuern; Protokoll (ART-0035 (Band 1)).
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Recherche-Details (Fakten, Masse, Fehler-Tiefe)]]
#table(
  columns: 2,
  table.header([*Aspekt*], [*Detail (Recherche)*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Masse/Zeiten/Mengen], [9 Bände = Kernregeln je Band; 2 Zeugen; 1× jährlich; 4 Schichten.],
  [Typische Fehler], [nur mündlich → Wissen stirbt mit der Person .],
  [Varianten Stadt/Land], [Stadt: Verlesen in der Hausgemeinschaft, Kopien in mehreren Wohnungen; Land: Rat verliest, Kopien in mehreren Gebäuden.],
  [Fakten], [1. Schreiben ; 2. Verlesen vor der Gruppe ; 3. Kopie in die vier Schichten . Jährlich aktualisieren . Übungsziel : 1× jährlich, Kernregeln pro –9 niedergeschrie],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Übungsprotokoll (Verfalluhr 12 Monate)]]
#table(
  columns: 5,
  table.header([*Nr.*], [*Datum*], [*Dauer*], [*Fehler*], [*V / Verfall*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [1], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [2], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [3], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [4], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [5], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [6], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [7], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [8], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [9], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [10], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [11], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [12], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Randbedingungen (vor Ort ausfüllen)]]
#table(
  columns: 3,
  table.header([*Randbedingung*], [*Trifft zu*], [*Anmerkung*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Allein / in der Gruppe], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Stadt / Land], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Tag / Nacht], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Sommer / Winter], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Notizen zu ART-0311]]
#block(width: 100%, height: 6.5cm, stroke: 0.6pt + rgb("#8c8c8c"), inset: 6pt)[Platz für eigene Notizen zu diesem Artikel.]
#pagebreak(weak: true)
== ART-0312 — Wie vergebe ich Ämter im Dorf (Amt an die Hand, nicht an das Blut)? <art-0312>
Ämter des Dorfes/Haushalts so vergeben, dass Ordnung bei Ausfall bleibt: _Amt an die Hand, nicht an das Blut_ — rotierend und _doppelt besetzt_ (ART-0028 (Band 1)).
- Ämter-Tafel (Papier): je Amt 2 Namen, Rotationstermin
- Rad der Ämter (Abb. 10.3): Markt in der Mitte, Dienste am Rand; Wach-Amt als Warnrahmen des Dorfes
- Ämter (— interne Konvention): Schmied, Müllerin, Bäcker, Zimmermann, Spinnerin, Heilerin, Wache, Schreiber — 8 Ämter
- Feuerprobe-Fragen (Nr. 9–10): Welches Amt trage ich — kann ich es mit geschlossenen Augen? Auf wessen Schulter lastet ein Amt zu viel?
+ Ämter definieren (8 Dienste) und an die _Hand_ vergeben — die es kann, nicht die erbt.
+ Jedes Amt _doppelt besetzen_ (Ausfall kompensierbar).
+ Rotation planen (z. B. jährlich, Neujahrs-Rat — ART-0291).
+ Wachplan für das Haus aufstellen (ART-0028); Tauschplatz/Wachen besetzen (ART-0302).
+ Kontrolle: keine Schulter trägt alles; bei Überlastung umverteilen.
- _Land:_ Dorfgemeinschaft, Rat aus Ämtern im Gemeindehaus; _Stadt:_ Ämter pro Haushalt in der Nachbarschaft/Etage, Rat der Nachbarn, Tauschplatz Treppenhaus/Hof (ART-0302), Vorrat im kühlen Treppenhaus (ART-0284), Wachplan fürs Haus (ART-0028).
#table(
  columns: 3,
  table.header([Fehler], [Folge], [Korrektur]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Erbämter (Amt der Bluts-Linie)], [Rat bekommt einen Namen statt einer Hand — Amt erlahmt], [Amt an die Hand (dieser Artikel)],
  [Alle Ämter auf eine Schulter], [der Eine backt, schmiedet, heilt — und fällt aus], [Doppelbesetzung + Rotation],
  [Keine Rotation], [Ausfall nicht kompensierbar, Tyrannei], [Rotation geplant],
)
Keine.
ART-0028 (Band 1) (Rollen/Wochenplan), ART-0283, S. #refpage(<art-0283>) (Krisenstab), ART-0302, S. #refpage(<art-0302>) (Tausch-Platz/Wachen), ART-0305, S. #refpage(<art-0305>) (Rat), ART-0291, S. #refpage(<art-0291>) (Kalender), ART-0292, S. #refpage(<art-0292>) (Feuerprobe)
Üben: zum Neujahrs-Rat einmal im Jahr die Ämter-Tafel erneuern — jedes Amt doppelt besetzt, Rotation geplant.
- _Amt:_ Dienst, den das Dorf trägt — gehört der Hand, die es kann, nicht dem Blut.
- _Doppelbesetzung:_ jedes Amt mit 2 Personen — Ausfall kompensierbar.
- _Rad der Ämter:_ Markt in der Mitte, Dienste am Rand (Abb. 10.3).
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Abbildungen]]
#align(center)[#block(width: 10.5cm)[#figure(image("../illustrationen/abb-10-3.svg", width: 100%), caption: [Abb. 10.3 (Band 10, siehe Artikel ART-0312)])]]
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Kontroll-Checkliste]]
- [ ] Ämter definieren (8 Dienste) und an die Hand vergeben — die es kann, nicht die erbt.
- [ ] Jedes Amt doppelt besetzen (Ausfall kompensierbar).
- [ ] Rotation planen (z. B. jährlich, Neujahrs-Rat — ART-0291, S. #refpage(<art-0291>)).
- [ ] Wachplan für das Haus aufstellen (ART-0028 (Band 1)); Tauschplatz/Wachen besetzen (ART-0302, S. #refpage(<art-0302>)).
- [ ] Kontrolle: keine Schulter trägt alles; bei Überlastung umverteilen.
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Recherche-Details (Fakten, Masse, Fehler-Tiefe)]]
#table(
  columns: 2,
  table.header([*Aspekt*], [*Detail (Recherche)*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Masse/Zeiten/Mengen], [8 Ämter ; 2 Namen je Amt ; Rotation geplant .],
  [Typische Fehler], [Erbämter → Inkompetenz, Ausfall nicht kompensierbar, Tyrannei .],
  [Varianten Stadt/Land], [Land: Dorfgemeinschaft, Rat aus Ämtern; Stadt: dasselbe auf Nachbarschaft/Stockwerk — Ämter pro Haushalt rotierend, Rat der Nachbarn, Tauschplatz Treppenhaus/Ho],
  [Fakten], [Amt an die Hand, nicht an das Blut — Ämter rotieren und sind doppelt besetzt , damit Ordnung bei Ausfall bleibt. Abb. 10.3: Rad der Ämter — Markt in der Mitte, ],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Übungsprotokoll (Verfalluhr 12 Monate)]]
#table(
  columns: 5,
  table.header([*Nr.*], [*Datum*], [*Dauer*], [*Fehler*], [*V / Verfall*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [1], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [2], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [3], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [4], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [5], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [6], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [7], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [8], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [9], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [10], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [11], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [12], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Randbedingungen (vor Ort ausfüllen)]]
#table(
  columns: 3,
  table.header([*Randbedingung*], [*Trifft zu*], [*Anmerkung*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Allein / in der Gruppe], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Stadt / Land], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Tag / Nacht], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Sommer / Winter], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Notizen zu ART-0312]]
#block(width: 100%, height: 6.5cm, stroke: 0.6pt + rgb("#8c8c8c"), inset: 6pt)[Platz für eigene Notizen zu diesem Artikel.]
#pagebreak(weak: true)
== ART-0313 — Wie vermeide ich Wucher (Not-Preis nach der Not)? <art-0313>
In der Not faire Preise halten: der _Not-Preis wird nach der Not_ bemessen — ethisch vertretbar, rechtlich Grauzone; im Korridor (ART-0285, S. #refpage(<art-0285>)) bleiben, nie Mondpreise.
- Wert-Korridor je Ware (ART-0285) — untere/obere Grenze am Blatt
- Keine feste numerische Schwelle: „auffälliges Missverhältnis“ ist Tatbestandsfrage (bewusst keine Quote)
- Wort-Kunde: „der Wucher — der Preis, der die Not verzinst; die Frist ersetzt den Zins, das Blatt ersetzt die Angst“
- Feuerprobe-Frage 7: „Wo habe ich an der Not des Nachbarn verdient? — der Wucher-Test, die Schuld geschoren“
+ Vor jedem Tausch in der Not: Korridor rechnen (Stunde, Seltenheit, Not — ART-0285).
+ Preis _innerhalb_ des Korridors halten — nie auf der Spitze.
+ Not-Markt: Ware aus der Reserve, _kein Gewinn_ (ART-0302).
+ Zeile am Tausch-Blatt mit 2 Zeugen + Frist (ART-0307) — die Frist ersetzt den Zins.
+ Selbstprüfung monatlich: an wessen Not habe ich verdient?
- _Stadt/Land:_ gleich; Notlage: Preis nach Bedarf des anderen, im Korridor.
- _Klima:_ Missernte/Jahreszeit ändert Seltenheit — Korridor anpassen (ART-0285).
#table(
  columns: 3,
  table.header([Fehler], [Folge], [Korrektur]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Mondpreis in der Not], [strafbar (§ 291 StGB), nichtig (§ 138 Abs. 2 BGB), das Dorf ächtet einen, künftige Hilfe aus], [Not-Preis nach der Not, im Korridor (dieser Artikel)],
  [Gewinn am Not-Markt], [Wucher — strafbar], [Not-Markt ohne Gewinn (ART-0302)],
  [Korridor nicht gerechnet], [Preis der Angst zahlt dreimal], [Korridor am Blatt (ART-0285)],
)
#warnrahmen(id: "warn-art-0313", )[siehe oben — § 291 StGB / § 138 Abs. 2 BGB Wortlaut; Schwellenwert „auffälliges Missverhältnis“ nicht beziffert (Tatbestandsfrage);.]
ART-0285, S. #refpage(<art-0285>) (Wert-Korridor), ART-0302, S. #refpage(<art-0302>) (Tausch-Platz/Not-Markt), ART-0307, S. #refpage(<art-0307>) (Vertrag/Zeugen), ART-0294, S. #refpage(<art-0294>) (Gabe nie mahnen), ART-0305, S. #refpage(<art-0305>) (Rat)
Üben: monatlich den Wucher-Test — habe ich an der Not eines anderen verdient? Not-Preis nur innerhalb des Korridors.
- _Wucher:_ Ausbeutung der Zwangslage mit „auffälligem Missverhältnis“ — strafbar (§ 291 StGB), nichtig (§ 138 Abs. 2 BGB).
- _Not-Preis:_ Preis nach dem Bedarf des anderen — im Korridor bleiben.
- _Wucher-Test:_ monatliche Selbstprüfung (Feuerprobe-Frage 7).
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Kontroll-Checkliste]]
- [ ] Vor jedem Tausch in der Not: Korridor rechnen (Stunde, Seltenheit, Not — ART-0285, S. #refpage(<art-0285>)).
- [ ] Preis innerhalb des Korridors halten — nie auf der Spitze.
- [ ] Not-Markt: Ware aus der Reserve, kein Gewinn (ART-0302, S. #refpage(<art-0302>)).
- [ ] Zeile am Tausch-Blatt mit 2 Zeugen + Frist (ART-0307, S. #refpage(<art-0307>)) — die Frist ersetzt den Zins.
- [ ] Selbstprüfung monatlich: an wessen Not habe ich verdient?
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Recherche-Details (Fakten, Masse, Fehler-Tiefe)]]
#table(
  columns: 2,
  table.header([*Aspekt*], [*Detail (Recherche)*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Masse/Zeiten/Mengen], [keine numerischen Grenzen im Band — „krasses Missverhältnis“ ist Tatbestandsfrage .],
  [Typische Fehler], [in der Not Mondpreise verlangen → strafbar , das Dorf ächtet einen, künftige Hilfe aus ; : „Not-Preis in der Not überzogen“.],
  [Varianten Stadt/Land], [gleich; Notlage: Preis nach Bedarf des anderen, im Korridor bleiben.],
  [Fakten], [Not-Preis nach der Not — ethisch vertretbar, rechtlich Grauzone: § 291 StGB , § 138 Abs. 2 BGB . Leitlinie: Tausch vor Behalten, faire Korridore bleiben ; Not-M],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Übungsprotokoll (Verfalluhr 12 Monate)]]
#table(
  columns: 5,
  table.header([*Nr.*], [*Datum*], [*Dauer*], [*Fehler*], [*V / Verfall*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [1], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [2], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [3], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [4], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [5], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [6], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [7], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [8], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [9], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [10], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [11], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [12], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Randbedingungen (vor Ort ausfüllen)]]
#table(
  columns: 3,
  table.header([*Randbedingung*], [*Trifft zu*], [*Anmerkung*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Allein / in der Gruppe], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Stadt / Land], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Tag / Nacht], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Sommer / Winter], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Notizen zu ART-0313]]
#block(width: 100%, height: 6.5cm, stroke: 0.6pt + rgb("#8c8c8c"), inset: 6pt)[Platz für eigene Notizen zu diesem Artikel.]
#pagebreak(weak: true)
== ART-0314 — Wie wiege ich ehrlich (gestrichen messen, Bürger-Maß)? <art-0314>
Beim Tausch ehrlich messen: _gestrichen messen_ (randvoll, nicht gehäuft), das _Bürger-Maß_ des Platzes als Referenz, die Waage vor Gebrauch _balanciert prüfen_.
- Maße-Tafel des Dorfes (— interne Praxis; nach -Korrektur widerspruchsfrei):
- _Länge:_ Elle (Vorderarm bis Mittelfinger, ≈ 45 cm Körpermaß, individuell geeicht — ART-0024 (Band 1)), Fuß, _Rute regional 10–16 Fuß_ (korrigiert); geprüft je Markt-Tag vom Rat an der _Markt-Rute am Ring - _Gewicht:_ Pfund (der Stein), _Zentner = 100 Pfund = 50 kg_; geprüft am Balken mit zwei Eimern und dem Stein, je Markt-Tag am Amts-Blatt - _Hohlmaß:_ Zuber, Fäßchen, Metze für Korn — _gestrichen, nicht gehäuft: „der Strich ist das Gesetz“_; geprüft je Markt-Tag am Korn-Tisch - _Zeit:_ Stunde (Sonnenstand, Kerze), Tag von Hahn bis Eule; Markt-Kerze am Platz - _Stück:_ Dutzend, _Mandel = 15\*\* — laut gezählt vor dem Zeugen (Tausch-Blatt zeugt, ART-0307, S. #refpage(<art-0307>))
- Waage (balanciert prüfen) oder Balken mit zwei Eimern
+ Bürger-Maß bereitstellen (Rute am Ring, Stein am Balken, Metze am Korn-Tisch).
+ Waage vor Gebrauch balancieren (leer ausschlagen lassen).
+ Hohlmaß _gestrichen_ füllen — mit dem Strich abziehen, nie gehäuft.
+ Stückware laut vor dem Zeugen zählen (Dutzend, Mandel).
+ Ergebnis am Tausch-Blatt eintragen (ART-0307); Maß am Markt-Tag vom Rat prüfen lassen (April, Tausch-Jahr: „Maße weihen“).
- _Land:_ Bürger-Maß am Ring/Dorfanger; _Stadt:_ Referenzgefäß + Waage des Hauses im Treppenhaus, Eichung zu Hause.
- _Klima:_ Metall dehnt sich — Maß bei Kälte/Hitze nicht neu eichen; Holzmaß quillt bei Nässe.
#table(
  columns: 3,
  table.header([Fehler], [Folge], [Korrektur]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Gehäuft statt gestrichen gemessen], [einer zahlt doppelt — Streit], [gestrichen messen: der Strich ist das Gesetz],
  [Ungeeichte Waage], [systematische Fehlmessung], [vor Gebrauch balancieren],
  [Eigene Rute gegen das Bürger-Maß], [zwei Ruthen, zwei Wahrheiten], [Bürger-Maß gilt am Platz; eigene Maße zu Hause eichen (ART-0024)],
  [Historische Maße unkritisch (z. B. „Ruthe = 6 Fuß“)], [falsche Mengen], [Rute regional 10–16 Fuß (-Korrektur)],
)
Keine.
ART-0285, S. #refpage(<art-0285>) (Wert), ART-0302, S. #refpage(<art-0302>) (Tausch-Platz), ART-0307, S. #refpage(<art-0307>) (Vertrag), ART-0309, S. #refpage(<art-0309>) (Ware), ART-0023 (Band 1) (Mengen ohne Waage), ART-0024 (Band 1) (Körpermaße), ART-0023 (Band 1) (EL/TL/20 Tropfen — grün)
Üben: im April die Maße am Platz prüfen lassen — Rute, Stein und Metze geeicht, Bürger-Maß am Ring.
- _Gestrichen messen:_ randvoll füllen, mit dem Strich abziehen — nie gehäuft.
- _Bürger-Maß:_ das Eich-Maß des Platzes (Rute am Ring, Stein am Balken, Metze am Korn-Tisch) — das Maß gehört dem Platz.
- _Mandel:_ 15 Stück. _Zentner:_ 100 Pfund = 50 kg. _Rute:_ regional 10–16 Fuß. _Elle:_ ≈ 45 cm Körpermaß.
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Kontroll-Checkliste]]
- [ ] Bürger-Maß bereitstellen (Rute am Ring, Stein am Balken, Metze am Korn-Tisch).
- [ ] Waage vor Gebrauch balancieren (leer ausschlagen lassen).
- [ ] Hohlmaß gestrichen füllen — mit dem Strich abziehen, nie gehäuft.
- [ ] Stückware laut vor dem Zeugen zählen (Dutzend, Mandel).
- [ ] Ergebnis am Tausch-Blatt eintragen (ART-0307, S. #refpage(<art-0307>)); Maß am Markt-Tag vom Rat prüfen lassen (April, Tausch-Jahr: „Ma
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Recherche-Details (Fakten, Masse, Fehler-Tiefe)]]
#table(
  columns: 2,
  table.header([*Aspekt*], [*Detail (Recherche)*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Masse/Zeiten/Mengen], [Ruthe = 6 Fuß; Mandel = 15; Zentner = 100 Pfund; Elle ≈ 45 cm; Eichung je Markt-Tag .],
  [Typische Fehler], [gehäuft messen oder ungeeichte Waage → einer zahlt doppelt, Streit .],
  [Varianten Stadt/Land], [gleich; Dorf: Bürger-Maß am Ring/Dorfanger; Stadt: Referenzgefäß im Treppenhaus, Waage des Hauses.],
  [Fakten], [messen ; Bürger-Maß = das bekannte Gefäß/Einheit des Platzes als Referenz ; Waage vor Gebrauch balanciert prüfen. Maße-Tafel: Länge — Elle , Fuß, Ruthe = 6 Fuß,],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Übungsprotokoll (Verfalluhr 12 Monate)]]
#table(
  columns: 5,
  table.header([*Nr.*], [*Datum*], [*Dauer*], [*Fehler*], [*V / Verfall*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [1], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [2], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [3], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [4], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [5], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [6], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [7], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [8], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [9], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [10], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [11], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
  [12], [[ ]], [\_\_\_\_\_  #v(2pt)], [\_\_\_  #v(2pt)], [\_\_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Randbedingungen (vor Ort ausfüllen)]]
#table(
  columns: 3,
  table.header([*Randbedingung*], [*Trifft zu*], [*Anmerkung*]),
  table.hline(stroke: 0.9pt + rgb("#1a1a1a")),
  [Allein / in der Gruppe], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Stadt / Land], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Tag / Nacht], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
  [Sommer / Winter], [[ ] geprüft  #v(2pt)], [Notiz: \_\_\_\_  #v(2pt)],
)
#block(above: 8pt, below: 3pt)[#text(size: 11pt, weight: "bold")[Notizen zu ART-0314]]
#block(width: 100%, height: 6.5cm, stroke: 0.6pt + rgb("#8c8c8c"), inset: 6pt)[Platz für eigene Notizen zu diesem Artikel.]
